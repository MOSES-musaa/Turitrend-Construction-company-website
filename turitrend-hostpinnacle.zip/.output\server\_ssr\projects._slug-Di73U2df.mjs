import { r as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./projects._slug-BPr1HOFN.mjs";
import { n as projects } from "./project-DTVvFtME.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects._slug-Di73U2df.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProjectGallery({ images, projectName }) {
	const [activeIndex, setActiveIndex] = (0, import_react.useState)(0);
	if (images.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex aspect-16/10 items-center justify-center border border-line bg-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "label-tech text-muted-foreground",
			children: "Project photography unavailable"
		})
	});
	const activeImage = images[activeIndex];
	const previousImage = () => {
		setActiveIndex((current) => current === 0 ? images.length - 1 : current - 1);
	};
	const nextImage = () => {
		setActiveIndex((current) => current === images.length - 1 ? 0 : current + 1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden bg-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: activeImage.src,
					alt: activeImage.alt,
					className: "aspect-16/10 w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute bottom-4 left-4 bg-background/90 px-3 py-1.5 text-xs font-medium backdrop-blur-sm",
					children: [
						activeIndex + 1,
						" / ",
						images.length
					]
				}),
				images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: previousImage,
					"aria-label": "Previous project image",
					className: "absolute left-4 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center border border-background/30 bg-background/90 text-lg transition-transform hover:scale-105",
					children: "←"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: nextImage,
					"aria-label": "Next project image",
					className: "absolute right-4 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center border border-background/30 bg-background/90 text-lg transition-transform hover:scale-105",
					children: "→"
				})] })
			]
		}), images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-4 gap-2 sm:grid-cols-6 md:grid-cols-8",
			"aria-label": `${projectName} image gallery`,
			children: images.map((image, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setActiveIndex(index),
				"aria-label": `View image ${index + 1}`,
				"aria-current": index === activeIndex,
				className: `relative aspect-square overflow-hidden border-2 transition-opacity ${index === activeIndex ? "border-accent" : "border-transparent opacity-70 hover:opacity-100"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: image.src,
					alt: "",
					loading: "lazy",
					className: "h-full w-full object-cover"
				})
			}, image.src))
		})]
	});
}
function ProjectDetail() {
	const { slug } = Route.useParams();
	const project = projects.find((item) => item.slug === slug);
	if (!project) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "container-x section-y",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech text-accent",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-4xl font-semibold tracking-tight",
					children: "Project not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted-foreground",
					children: "The project you are looking for could not be found."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/projects",
					className: "mt-8 inline-flex border border-line px-5 py-3 text-sm font-medium transition-colors hover:bg-foreground hover:text-background",
					children: "← Back to projects"
				})
			]
		})
	});
	const relatedProjects = projects.filter((item) => item.category === project.category && item.slug !== project.slug).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-4xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/projects",
						className: "label-tech text-muted-foreground transition-colors hover:text-accent",
						children: "← Projects"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-10 label-tech text-accent",
						children: project.category
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 text-4xl font-semibold tracking-tight md:text-6xl",
						children: project.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted-foreground",
						children: project.location
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectGallery, {
				images: project.images,
				projectName: project.name
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-[1fr_320px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech text-accent",
						children: "Project overview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-3xl font-semibold tracking-tight",
						children: project.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-3xl text-base leading-8 text-muted-foreground",
						children: project.description
					}),
					project.scope.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-semibold",
							children: "Scope of work"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3",
							children: project.scope.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 text-sm text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-accent",
									children: "+"
								}), item]
							}, item))
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "border border-line bg-card p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech text-accent",
						children: "Project details"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Category"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm font-medium",
								children: project.category
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Location"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm font-medium",
								children: project.location
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Status"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm font-medium",
								children: project.status
							})] }),
							project.servicesProvided.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Services"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-3 flex flex-wrap gap-2",
								children: project.servicesProvided.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "border border-line px-2.5 py-1 text-xs",
									children: service
								}, service))
							})] })
						]
					})]
				})]
			})
		}),
		relatedProjects.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y border-t border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "label-tech text-accent",
				children: "More projects"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-3 text-3xl font-semibold tracking-tight",
				children: ["More from ", project.category]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
				children: relatedProjects.map((related) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-line p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label-tech text-accent",
							children: related.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 text-xl font-semibold",
							children: related.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: related.location
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/projects/$slug",
							params: { slug: related.slug },
							className: "mt-6 inline-flex text-sm font-medium hover:text-accent",
							children: "View project →"
						})
					]
				}, related.slug))
			})]
		})
	] });
}
//#endregion
export { ProjectDetail as component };
