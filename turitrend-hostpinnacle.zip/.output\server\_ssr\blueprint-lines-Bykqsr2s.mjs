//#region node_modules/.nitro/vite/services/ssr/assets/blueprint-lines-Bykqsr2s.js
var blueprint_lines_default = "/assets/blueprint-lines-nL0mkxgi.jpg";
//#endregion
export { blueprint_lines_default as t };
