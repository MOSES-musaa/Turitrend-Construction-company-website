import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as CtaBand } from "./cta-band-CNJbZvLK.mjs";
import { t as Reveal } from "./reveal-9iJXRnDn.mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { t as SectionHeading } from "./section-heading-CNHs7aX1.mjs";
import { n as projects, t as projectCategories } from "./project-DTVvFtME.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects.index-XZvwNUyJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProjectCard({ project }) {
	const coverImage = project.images[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group overflow-hidden border border-line bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-4/3 overflow-hidden bg-muted",
			children: [
				coverImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: coverImage.src,
					alt: coverImage.alt,
					loading: "lazy",
					className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full items-center justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "label-tech text-muted-foreground",
						children: "Project photography"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute left-4 top-4 bg-background/90 px-3 py-1.5 text-xs font-medium backdrop-blur-sm",
					children: project.category
				}),
				project.images.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "absolute bottom-4 right-4 bg-foreground/90 px-3 py-1.5 text-xs font-medium text-background",
					children: [
						project.images.length,
						" ",
						project.images.length === 1 ? "photo" : "photos"
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech text-accent",
					children: project.location
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 text-xl font-semibold tracking-tight",
					children: project.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 line-clamp-3 text-sm leading-relaxed text-muted-foreground",
					children: project.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/projects/$slug",
					params: { slug: project.slug },
					className: "mt-6 inline-flex items-center gap-2 text-sm font-medium transition-colors hover:text-accent",
					children: ["View project", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						className: "transition-transform duration-200 group-hover:translate-x-1",
						children: "→"
					})]
				})
			]
		})]
	});
}
function Projects() {
	const [filter, setFilter] = (0, import_react.useState)("All");
	const categories = projectCategories;
	const visible = filter === "All" ? projects : projects.filter((p) => p.category === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Projects",
			title: "Project showcases are being documented.",
			intro: "Explore a selection of our completed and ongoing projects, showcasing Turiend Construction Limited’s commitment to quality craftsmanship, thoughtful execution, and reliable construction solutions. From residential developments to commercial works, every project reflects our focus on delivering lasting value from concept to completion."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Filter",
					title: "Browse by service area",
					intro: "Filters are live — project entries will appear under the relevant service area as they are published."
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 flex flex-wrap gap-2",
					role: "group",
					"aria-label": "Filter projects",
					children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(category),
						"aria-pressed": filter === category,
						className: cn("label-tech min-h-11 border px-4 py-2.5 transition-colors", filter === category ? "border-ink bg-ink text-ink-foreground" : "border-line hover:border-ink"),
						children: category
					}, category))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
					children: visible.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectCard, { project }, project.slug))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {
			title: "Ask about work we have done.",
			text: "Tell us the kind of project you are planning and we will discuss relevant experience with you directly.",
			whatsappMessage: "Hello Turiend, I would like to ask about projects you have completed.",
			context: "projects"
		})
	] });
}
//#endregion
export { Projects as component };
