//#region node_modules/.nitro/vite/services/ssr/assets/placeholders-CL4ero5s.js
var aboutus1_default = "/assets/aboutus1-x_y0PJyX.jpg";
var process_planning_default = "/assets/process-planning-BE6SJAs2.jpg";
var serviceImages = {
	"home-improvements-renovations": {
		src: "/assets/service-renovations-aWb-S1df.jpg",
		alt: "Illustrative view of a contemporary home renovation interior"
	},
	"building-works": {
		src: "/assets/service-building-CQw4dWYd.jpg",
		alt: "Illustrative view of a building structure under construction"
	},
	"fences-gates-car-shades": {
		src: "/assets/service-fences-BGc-bXo-.jpg",
		alt: "Illustrative view of a modern entrance gate and perimeter fence"
	},
	"biodigester-works": {
		src: "/assets/service-biodigester-BjG2Orh7.jpg",
		alt: "Illustrative view of a biodigester installation in progress"
	},
	"road-electrical-water-works": {
		src: "/assets/service-infrastructure-CsYHMo1x.jpg",
		alt: "Illustrative view of road and utility infrastructure works"
	},
	"project-property-management": {
		src: "/assets/service-management-C84caurY.jpg",
		alt: "Illustrative view of construction drawings and site management planning"
	}
};
var aboutImage = {
	src: aboutus1_default,
	alt: "Illustrative view of a construction team reviewing plans on site"
};
var processImage = {
	src: process_planning_default,
	alt: "Illustrative view of construction planning documents and measuring tools"
};
//#endregion
export { processImage as n, serviceImages as r, aboutImage as t };
