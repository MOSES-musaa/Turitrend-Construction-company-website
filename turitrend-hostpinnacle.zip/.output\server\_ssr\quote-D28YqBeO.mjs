import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as ArrowRight, O as Check, P as ArrowLeft } from "../_libs/lucide-react.mjs";
import { d as projectStages, f as quoteServiceOptions, g as whatsappLink, h as track, o as company, r as WhatsAppCta, s as defaultWhatsappMessage, t as CtaButton } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { t as submitEnquiry } from "./enquiry.functions-iaWd7HN7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quote-D28YqBeO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fieldClass = "w-full border border-line bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-ink placeholder:text-muted-foreground/60";
var steps = [
	"Service",
	"Location",
	"Details",
	"Stage",
	"Contact",
	"Review"
];
var initialState = {
	service: "",
	location: "",
	details: "",
	stage: "",
	name: "",
	phone: "",
	email: ""
};
function QuotePage() {
	const [step, setStep] = (0, import_react.useState)(0);
	const [form, setForm] = (0, import_react.useState)(initialState);
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const [sending, setSending] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const set = (key, value) => setForm((current) => ({
		...current,
		[key]: value
	}));
	const canContinue = (0, import_react.useMemo)(() => {
		switch (step) {
			case 0: return form.service !== "";
			case 1: return form.location.trim().length > 1;
			case 2: return form.details.trim().length > 10;
			case 3: return form.stage !== "";
			case 4: return form.name.trim().length > 1 && form.phone.trim().length > 6;
			default: return true;
		}
	}, [step, form]);
	const summary = (0, import_react.useMemo)(() => [
		`Service: ${form.service}`,
		`Location: ${form.location}`,
		`Stage: ${form.stage}`,
		"",
		form.details,
		"",
		`— ${form.name}`,
		form.phone,
		form.email
	].filter(Boolean).join("\n"), [form]);
	const next = () => {
		track("quote_step_completed", { step: steps[step] });
		if (step === 0) track("quote_started", { service: form.service });
		setError("");
		setStep((current) => Math.min(current + 1, steps.length - 1));
	};
	const back = () => {
		if (sending) return;
		setError("");
		setStep((current) => Math.max(current - 1, 0));
	};
	async function onSubmit() {
		if (sending) return;
		setSending(true);
		setError("");
		try {
			await submitEnquiry({ data: {
				type: "quote",
				service: form.service,
				location: form.location,
				details: form.details,
				stage: form.stage,
				name: form.name,
				phone: form.phone,
				email: form.email
			} });
			track("quote_submitted", {
				service: form.service,
				location: form.location,
				stage: form.stage
			});
			setSubmitted(true);
		} catch (submissionError) {
			console.error("Quote form submission failed:", submissionError);
			setError("We couldn't send your quote request right now. Please try again or contact us directly on WhatsApp.");
		} finally {
			setSending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Request a quote",
		title: "Tell us about your project.",
		intro: "Six short steps. The more specific you are, the more useful our first response will be."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "container-x section-y",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-3xl",
			children: submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-line bg-surface p-8 md:p-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech text-accent",
						children: "Enquiry sent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "display-3 mt-4",
						children: [
							"Thank you, ",
							form.name.split(" ")[0],
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground",
						children: "Your quote request has been sent successfully to the Turiend team. We have the project details below and will review them before getting back to you."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-6 overflow-x-auto border border-line bg-background p-5 font-mono text-xs leading-relaxed whitespace-pre-wrap",
						children: summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: whatsappLink(`Hello Turiend, I have just submitted a quote request through your website.\n\n${summary}`),
							target: "_blank",
							rel: "noopener noreferrer",
							onClick: () => track("whatsapp_click", { context: "quote_confirmation" }),
							className: "inline-flex min-h-11 items-center justify-center gap-2.5 rounded-xs bg-accent px-6 py-3 text-sm font-medium tracking-tight text-accent-foreground transition-all hover:brightness-108",
							children: "Follow up on WhatsApp"
						})
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-6 gap-px border border-line bg-line",
					children: steps.map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("bg-background px-2 py-3 text-center text-[0.65rem] font-medium tracking-wider uppercase", i === step && "bg-ink text-ink-foreground", i < step && "bg-surface text-muted-foreground"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: label
						})
					}, label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 border border-line bg-card p-6 md:p-10",
					children: [
						step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-xl font-semibold tracking-tight",
							children: "Which service does your project fall under?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid gap-2 sm:grid-cols-2",
							children: quoteServiceOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: cn("flex cursor-pointer items-center gap-3 border border-line px-4 py-3 text-sm transition-colors hover:border-ink", form.service === option && "border-ink bg-ink text-ink-foreground"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										name: "service",
										value: option,
										checked: form.service === option,
										onChange: () => set("service", option),
										className: "sr-only"
									}),
									form.service === option && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "size-4 shrink-0 text-accent",
										"aria-hidden": "true"
									}),
									option
								]
							}, option))
						})] }),
						step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "location",
								className: "text-xl font-semibold tracking-tight",
								children: "Where is the project located?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Town, county, or the nearest landmark is enough at this stage."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "location",
								type: "text",
								value: form.location,
								onChange: (event) => set("location", event.target.value),
								placeholder: "e.g. Ruiru, Kiambu County",
								className: cn(fieldClass, "mt-5"),
								autoFocus: true,
								disabled: sending
							})
						] }),
						step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "details",
								className: "text-xl font-semibold tracking-tight",
								children: "Describe the work you have in mind."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Size, current condition, what you want to end up with. If you have drawings, photos or a bill of quantities, mention it here — you can share files with us on WhatsApp or email after submitting."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								id: "details",
								rows: 6,
								value: form.details,
								onChange: (event) => set("details", event.target.value),
								placeholder: "e.g. A three-bedroom house on a 40×80 plot, foundation already cast…",
								className: cn(fieldClass, "mt-5 resize-y"),
								autoFocus: true,
								disabled: sending
							})
						] }),
						step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-xl font-semibold tracking-tight",
							children: "What stage is the project at?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid gap-2",
							children: projectStages.map((stageOption) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: cn("flex cursor-pointer items-center gap-3 border border-line px-4 py-3 text-sm transition-colors hover:border-ink", form.stage === stageOption && "border-ink bg-ink text-ink-foreground"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										name: "stage",
										value: stageOption,
										checked: form.stage === stageOption,
										onChange: () => set("stage", stageOption),
										className: "sr-only"
									}),
									form.stage === stageOption && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "size-4 shrink-0 text-accent",
										"aria-hidden": "true"
									}),
									stageOption
								]
							}, stageOption))
						})] }),
						step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-semibold tracking-tight",
								children: "How do we reach you?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Please provide your phone or WhatsApp number. You can also add an email address."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 grid gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "name",
									className: "label-tech mb-2 block",
									children: "Full name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "name",
									type: "text",
									autoComplete: "name",
									value: form.name,
									onChange: (event) => set("name", event.target.value),
									className: fieldClass,
									autoFocus: true,
									disabled: sending
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "phone",
										className: "label-tech mb-2 block",
										children: "Phone / WhatsApp"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "phone",
										type: "tel",
										autoComplete: "tel",
										value: form.phone,
										onChange: (event) => set("phone", event.target.value),
										placeholder: "07XX XXX XXX",
										className: fieldClass,
										disabled: sending
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "email",
										className: "label-tech mb-2 block",
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "email",
										type: "email",
										autoComplete: "email",
										value: form.email,
										onChange: (event) => set("email", event.target.value),
										placeholder: "you@example.com",
										className: fieldClass,
										disabled: sending
									})] })]
								})]
							})
						] }),
						step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-semibold tracking-tight",
								children: "Review your enquiry."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Check the summary below before sending it to the Turiend team."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-5 overflow-x-auto border border-line bg-surface p-5 font-mono text-xs leading-relaxed whitespace-pre-wrap",
								children: summary
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								role: "alert",
								className: "mt-5 border border-destructive/30 bg-destructive/5 p-4 text-sm leading-relaxed text-destructive",
								children: error
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex items-center justify-between gap-3 border-t border-line pt-6",
							children: [step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: back,
								disabled: sending,
								className: "inline-flex min-h-11 items-center gap-2 px-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Back"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), step < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CtaButton, {
								variant: "ink",
								size: "md",
								disabled: !canContinue || sending,
								onClick: next,
								children: ["Continue", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "size-4",
									"aria-hidden": "true"
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CtaButton, {
								variant: "accent",
								size: "md",
								disabled: sending,
								onClick: onSubmit,
								children: [sending ? "Sending request..." : "Send quote request", !sending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "size-4",
									"aria-hidden": "true"
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-center text-sm text-muted-foreground",
					children: [
						"Prefer to talk it through first?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppCta, {
							message: defaultWhatsappMessage,
							label: "Message us on WhatsApp",
							variant: "quiet",
							size: "sm",
							context: "quote_page"
						}),
						" ",
						"or call",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: company.phoneHref,
							onClick: () => track("phone_click", { context: "quote_page" }),
							className: "underline underline-offset-4 hover:text-accent",
							children: company.phone
						}),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-center text-xs text-muted-foreground",
					children: [
						"Looking for general contact details instead?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "underline underline-offset-4 hover:text-accent",
							children: "Visit the contact page"
						}),
						"."
					]
				})
			] })
		})
	})] });
}
//#endregion
export { QuotePage as component };
