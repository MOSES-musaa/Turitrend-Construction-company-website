import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./insights._slug-DFlC2dLy.mjs";
import { t as insights } from "./insights-CLXMg3hL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights._slug-IVB1ynvL.js
var import_jsx_runtime = require_jsx_runtime();
function InsightDetail() {
	const { slug } = Route.useParams();
	const insight = insights.find((item) => item.slug === slug);
	if (!insight) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "container-x section-y",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech text-accent",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-4xl font-semibold tracking-tight",
					children: "Insight not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted-foreground",
					children: "The insight you are looking for could not be found."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/insights",
					className: "mt-8 inline-flex border border-line px-5 py-3 text-sm font-medium transition-colors hover:bg-foreground hover:text-background",
					children: "← Back to insights"
				})
			]
		})
	});
	const relatedInsights = insights.filter((item) => item.category === insight.category && item.slug !== insight.slug).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/insights",
					className: "label-tech text-muted-foreground transition-colors hover:text-accent",
					children: "← Insights"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label-tech text-accent",
							children: insight.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 text-4xl font-semibold tracking-tight md:text-6xl",
							children: insight.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-3xl text-lg leading-8 text-muted-foreground",
							children: insight.excerpt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: insight.date }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "·"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: insight.readTime })
							]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden bg-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: insight.image,
					alt: insight.title,
					className: "aspect-16/8 w-full object-cover"
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "mx-auto max-w-3xl",
				children: insight.content.map((section, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: index === 0 ? "" : "mt-12",
					children: [section.heading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-semibold tracking-tight md:text-3xl",
						children: section.heading
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 space-y-5",
						children: section.paragraphs.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base leading-8 text-muted-foreground md:text-lg",
							children: paragraph
						}, paragraph))
					})]
				}, `${section.heading ?? "section"}-${index}`))
			})
		}),
		relatedInsights.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y border-t border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "label-tech text-accent",
				children: "Continue reading"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-3xl font-semibold tracking-tight",
				children: "More insights"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
				children: relatedInsights.map((related) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "group overflow-hidden border border-line bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "aspect-16/10 overflow-hidden bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: related.image,
							alt: related.title,
							className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.02]",
							loading: "lazy"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "label-tech text-accent",
								children: related.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-xl font-semibold tracking-tight",
								children: related.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-7 text-muted-foreground",
								children: related.excerpt
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/insights/$slug",
								params: { slug: related.slug },
								className: "mt-5 inline-flex items-center gap-2 text-sm font-medium transition-colors hover:text-accent",
								children: ["Read article", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "→"
								})]
							})
						]
					})]
				}, related.slug))
			})]
		})
	] });
}
//#endregion
export { InsightDetail as component };
