//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CRDjDtIW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/faqs",
			"/how-we-work",
			"/insights",
			"/projects",
			"/quote",
			"/services/$slug",
			"/services/"
		],
		preloads: [
			"/assets/index-DyP7_x9B.js",
			"/assets/useStore-B9WcefOa.js",
			"/assets/link-CSxX31-N.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/matchContext-DcmkPtE7.js",
			"/assets/redirect-Dhm19zUi.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DyP7_x9B.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CGTPfqyH.js",
			"/assets/arrow-left-BeWaAL_x.js",
			"/assets/arrow-right-BkslHduy.js",
			"/assets/arrow-up-right-ws7jlizM.js",
			"/assets/shield-check-ClZb1RKx.js",
			"/assets/cta-band-BG9R-25G.js",
			"/assets/reveal-WL2P4jPb.js",
			"/assets/section-heading-Ct52sk2A.js",
			"/assets/placeholders-D7-QZQe-.js",
			"/assets/blueprint-lines-CmX7cIbn.js"
		]
	},
	"/about": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-B4f_WTNH.js",
			"/assets/shield-check-ClZb1RKx.js",
			"/assets/cta-band-BG9R-25G.js",
			"/assets/reveal-WL2P4jPb.js",
			"/assets/page-hero-D2urCon_.js",
			"/assets/section-heading-Ct52sk2A.js",
			"/assets/placeholders-D7-QZQe-.js"
		]
	},
	"/contact": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-BT4ZLrzp.js",
			"/assets/enquiry.functions-Dzy01iyp.js",
			"/assets/reveal-WL2P4jPb.js",
			"/assets/page-hero-D2urCon_.js",
			"/assets/section-heading-Ct52sk2A.js"
		]
	},
	"/faqs": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/faqs.tsx",
		children: void 0,
		preloads: [
			"/assets/faqs-CZ8WsDAQ.js",
			"/assets/accordion-Cn5es3Ul.js",
			"/assets/cta-band-BG9R-25G.js",
			"/assets/page-hero-D2urCon_.js"
		]
	},
	"/how-we-work": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/how-we-work.tsx",
		children: void 0,
		preloads: [
			"/assets/how-we-work-BeRW52TL.js",
			"/assets/cta-band-BG9R-25G.js",
			"/assets/reveal-WL2P4jPb.js",
			"/assets/page-hero-D2urCon_.js",
			"/assets/section-heading-Ct52sk2A.js",
			"/assets/placeholders-D7-QZQe-.js",
			"/assets/blueprint-lines-CmX7cIbn.js"
		]
	},
	"/insights": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/insights.tsx",
		children: ["/insights/$slug", "/insights/"],
		preloads: ["/assets/insights-CMPDyGl7.js"]
	},
	"/projects": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/projects.tsx",
		children: ["/projects/$slug", "/projects/"],
		preloads: ["/assets/projects-CMPDyGl7.js"]
	},
	"/quote": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/quote.tsx",
		children: void 0,
		preloads: [
			"/assets/quote-CqWq2-Vv.js",
			"/assets/enquiry.functions-Dzy01iyp.js",
			"/assets/arrow-left-BeWaAL_x.js",
			"/assets/arrow-right-BkslHduy.js",
			"/assets/check-CRrS2zSL.js",
			"/assets/page-hero-D2urCon_.js"
		]
	},
	"/insights/$slug": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/insights.$slug.tsx",
		children: void 0,
		preloads: ["/assets/insights._slug-DBNHJEYQ.js", "/assets/insights-CeU3_Q_M.js"]
	},
	"/projects/$slug": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/projects.$slug.tsx",
		children: void 0,
		preloads: ["/assets/projects._slug-BAP6lkwb.js", "/assets/project-PBWhjMT7.js"]
	},
	"/services/$slug": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/services.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/services._slug-Dj0dN6rG.js",
			"/assets/arrow-left-BeWaAL_x.js",
			"/assets/arrow-up-right-ws7jlizM.js",
			"/assets/check-CRrS2zSL.js",
			"/assets/accordion-Cn5es3Ul.js",
			"/assets/cta-band-BG9R-25G.js",
			"/assets/reveal-WL2P4jPb.js",
			"/assets/page-hero-D2urCon_.js",
			"/assets/section-heading-Ct52sk2A.js",
			"/assets/placeholders-D7-QZQe-.js"
		]
	},
	"/insights/": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/insights.index.tsx",
		children: void 0,
		preloads: [
			"/assets/insights.index-DH8-_wDA.js",
			"/assets/page-hero-D2urCon_.js",
			"/assets/insights-CeU3_Q_M.js"
		]
	},
	"/projects/": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/projects.index.tsx",
		children: void 0,
		preloads: [
			"/assets/projects.index-Dv0o7EZA.js",
			"/assets/cta-band-BG9R-25G.js",
			"/assets/reveal-WL2P4jPb.js",
			"/assets/page-hero-D2urCon_.js",
			"/assets/section-heading-Ct52sk2A.js",
			"/assets/project-PBWhjMT7.js"
		]
	},
	"/services/": {
		filePath: "C:/Users/User/Desktop/Website projects/TURITREND 2/Turitrend_website1/src/routes/services.index.tsx",
		children: void 0,
		preloads: [
			"/assets/services.index-CB6bXvZR.js",
			"/assets/arrow-up-right-ws7jlizM.js",
			"/assets/cta-band-BG9R-25G.js",
			"/assets/reveal-WL2P4jPb.js",
			"/assets/page-hero-D2urCon_.js",
			"/assets/placeholders-D7-QZQe-.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
