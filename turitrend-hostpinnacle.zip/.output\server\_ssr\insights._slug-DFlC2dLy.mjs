import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights._slug-DFlC2dLy.js
var $$splitComponentImporter = () => import("./insights._slug-IVB1ynvL.mjs");
var Route = createFileRoute("/insights/$slug")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
