globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/about-B4f_WTNH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4115-7hnMJftaZCYWTo1aIduGRssLu3A\"",
		"mtime": "2026-10-13T16:29:18.433Z",
		"size": 16661,
		"path": "../public/assets/about-B4f_WTNH.js"
	},
	"/assets/arrow-left-BeWaAL_x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-T9Cve/3ILRucwif2kqynIXRwLOc\"",
		"mtime": "2026-10-13T16:29:18.443Z",
		"size": 154,
		"path": "../public/assets/arrow-left-BeWaAL_x.js"
	},
	"/assets/accordion-Cn5es3Ul.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"60af-eV6+YNHpcD3kjJnzcUZrHJl06Nc\"",
		"mtime": "2026-10-13T16:29:18.433Z",
		"size": 24751,
		"path": "../public/assets/accordion-Cn5es3Ul.js"
	},
	"/assets/arrow-right-BkslHduy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-hwYb3utQ9h06b84WE9BO0VuiMrw\"",
		"mtime": "2026-10-13T16:29:18.445Z",
		"size": 154,
		"path": "../public/assets/arrow-right-BkslHduy.js"
	},
	"/assets/arrow-up-right-ws7jlizM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9c-W6MIZnv+Dq6z90DeZOQH6FG+D2M\"",
		"mtime": "2026-10-13T16:29:18.445Z",
		"size": 156,
		"path": "../public/assets/arrow-up-right-ws7jlizM.js"
	},
	"/assets/blueprint-lines-CmX7cIbn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c-tVCwpWyO5TB9j1Kg/5Azrc1X/NU\"",
		"mtime": "2026-10-13T16:29:18.447Z",
		"size": 60,
		"path": "../public/assets/blueprint-lines-CmX7cIbn.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-09-07T08:43:27.768Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"59cc-gYuOy1TZ7yGGIUof1k2HIPLDpVs\"",
		"mtime": "2026-09-07T08:43:27.767Z",
		"size": 22988,
		"path": "../public/favicon.png"
	},
	"/assets/check-CRrS2zSL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"71-yUmhQRnM7LlQEEbG7o+JaCPix+4\"",
		"mtime": "2026-10-13T16:29:18.449Z",
		"size": 113,
		"path": "../public/assets/check-CRrS2zSL.js"
	},
	"/assets/contact-BT4ZLrzp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"184b-4ZdpBSq3k24n5kfiLQ6SFInlrIg\"",
		"mtime": "2026-10-13T16:29:18.449Z",
		"size": 6219,
		"path": "../public/assets/contact-BT4ZLrzp.js"
	},
	"/assets/cta-band-BG9R-25G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"46a-M5mvEzcMpdGbmFkFtcbr+rP5BxA\"",
		"mtime": "2026-10-13T16:29:18.449Z",
		"size": 1130,
		"path": "../public/assets/cta-band-BG9R-25G.js"
	},
	"/assets/enquiry.functions-Dzy01iyp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11b1-HKNXi6Jfi78EFTHfm1SoGdEvTaY\"",
		"mtime": "2026-10-13T16:29:18.451Z",
		"size": 4529,
		"path": "../public/assets/enquiry.functions-Dzy01iyp.js"
	},
	"/assets/faqs-CZ8WsDAQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d11-ueeur/94H+g9I+srhL2R7y2HbV0\"",
		"mtime": "2026-10-13T16:29:18.451Z",
		"size": 3345,
		"path": "../public/assets/faqs-CZ8WsDAQ.js"
	},
	"/assets/how-we-work-BeRW52TL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dec-/2jvst2/BWUZDb1oB29mI9ZFIJA\"",
		"mtime": "2026-10-13T16:29:18.451Z",
		"size": 3564,
		"path": "../public/assets/how-we-work-BeRW52TL.js"
	},
	"/assets/insights-CeU3_Q_M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1196-L5CkoXvhoV0ARxDenOeGGXUBw1k\"",
		"mtime": "2026-10-13T16:29:18.456Z",
		"size": 4502,
		"path": "../public/assets/insights-CeU3_Q_M.js"
	},
	"/assets/insights-CMPDyGl7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-8hIgJDL/xdYRbNhI648c2XocKzs\"",
		"mtime": "2026-10-13T16:29:18.454Z",
		"size": 151,
		"path": "../public/assets/insights-CMPDyGl7.js"
	},
	"/assets/insights.index-DH8-_wDA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c6d-5/+4lyEpt1PjaChRRoufq++mYQw\"",
		"mtime": "2026-10-13T16:29:18.456Z",
		"size": 3181,
		"path": "../public/assets/insights.index-DH8-_wDA.js"
	},
	"/assets/index-DyP7_x9B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5d561-uyJsWVe7SMQ79f7u1oUTAzfqevM\"",
		"mtime": "2026-10-13T16:29:18.431Z",
		"size": 382305,
		"path": "../public/assets/index-DyP7_x9B.js"
	},
	"/assets/insights._slug-DBNHJEYQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f0b-5IfeLel56Yjzn8hilz8i6uCVYo4\"",
		"mtime": "2026-10-13T16:29:18.456Z",
		"size": 3851,
		"path": "../public/assets/insights._slug-DBNHJEYQ.js"
	},
	"/assets/blueprint-lines-nL0mkxgi.jpg": {
		"type": "image/jpeg",
		"etag": "\"127b9-z3h35D+2vtzGDnKip6vSwygFqJs\"",
		"mtime": "2026-10-13T16:29:18.483Z",
		"size": 75705,
		"path": "../public/assets/blueprint-lines-nL0mkxgi.jpg"
	},
	"/assets/link-CSxX31-N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e68-MSNLjLS4WLs9aK11vVq7oK6HG/w\"",
		"mtime": "2026-10-13T16:29:18.467Z",
		"size": 7784,
		"path": "../public/assets/link-CSxX31-N.js"
	},
	"/assets/hero-construction-DyKaLMTn.jpg": {
		"type": "image/jpeg",
		"etag": "\"18e90-aMJE2qVyfqI8TTF73v/6eak/4Ww\"",
		"mtime": "2026-10-13T16:29:18.485Z",
		"size": 102032,
		"path": "../public/assets/hero-construction-DyKaLMTn.jpg"
	},
	"/assets/hero-architecture-DmdUpQVN.jpg": {
		"type": "image/jpeg",
		"etag": "\"4c51b-z5OTWMvqb4fBAJCmpZF/QwnQNAM\"",
		"mtime": "2026-10-13T16:29:18.483Z",
		"size": 312603,
		"path": "../public/assets/hero-architecture-DmdUpQVN.jpg"
	},
	"/assets/logo1-CAT8vbKs.png": {
		"type": "image/png",
		"etag": "\"70d4f-7a6K1ZUIVDiMrf6ygyUliMEDNhA\"",
		"mtime": "2026-10-13T16:29:18.485Z",
		"size": 462159,
		"path": "../public/assets/logo1-CAT8vbKs.png"
	},
	"/assets/aboutus1-x_y0PJyX.jpg": {
		"type": "image/jpeg",
		"etag": "\"f4f03-eayGe2KxsAEtpPF4zFs+SR5NOeY\"",
		"mtime": "2026-10-13T16:29:18.483Z",
		"size": 1003267,
		"path": "../public/assets/aboutus1-x_y0PJyX.jpg"
	},
	"/assets/matchContext-DcmkPtE7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-Mhvuh2b3KkHkrxQcRpD1fle7X/Q\"",
		"mtime": "2026-10-13T16:29:18.467Z",
		"size": 159,
		"path": "../public/assets/matchContext-DcmkPtE7.js"
	},
	"/assets/not-found-i5RsCZif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-Trmr7GZIBZuvfg4uM18tBiRtOXg\"",
		"mtime": "2026-10-13T16:29:18.467Z",
		"size": 118,
		"path": "../public/assets/not-found-i5RsCZif.js"
	},
	"/assets/placeholders-D7-QZQe-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"473-bAw1NVvbqFMH3flE+VOLKi7W7DI\"",
		"mtime": "2026-10-13T16:29:18.471Z",
		"size": 1139,
		"path": "../public/assets/placeholders-D7-QZQe-.js"
	},
	"/assets/page-hero-D2urCon_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"650-lDfVl27I+ofTPFRgLDkY2sZ+90E\"",
		"mtime": "2026-10-13T16:29:18.469Z",
		"size": 1616,
		"path": "../public/assets/page-hero-D2urCon_.js"
	},
	"/assets/project-PBWhjMT7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2803-3vR8PJqf6NqN2O/0STrEAopXtNo\"",
		"mtime": "2026-10-13T16:29:18.471Z",
		"size": 10243,
		"path": "../public/assets/project-PBWhjMT7.js"
	},
	"/assets/project-placeholder-2-1ylxr1Kq.jpg": {
		"type": "image/jpeg",
		"etag": "\"14649-fKZ6vUu9R1a/xmEnwNzKZlkJFUk\"",
		"mtime": "2026-10-13T16:29:18.487Z",
		"size": 83529,
		"path": "../public/assets/project-placeholder-2-1ylxr1Kq.jpg"
	},
	"/assets/projects-CMPDyGl7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-8hIgJDL/xdYRbNhI648c2XocKzs\"",
		"mtime": "2026-10-13T16:29:18.471Z",
		"size": 151,
		"path": "../public/assets/projects-CMPDyGl7.js"
	},
	"/assets/project-placeholder-1-COgSgIrE.jpg": {
		"type": "image/jpeg",
		"etag": "\"26245-CdrzXrzaup+ITEWYVfS+SeHNqpU\"",
		"mtime": "2026-10-13T16:29:18.487Z",
		"size": 156229,
		"path": "../public/assets/project-placeholder-1-COgSgIrE.jpg"
	},
	"/assets/process-planning-BE6SJAs2.jpg": {
		"type": "image/jpeg",
		"etag": "\"33bb0-WSDE9YFXKWBlwunz2jtKeIL3YO4\"",
		"mtime": "2026-10-13T16:29:18.485Z",
		"size": 211888,
		"path": "../public/assets/process-planning-BE6SJAs2.jpg"
	},
	"/assets/projects.index-Dv0o7EZA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e14-LcMG7WD5aOJxHJUD8euEIDStgVk\"",
		"mtime": "2026-10-13T16:29:18.473Z",
		"size": 3604,
		"path": "../public/assets/projects.index-Dv0o7EZA.js"
	},
	"/assets/projects._slug-BAP6lkwb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1906-1ND6CP4nDdaFJ93Cbq/A0yvO6Bo\"",
		"mtime": "2026-10-13T16:29:18.471Z",
		"size": 6406,
		"path": "../public/assets/projects._slug-BAP6lkwb.js"
	},
	"/assets/project-placeholder-3-BTK0WFDa.jpg": {
		"type": "image/jpeg",
		"etag": "\"23b1c-0XGFiE6Hkf3iYBdq6nK8hbfcZ40\"",
		"mtime": "2026-10-13T16:29:18.487Z",
		"size": 146204,
		"path": "../public/assets/project-placeholder-3-BTK0WFDa.jpg"
	},
	"/assets/quote-CqWq2-Vv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2651-T+hAtdED/vPKUQii28q3uWZKqEo\"",
		"mtime": "2026-10-13T16:29:18.473Z",
		"size": 9809,
		"path": "../public/assets/quote-CqWq2-Vv.js"
	},
	"/assets/redirect-Dhm19zUi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f4-ePZWCXP5uehkmkGMkMl5xDch+/Y\"",
		"mtime": "2026-10-13T16:29:18.473Z",
		"size": 500,
		"path": "../public/assets/redirect-Dhm19zUi.js"
	},
	"/assets/reveal-WL2P4jPb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"286-riUEfYlbmeCdS3ZhFg71Oc84zds\"",
		"mtime": "2026-10-13T16:29:18.473Z",
		"size": 646,
		"path": "../public/assets/reveal-WL2P4jPb.js"
	},
	"/assets/routes-CGTPfqyH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3fae-njQU4QsDxaS76YieZ61UBS1XB3Y\"",
		"mtime": "2026-10-13T16:29:18.475Z",
		"size": 16302,
		"path": "../public/assets/routes-CGTPfqyH.js"
	},
	"/assets/service-building-CQw4dWYd.jpg": {
		"type": "image/jpeg",
		"etag": "\"12d38-VTeVv07v4+ml1q3rpQ1oPdG5Mrw\"",
		"mtime": "2026-10-13T16:29:18.489Z",
		"size": 77112,
		"path": "../public/assets/service-building-CQw4dWYd.jpg"
	},
	"/assets/section-heading-Ct52sk2A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"367-Hj8qgDa7Jsv0NaJ1BkIMqKAmu4I\"",
		"mtime": "2026-10-13T16:29:18.475Z",
		"size": 871,
		"path": "../public/assets/section-heading-Ct52sk2A.js"
	},
	"/assets/service-biodigester-BjG2Orh7.jpg": {
		"type": "image/jpeg",
		"etag": "\"3c120-6eS8LD8AISqwoMC9ilOK7LNg2Sk\"",
		"mtime": "2026-10-13T16:29:18.489Z",
		"size": 246048,
		"path": "../public/assets/service-biodigester-BjG2Orh7.jpg"
	},
	"/assets/service-fences-BGc-bXo-.jpg": {
		"type": "image/jpeg",
		"etag": "\"185f5-hKMv08ZAkJhpqOzT3GSpAtkAHXs\"",
		"mtime": "2026-10-13T16:29:18.489Z",
		"size": 99829,
		"path": "../public/assets/service-fences-BGc-bXo-.jpg"
	},
	"/assets/services.index-CB6bXvZR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e3c-XFQSUUf8MmZkHxYMYkLqwanktfQ\"",
		"mtime": "2026-10-13T16:29:18.481Z",
		"size": 3644,
		"path": "../public/assets/services.index-CB6bXvZR.js"
	},
	"/assets/service-renovations-aWb-S1df.jpg": {
		"type": "image/jpeg",
		"etag": "\"11c4a-v2t8FjsU6cqwie4wozEgSdYxaCE\"",
		"mtime": "2026-10-13T16:29:18.491Z",
		"size": 72778,
		"path": "../public/assets/service-renovations-aWb-S1df.jpg"
	},
	"/assets/service-management-C84caurY.jpg": {
		"type": "image/jpeg",
		"etag": "\"13081-Neo+amC18qoj4oUOuEJ6Qq0daqg\"",
		"mtime": "2026-10-13T16:29:18.491Z",
		"size": 77953,
		"path": "../public/assets/service-management-C84caurY.jpg"
	},
	"/assets/service-infrastructure-CsYHMo1x.jpg": {
		"type": "image/jpeg",
		"etag": "\"45d54-WDKqj0DzrdpUZKkvwnNs5sZkICQ\"",
		"mtime": "2026-10-13T16:29:18.491Z",
		"size": 286036,
		"path": "../public/assets/service-infrastructure-CsYHMo1x.jpg"
	},
	"/assets/services._slug-Dj0dN6rG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d07-C81aT6qAbXb8mB4sz+fOGJDNzMs\"",
		"mtime": "2026-10-13T16:29:18.477Z",
		"size": 7431,
		"path": "../public/assets/services._slug-Dj0dN6rG.js"
	},
	"/assets/shield-check-ClZb1RKx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"461-JjKfuyUIp96noD+NvHIwM6dOWsc\"",
		"mtime": "2026-10-13T16:29:18.481Z",
		"size": 1121,
		"path": "../public/assets/shield-check-ClZb1RKx.js"
	},
	"/assets/styles-hQhEHVxV.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"145bf-PP3HdH34KDJHco2o24q4oK0D3V8\"",
		"mtime": "2026-10-13T16:29:18.491Z",
		"size": 83391,
		"path": "../public/assets/styles-hQhEHVxV.css"
	},
	"/assets/useStore-B9WcefOa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ba9-DyLG3MsOxLBofb+Ep/+VkQIRI0g\"",
		"mtime": "2026-10-13T16:29:18.481Z",
		"size": 27561,
		"path": "../public/assets/useStore-B9WcefOa.js"
	},
	"/images/projects/biodigester/biodigester1/image2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1a93e-nJZybaNmyb+88JboHoqpbtljw1o\"",
		"mtime": "2026-09-09T06:41:15.497Z",
		"size": 108862,
		"path": "../public/images/projects/biodigester/biodigester1/image2.jpeg"
	},
	"/images/projects/biodigester/biodigester1/image1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2d686-k4YooS7YTFZHD5DAo7rHfoIvdL4\"",
		"mtime": "2026-09-09T06:41:15.486Z",
		"size": 185990,
		"path": "../public/images/projects/biodigester/biodigester1/image1.jpeg"
	},
	"/images/projects/biodigester/biodigester1/image3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"16754-8bvzICQ5C0dpAtzpkVLZ8ucbE7s\"",
		"mtime": "2026-09-09T06:41:15.503Z",
		"size": 91988,
		"path": "../public/images/projects/biodigester/biodigester1/image3.jpeg"
	},
	"/images/projects/biodigester/biodigester1/image4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2dcd6-lyQ2qL0XWujye1u98k81Ka+x3zM\"",
		"mtime": "2026-09-09T06:41:15.514Z",
		"size": 187606,
		"path": "../public/images/projects/biodigester/biodigester1/image4.jpeg"
	},
	"/images/projects/biodigester/biodigester1/image5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"126a5-G3mQfIDE0lbM5YQem1pMfH9+S54\"",
		"mtime": "2026-09-09T06:41:15.536Z",
		"size": 75429,
		"path": "../public/images/projects/biodigester/biodigester1/image5.jpeg"
	},
	"/images/projects/biodigester/biodigester1/image7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"13a73-zqnTpppB+cHy+/RfQgXjlDzZHVs\"",
		"mtime": "2026-09-09T06:41:15.559Z",
		"size": 80499,
		"path": "../public/images/projects/biodigester/biodigester1/image7.jpeg"
	},
	"/images/projects/building/building-project-1/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"11ccd-5b9mv/usJyUG/5R2SOJhzeMEynU\"",
		"mtime": "2026-09-09T06:44:32.274Z",
		"size": 72909,
		"path": "../public/images/projects/building/building-project-1/img1.jpeg"
	},
	"/images/projects/building/building-project-1/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"d47d-krNxQQpm22LCxQznhlNiv+R1P9s\"",
		"mtime": "2026-09-09T06:44:32.393Z",
		"size": 54397,
		"path": "../public/images/projects/building/building-project-1/img11.jpeg"
	},
	"/images/projects/biodigester/biodigester1/image6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"eaf0-tVoLiLa7gs+aRxyS4o8fHPRUk1Y\"",
		"mtime": "2026-09-09T06:41:15.547Z",
		"size": 60144,
		"path": "../public/images/projects/biodigester/biodigester1/image6.jpeg"
	},
	"/images/projects/building/building-project-1/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2324b-wtt0Veq+X+VAgOp15Oi6KFpCGrU\"",
		"mtime": "2026-09-09T06:44:32.379Z",
		"size": 143947,
		"path": "../public/images/projects/building/building-project-1/img10.jpeg"
	},
	"/images/projects/building/building-project-1/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"194c7-H8MbzeLHmBBMXp2IYkmUBkulCrY\"",
		"mtime": "2026-09-09T06:44:32.400Z",
		"size": 103623,
		"path": "../public/images/projects/building/building-project-1/img12.jpeg"
	},
	"/images/projects/building/building-project-1/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2ff39-qR1f7lqrzshq+3maTYY3J/ui3v8\"",
		"mtime": "2026-09-09T06:44:32.410Z",
		"size": 196409,
		"path": "../public/images/projects/building/building-project-1/img13.jpeg"
	},
	"/images/projects/building/building-project-1/img14.jpeg": {
		"type": "image/jpeg",
		"etag": "\"f005-mEJOj+Z19UlIS6egNIUV4nBaZQs\"",
		"mtime": "2026-09-09T06:44:32.430Z",
		"size": 61445,
		"path": "../public/images/projects/building/building-project-1/img14.jpeg"
	},
	"/images/projects/building/building-project-1/img15.jpeg": {
		"type": "image/jpeg",
		"etag": "\"24fd8-fktFuhtEYrbSC1ZhhqQScB+7MxM\"",
		"mtime": "2026-09-09T06:44:32.441Z",
		"size": 151512,
		"path": "../public/images/projects/building/building-project-1/img15.jpeg"
	},
	"/images/projects/building/building-project-1/img16.jpeg": {
		"type": "image/jpeg",
		"etag": "\"14078-RL/JI1M98/xdTyC866/KNlfTg34\"",
		"mtime": "2026-09-09T06:44:32.447Z",
		"size": 82040,
		"path": "../public/images/projects/building/building-project-1/img16.jpeg"
	},
	"/images/projects/building/building-project-1/img17.jpeg": {
		"type": "image/jpeg",
		"etag": "\"29044-1MudjK6ovvFn6GzF2o+AF5xeFec\"",
		"mtime": "2026-09-09T06:44:32.466Z",
		"size": 168004,
		"path": "../public/images/projects/building/building-project-1/img17.jpeg"
	},
	"/images/projects/building/building-project-1/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"13731-ukdQHunOXWfd8VKlhzg6+1l7Qp8\"",
		"mtime": "2026-09-09T06:44:32.287Z",
		"size": 79665,
		"path": "../public/images/projects/building/building-project-1/img2.jpeg"
	},
	"/images/projects/building/building-project-1/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"34c1f-PosnwPgMHJRyv2IDgVmcNgLIbLc\"",
		"mtime": "2026-09-09T06:44:32.301Z",
		"size": 216095,
		"path": "../public/images/projects/building/building-project-1/img3.jpeg"
	},
	"/assets/texture-concrete-BtuPXH0p.jpg": {
		"type": "image/jpeg",
		"etag": "\"12b685-Q1muYOhOZXBrqm8KJ7Mv/lPY3GI\"",
		"mtime": "2026-10-13T16:29:18.493Z",
		"size": 1226373,
		"path": "../public/assets/texture-concrete-BtuPXH0p.jpg"
	},
	"/images/projects/building/building-project-1/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"e67f-Vp/6/NBrWOxDRm6nWFbyDS7hRLQ\"",
		"mtime": "2026-09-09T06:44:32.308Z",
		"size": 59007,
		"path": "../public/images/projects/building/building-project-1/img4.jpeg"
	},
	"/images/projects/building/building-project-1/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"339bf-qO8ZgQFAtugGVaJP36Bs4sJX9tw\"",
		"mtime": "2026-09-09T06:44:32.325Z",
		"size": 211391,
		"path": "../public/images/projects/building/building-project-1/img5.jpeg"
	},
	"/images/projects/building/building-project-1/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"c016-NoCB57NUlS6ra4bs5H2w+GvOX6A\"",
		"mtime": "2026-09-09T06:44:32.338Z",
		"size": 49174,
		"path": "../public/images/projects/building/building-project-1/img6.jpeg"
	},
	"/images/projects/building/building-project-1/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"139a4-Tu4pXOq6bamVchCVOOHw9jUKmII\"",
		"mtime": "2026-09-09T06:44:32.355Z",
		"size": 80292,
		"path": "../public/images/projects/building/building-project-1/img8.jpeg"
	},
	"/images/projects/building/building-project-1/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"91f4-ULpn9CkIATjhz65q6AEP4n/Rn7g\"",
		"mtime": "2026-09-09T06:44:32.348Z",
		"size": 37364,
		"path": "../public/images/projects/building/building-project-1/img7.jpeg"
	},
	"/images/projects/building/building-project-1/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"e270-NRgEaUJ1ygTGuz7J6CwuZS2YxDs\"",
		"mtime": "2026-09-09T06:44:32.364Z",
		"size": 57968,
		"path": "../public/images/projects/building/building-project-1/img9.jpeg"
	},
	"/images/projects/building/building-project-3/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1be0c-K4jxgrDg47mwaNwXcdSrI7coq4A\"",
		"mtime": "2026-09-09T07:01:44.607Z",
		"size": 114188,
		"path": "../public/images/projects/building/building-project-3/img1.jpeg"
	},
	"/images/projects/building/building-project-3/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"21ba3-VD+8YecoalAWCIRAzPMEAE45Jf4\"",
		"mtime": "2026-09-09T07:01:44.621Z",
		"size": 138147,
		"path": "../public/images/projects/building/building-project-3/img2.jpeg"
	},
	"/images/projects/building/building-project-2/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5cba9-I7ZSB54qUhLoUBQouWSh3k4C/oI\"",
		"mtime": "2026-09-09T07:00:17.843Z",
		"size": 379817,
		"path": "../public/images/projects/building/building-project-2/img1.jpeg"
	},
	"/images/projects/building/building-project-2/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"30d39-3uRVH0E8JuH1XSiJmR4MLt7srLU\"",
		"mtime": "2026-09-09T07:00:17.994Z",
		"size": 199993,
		"path": "../public/images/projects/building/building-project-2/img10.jpeg"
	},
	"/images/insights/insight-1.jpg": {
		"type": "image/jpeg",
		"etag": "\"259252-tFptjwbDo6/lmtlKVCeXfuhNdFA\"",
		"mtime": "2026-09-11T17:28:26.172Z",
		"size": 2462290,
		"path": "../public/images/insights/insight-1.jpg"
	},
	"/images/projects/building/building-project-2/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5078f-46yd9f7ICGwiAKY8LBkDgsJ4Xtk\"",
		"mtime": "2026-09-09T07:00:18.010Z",
		"size": 329615,
		"path": "../public/images/projects/building/building-project-2/img11.jpeg"
	},
	"/images/projects/building/building-project-2/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2d141-vOAApRx5UjGeZo1SU3vL5kH0IuM\"",
		"mtime": "2026-09-09T07:00:18.040Z",
		"size": 184641,
		"path": "../public/images/projects/building/building-project-2/img13.jpeg"
	},
	"/images/projects/building/building-project-2/img14.jpeg": {
		"type": "image/jpeg",
		"etag": "\"46582-1VTdcwXSJwmsDEWZld53Domt0Ao\"",
		"mtime": "2026-09-09T07:00:18.056Z",
		"size": 288130,
		"path": "../public/images/projects/building/building-project-2/img14.jpeg"
	},
	"/images/projects/building/building-project-2/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"59192-4ANsHbZYeKmhkQwP/y2+u6HgowI\"",
		"mtime": "2026-09-09T07:00:18.027Z",
		"size": 364946,
		"path": "../public/images/projects/building/building-project-2/img12.jpeg"
	},
	"/images/projects/building/building-project-2/img15.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4791b-Xgeu5OFCYN1/oCCiEoCOIr1Y+IU\"",
		"mtime": "2026-09-09T07:00:18.070Z",
		"size": 293147,
		"path": "../public/images/projects/building/building-project-2/img15.jpeg"
	},
	"/images/projects/building/building-project-2/img16.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3d674-wqvSVpakBuzlBbVm1iex8SNTcfk\"",
		"mtime": "2026-09-09T07:00:18.085Z",
		"size": 251508,
		"path": "../public/images/projects/building/building-project-2/img16.jpeg"
	},
	"/images/projects/building/building-project-2/img18.jpeg": {
		"type": "image/jpeg",
		"etag": "\"28f80-XUIdeqVMdaRUKq2DJlRz0u2eDzE\"",
		"mtime": "2026-09-09T07:00:18.111Z",
		"size": 167808,
		"path": "../public/images/projects/building/building-project-2/img18.jpeg"
	},
	"/images/projects/building/building-project-2/img17.jpeg": {
		"type": "image/jpeg",
		"etag": "\"546a0-vtWkqiy2I1ajB1Fsu2aB3lDO2jc\"",
		"mtime": "2026-09-09T07:00:18.099Z",
		"size": 345760,
		"path": "../public/images/projects/building/building-project-2/img17.jpeg"
	},
	"/images/projects/building/building-project-2/img19.jpeg": {
		"type": "image/jpeg",
		"etag": "\"45895-KEbN7T2HRv5Vh52Fenh1zez2GVw\"",
		"mtime": "2026-09-09T07:00:18.126Z",
		"size": 284821,
		"path": "../public/images/projects/building/building-project-2/img19.jpeg"
	},
	"/images/projects/building/building-project-2/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"56e38-S7i1tYUyOdu9yDj5WlZoV2DCPa8\"",
		"mtime": "2026-09-09T07:00:17.863Z",
		"size": 355896,
		"path": "../public/images/projects/building/building-project-2/img2.jpeg"
	},
	"/images/projects/building/building-project-2/img20.jpeg": {
		"type": "image/jpeg",
		"etag": "\"340c6-Aiq5Zzrau+JgCt8OG6A5a+Zl3PI\"",
		"mtime": "2026-09-09T07:00:18.139Z",
		"size": 213190,
		"path": "../public/images/projects/building/building-project-2/img20.jpeg"
	},
	"/images/projects/building/building-project-2/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"57524-NH0bKG4FHnx4TAx6kOOhC2PrcYI\"",
		"mtime": "2026-09-09T07:00:17.881Z",
		"size": 357668,
		"path": "../public/images/projects/building/building-project-2/img3.jpeg"
	},
	"/images/projects/building/building-project-2/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"51644-R/gNXmJIu3MB7OdyLp/wqhCBmAk\"",
		"mtime": "2026-09-09T07:00:17.898Z",
		"size": 333380,
		"path": "../public/images/projects/building/building-project-2/img4.jpeg"
	},
	"/images/projects/building/building-project-2/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5121e-+EPS0rGG9SlRyqlsJGr49/4P6hE\"",
		"mtime": "2026-09-09T07:00:17.915Z",
		"size": 332318,
		"path": "../public/images/projects/building/building-project-2/img5.jpeg"
	},
	"/images/projects/building/building-project-2/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"61237-Psa+wZxrxt3f6g9tvfFVdbWb1o4\"",
		"mtime": "2026-09-09T07:00:17.932Z",
		"size": 397879,
		"path": "../public/images/projects/building/building-project-2/img6.jpeg"
	},
	"/images/projects/building/building-project-2/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"589aa-iQiLZu2qh9/TyWbl9KcryQNCb/k\"",
		"mtime": "2026-09-09T07:00:17.964Z",
		"size": 362922,
		"path": "../public/images/projects/building/building-project-2/img8.jpeg"
	},
	"/images/projects/building/building-project-4/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3b2a9-ty90vUD1fvPgwdrGioOfejTQyR0\"",
		"mtime": "2026-09-09T07:05:20.086Z",
		"size": 242345,
		"path": "../public/images/projects/building/building-project-4/img1.jpeg"
	},
	"/images/projects/building/building-project-2/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"47f2a-HEwj/pWxFw0Y2rk+jr/km7BDTWg\"",
		"mtime": "2026-09-09T07:00:17.947Z",
		"size": 294698,
		"path": "../public/images/projects/building/building-project-2/img7.jpeg"
	},
	"/images/projects/building/building-project-4/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2fc27-kkmK6mw/k1TChub/XkHXUa6WX8c\"",
		"mtime": "2026-09-09T07:05:20.099Z",
		"size": 195623,
		"path": "../public/images/projects/building/building-project-4/img2.jpeg"
	},
	"/images/projects/building/building-project-2/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5aab9-+HrLQkQPZwhWV+s0wzeR5OFxxZs\"",
		"mtime": "2026-09-09T07:00:17.980Z",
		"size": 371385,
		"path": "../public/images/projects/building/building-project-2/img9.jpeg"
	},
	"/images/projects/building/building-project-4/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2fc27-kkmK6mw/k1TChub/XkHXUa6WX8c\"",
		"mtime": "2026-09-09T07:05:20.132Z",
		"size": 195623,
		"path": "../public/images/projects/building/building-project-4/img4.jpeg"
	},
	"/images/projects/building/building-project-4/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3b2a9-ty90vUD1fvPgwdrGioOfejTQyR0\"",
		"mtime": "2026-09-09T07:05:20.116Z",
		"size": 242345,
		"path": "../public/images/projects/building/building-project-4/img3.jpeg"
	},
	"/images/projects/building/building-project-4/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2f0fa-Q2ksC154lXA4IVcUGOVkFotHUTE\"",
		"mtime": "2026-09-09T07:05:20.146Z",
		"size": 192762,
		"path": "../public/images/projects/building/building-project-4/img5.jpeg"
	},
	"/images/projects/building/building-project-4/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1b231-Hjt+Tb6dS7rlBdoZd3UzvUWUnHw\"",
		"mtime": "2026-09-19T20:30:18.828Z",
		"size": 111153,
		"path": "../public/images/projects/building/building-project-4/img6.jpeg"
	},
	"/images/projects/building/building-project-5/1img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4b02a-m5LGboR0S/qqG6QKgAPF35/qZwA\"",
		"mtime": "2026-09-09T07:07:21.837Z",
		"size": 307242,
		"path": "../public/images/projects/building/building-project-5/1img13.jpeg"
	},
	"/images/projects/building/building-project-5/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3ebaa-ugATWmxqxJWuTgeg4ZUq6p5GkDM\"",
		"mtime": "2026-09-09T07:07:21.668Z",
		"size": 256938,
		"path": "../public/images/projects/building/building-project-5/img1.jpeg"
	},
	"/images/projects/building/building-project-5/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3ebaa-ugATWmxqxJWuTgeg4ZUq6p5GkDM\"",
		"mtime": "2026-09-09T07:07:21.797Z",
		"size": 256938,
		"path": "../public/images/projects/building/building-project-5/img10.jpeg"
	},
	"/images/projects/building/building-project-5/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3ea93-02g4GtIizqIvWvjnh+i1oVIvJIw\"",
		"mtime": "2026-09-09T07:07:21.812Z",
		"size": 256659,
		"path": "../public/images/projects/building/building-project-5/img11.jpeg"
	},
	"/images/projects/building/building-project-5/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"46654-C/IVwhl5t/80YdmrlGR7TIgFeyQ\"",
		"mtime": "2026-09-09T07:07:21.685Z",
		"size": 288340,
		"path": "../public/images/projects/building/building-project-5/img2.jpeg"
	},
	"/images/projects/building/building-project-5/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"46654-C/IVwhl5t/80YdmrlGR7TIgFeyQ\"",
		"mtime": "2026-09-09T07:07:21.825Z",
		"size": 288340,
		"path": "../public/images/projects/building/building-project-5/img12.jpeg"
	},
	"/images/projects/building/building-project-5/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"30f0f-lhyLpri7IpbgKIDz1ClLgEm7KCA\"",
		"mtime": "2026-09-09T07:07:21.701Z",
		"size": 200463,
		"path": "../public/images/projects/building/building-project-5/img3.jpeg"
	},
	"/images/insights/insight-2.jpg": {
		"type": "image/jpeg",
		"etag": "\"47a1d3-YATClIw21dTg+PzabpIkkSNpQVY\"",
		"mtime": "2026-09-11T17:28:52.283Z",
		"size": 4694483,
		"path": "../public/images/insights/insight-2.jpg"
	},
	"/images/projects/building/building-project-5/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"30f0f-lhyLpri7IpbgKIDz1ClLgEm7KCA\"",
		"mtime": "2026-09-09T07:07:21.715Z",
		"size": 200463,
		"path": "../public/images/projects/building/building-project-5/img4.jpeg"
	},
	"/images/projects/building/building-project-5/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3838a-iCX1GSIRv1Pz1isZ/G/+UyKyKB4\"",
		"mtime": "2026-09-09T07:07:21.730Z",
		"size": 230282,
		"path": "../public/images/projects/building/building-project-5/img5.jpeg"
	},
	"/images/projects/building/building-project-5/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"38955-BvMu4WGoCFj1AEop7O4H6PH/ZUM\"",
		"mtime": "2026-09-09T07:07:21.756Z",
		"size": 231765,
		"path": "../public/images/projects/building/building-project-5/img7.jpeg"
	},
	"/images/projects/building/building-project-5/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"64b25-MXniEzQE6Vc4+vvDpIyaSLSq7mY\"",
		"mtime": "2026-09-09T07:07:21.744Z",
		"size": 412453,
		"path": "../public/images/projects/building/building-project-5/img6.jpeg"
	},
	"/images/projects/building/building-project-5/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"54fbf-p73nsjX1L5gGUBJjh15dELLlBio\"",
		"mtime": "2026-09-09T07:07:21.771Z",
		"size": 348095,
		"path": "../public/images/projects/building/building-project-5/img8.jpeg"
	},
	"/images/projects/building/building-project-5/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4e379-fpCCX5yiNdrQtJCClVZk1jp2K8c\"",
		"mtime": "2026-09-09T07:07:21.785Z",
		"size": 320377,
		"path": "../public/images/projects/building/building-project-5/img9.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"313b5-DHoeyChelznGVesEcRuCCCab8ak\"",
		"mtime": "2026-09-09T06:48:49.761Z",
		"size": 201653,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img1.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"31b47-yxbxT9qcy28aHsyCM2T+WM9QOzg\"",
		"mtime": "2026-09-09T06:48:49.889Z",
		"size": 203591,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img11.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2c368-wtg0n2cKv7wiY32sdumxsMx2n68\"",
		"mtime": "2026-09-09T06:48:49.877Z",
		"size": 181096,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img10.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"33da8-9DkklkcJ5OVaGhNCW/5SoXTId2Q\"",
		"mtime": "2026-09-09T06:48:49.914Z",
		"size": 212392,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img13.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"288b2-/B6l8VOjzwTb9Zy3Y0XzP4X10Js\"",
		"mtime": "2026-09-09T06:48:49.901Z",
		"size": 166066,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img12.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img15.jpeg": {
		"type": "image/jpeg",
		"etag": "\"12a98-gvF844TC8x5tPQXkrtyQb4QFBEQ\"",
		"mtime": "2026-09-09T06:48:49.935Z",
		"size": 76440,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img15.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img14.jpeg": {
		"type": "image/jpeg",
		"etag": "\"23f90-lTUz3z8+tTLkGa68kVKdcykPNco\"",
		"mtime": "2026-09-09T06:48:49.922Z",
		"size": 147344,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img14.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img16.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1c289-edpTpW3NGlOXD1blK7Z7ru2ofZQ\"",
		"mtime": "2026-09-09T06:48:49.950Z",
		"size": 115337,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img16.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img17.jpeg": {
		"type": "image/jpeg",
		"etag": "\"13cf4-oZROxhVB8EQt6Oa2H7V4bkWviJw\"",
		"mtime": "2026-09-09T06:48:49.959Z",
		"size": 81140,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img17.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img18.jpeg": {
		"type": "image/jpeg",
		"etag": "\"22ef8-y7+O3DSr3bvU12cAAZ+piXTb5+Q\"",
		"mtime": "2026-09-09T06:48:49.972Z",
		"size": 143096,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img18.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4ece-0aDiac6Fiv4+V+dFTsn7YD2XJhU\"",
		"mtime": "2026-09-09T06:48:49.776Z",
		"size": 20174,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img2.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img20.jpeg": {
		"type": "image/jpeg",
		"etag": "\"8b97-+dyW6oChPzTBlKCmn2CSqX4LEF0\"",
		"mtime": "2026-09-09T06:48:49.996Z",
		"size": 35735,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img20.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img21.jpeg": {
		"type": "image/jpeg",
		"etag": "\"85f5-WnRhrXF3GLHxSPI1jDV/n81uaOU\"",
		"mtime": "2026-09-09T06:48:50.003Z",
		"size": 34293,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img21.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img22.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4d07-h5bna3uaalrWzHqL2f6abk30Mfc\"",
		"mtime": "2026-09-09T06:48:50.020Z",
		"size": 19719,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img22.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img19.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3bd05-8EtDFDdOu4vEM5xdtCcbyhn2O20\"",
		"mtime": "2026-09-09T06:48:49.985Z",
		"size": 244997,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img19.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img23.jpeg": {
		"type": "image/jpeg",
		"etag": "\"24078-dK4ykuqFT4rSLw8NNeXX77ici+c\"",
		"mtime": "2026-09-09T06:48:50.033Z",
		"size": 147576,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img23.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img24.jpeg": {
		"type": "image/jpeg",
		"etag": "\"16854-/H+RyYmMJg7tftRlDG0ZpVbEKSY\"",
		"mtime": "2026-09-09T06:48:50.045Z",
		"size": 92244,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img24.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img25.jpeg": {
		"type": "image/jpeg",
		"etag": "\"ef62-S+u7e4VbVgaUSX6JzK42OrRWINg\"",
		"mtime": "2026-09-09T06:48:50.050Z",
		"size": 61282,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img25.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img26.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2676b-UxImftdMRmO5GONGtL4nudbkHxM\"",
		"mtime": "2026-09-09T06:48:50.061Z",
		"size": 157547,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img26.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img27.jpeg": {
		"type": "image/jpeg",
		"etag": "\"cf61-tzSVQcEGWF8SISbX5WsfWgyFkDE\"",
		"mtime": "2026-09-09T06:48:50.081Z",
		"size": 53089,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img27.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img28.jpeg": {
		"type": "image/jpeg",
		"etag": "\"7651-JB3YyeVDxHodOCg8POcLe/GKzu0\"",
		"mtime": "2026-09-09T06:48:50.093Z",
		"size": 30289,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img28.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img29.jpeg": {
		"type": "image/jpeg",
		"etag": "\"cf92-OIarXt+ZfFR/dKJYaj5v7NlpU/Y\"",
		"mtime": "2026-09-09T06:48:50.097Z",
		"size": 53138,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img29.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"fbb2-V1qPIltXD6rZWxZmy1+i+YIglX4\"",
		"mtime": "2026-09-09T06:48:49.789Z",
		"size": 64434,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img3.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img31.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2f94b-W+ZQPudJNS3oxu60/xPAodCGlek\"",
		"mtime": "2026-09-09T06:48:50.112Z",
		"size": 194891,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img31.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img32.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2cf1f-EZmeTgOKC+KVCCYu4XCX3rgsVqg\"",
		"mtime": "2026-09-09T06:48:50.130Z",
		"size": 184095,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img32.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img33.jpeg": {
		"type": "image/jpeg",
		"etag": "\"32ff6-cA4fLVOBxu8kREhrIyIdimdXtGU\"",
		"mtime": "2026-09-09T06:48:50.143Z",
		"size": 208886,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img33.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img34.jpeg": {
		"type": "image/jpeg",
		"etag": "\"377e4-auepHZKXEt/rmmJXhIB2UxF54kM\"",
		"mtime": "2026-09-09T06:48:50.159Z",
		"size": 227300,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img34.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img35.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2dd54-CjmzDQzAUhLechl+BGGoDYKZRmo\"",
		"mtime": "2026-09-09T06:48:50.159Z",
		"size": 187732,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img35.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img36.jpeg": {
		"type": "image/jpeg",
		"etag": "\"dfc2-gsbKh7RBKxRYoHFp6CkvZ/Ta3G4\"",
		"mtime": "2026-09-09T06:48:50.183Z",
		"size": 57282,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img36.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img37.jpeg": {
		"type": "image/jpeg",
		"etag": "\"34dc2-OLxNy+vavFFUQ+jDjKaZzCz/XE4\"",
		"mtime": "2026-09-09T06:48:50.198Z",
		"size": 216514,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img37.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img39.jpeg": {
		"type": "image/jpeg",
		"etag": "\"16aa6-ZBUonszWRl3QD1nAJEpMylvLbZg\"",
		"mtime": "2026-09-09T06:48:50.215Z",
		"size": 92838,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img39.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img40.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1523b-qwkqmP8pmqCOiw2U78HGZOl+kHM\"",
		"mtime": "2026-09-09T06:48:50.230Z",
		"size": 86587,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img40.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1523b-qwkqmP8pmqCOiw2U78HGZOl+kHM\"",
		"mtime": "2026-09-09T06:48:49.797Z",
		"size": 86587,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img4.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img38.jpeg": {
		"type": "image/jpeg",
		"etag": "\"137f3-wqCCnU8FgL6If+QkzeHqxbAq9Zs\"",
		"mtime": "2026-09-09T06:48:50.210Z",
		"size": 79859,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img38.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img42.jpeg": {
		"type": "image/jpeg",
		"etag": "\"e481-kCTjLffT4t6O8EipF79m5Vh8hOo\"",
		"mtime": "2026-09-09T06:48:50.246Z",
		"size": 58497,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img42.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img41.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1af12-tq8t9t09m6nSDyLdD7LL8VEUeKA\"",
		"mtime": "2026-09-09T06:48:50.240Z",
		"size": 110354,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img41.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img43.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3e3da-MOvV4yxAQqXHvNOMYUyedtaHn5o\"",
		"mtime": "2026-09-09T06:48:50.267Z",
		"size": 254938,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img43.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img44.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2e005-i5uw3yMrs1VAdIJJ/VgHzPwz+4I\"",
		"mtime": "2026-09-09T06:48:50.286Z",
		"size": 188421,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img44.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img45.jpeg": {
		"type": "image/jpeg",
		"etag": "\"13cf4-oZROxhVB8EQt6Oa2H7V4bkWviJw\"",
		"mtime": "2026-09-09T06:48:50.297Z",
		"size": 81140,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img45.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img46.jpeg": {
		"type": "image/jpeg",
		"etag": "\"155d9-MhGErdDzISonCRdofCabXDJUPt4\"",
		"mtime": "2026-09-09T06:48:50.310Z",
		"size": 87513,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img46.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img47.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1eb91-MX0/j8JsT+gHAalwIXNoc7XmnGw\"",
		"mtime": "2026-09-09T06:48:50.322Z",
		"size": 125841,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img47.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img48.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1c627-BpynrtwmxnH+0JddQpWdn5tfE9E\"",
		"mtime": "2026-09-09T06:48:50.331Z",
		"size": 116263,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img48.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img49.jpeg": {
		"type": "image/jpeg",
		"etag": "\"20f4d-kPM1hn5dll4G3/UoESYdc9OscLc\"",
		"mtime": "2026-09-09T06:48:50.344Z",
		"size": 134989,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img49.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"526b1-RJF+OCJYhujKNg/DcHQ+lzehOCI\"",
		"mtime": "2026-09-09T06:48:49.811Z",
		"size": 337585,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img5.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img50.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1828c-iQrsbm7euNvNgQN3NNeyjwOif4Q\"",
		"mtime": "2026-09-09T06:48:50.357Z",
		"size": 98956,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img50.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img51.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1c9f3-CB/SdehL/NMFa6eQWglcfvi1wVo\"",
		"mtime": "2026-09-09T06:48:50.357Z",
		"size": 117235,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img51.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img53.jpeg": {
		"type": "image/jpeg",
		"etag": "\"54ddd-BFfzcDVGLAh3NswC27g35kcNdrA\"",
		"mtime": "2026-09-09T06:48:50.407Z",
		"size": 347613,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img53.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img54.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1d963-Q97jbFlSgbxFEQxH5Y1/EBSx34I\"",
		"mtime": "2026-09-09T06:48:50.416Z",
		"size": 121187,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img54.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img57.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5e570-1QWUfohu9Aah6n+eHs4M1x3qj3U\"",
		"mtime": "2026-09-09T06:48:50.454Z",
		"size": 386416,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img57.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img56.jpeg": {
		"type": "image/jpeg",
		"etag": "\"6bc64-AJ+K8jsNlcp5i6PPclRWupGN6wg\"",
		"mtime": "2026-09-09T06:48:50.437Z",
		"size": 441444,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img56.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2eb7a-lCniz8ywKBjFxQVFYSEer/fCbzo\"",
		"mtime": "2026-09-09T06:48:49.839Z",
		"size": 191354,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img7.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1bf0f-V89pXyFGJdzCtjV2Xa2zMhhIoJQ\"",
		"mtime": "2026-09-09T06:48:49.823Z",
		"size": 114447,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img6.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img58.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5bc6a-cy6jNa5DwdHhnAmcDtLiir6avrU\"",
		"mtime": "2026-09-09T06:48:50.468Z",
		"size": 375914,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img58.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"29b66-e0yNvW7ZAoKP0tAoqetKbqpk6OQ\"",
		"mtime": "2026-09-09T06:48:49.846Z",
		"size": 170854,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img8.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"28faf-0bAjJPWqDQ95RYT4sDxsivMpyYw\"",
		"mtime": "2026-09-09T06:48:49.863Z",
		"size": 167855,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img9.jpeg"
	},
	"/images/projects/fences/fences1/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1be67-kGzPXdNpkR3HYZOb2jHlmp+oWZY\"",
		"mtime": "2026-09-09T07:06:43.382Z",
		"size": 114279,
		"path": "../public/images/projects/fences/fences1/img1.jpeg"
	},
	"/images/projects/fences/fences1/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2e73b-+UxOo5roGtBRgcvLWfePyjmBgto\"",
		"mtime": "2026-09-09T07:06:43.397Z",
		"size": 190267,
		"path": "../public/images/projects/fences/fences1/img2.jpeg"
	},
	"/images/projects/car-shades-gates/carshades-and-automation/img52.jpeg": {
		"type": "image/jpeg",
		"etag": "\"9d146-TZlB2MuJzt2mcM30e5cqv3NvNnE\"",
		"mtime": "2026-09-09T06:48:50.389Z",
		"size": 643398,
		"path": "../public/images/projects/car-shades-gates/carshades-and-automation/img52.jpeg"
	},
	"/images/projects/fences/fences1/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"30718-4AyUDTToI9M5OZFs1sA1eGyigug\"",
		"mtime": "2026-09-09T07:06:43.412Z",
		"size": 198424,
		"path": "../public/images/projects/fences/fences1/img3.jpeg"
	},
	"/images/projects/fences/fences1/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"275dc-NNI2nhDa6Z5X4q5ZgN9e/8ZxH9Q\"",
		"mtime": "2026-09-09T07:06:43.414Z",
		"size": 161244,
		"path": "../public/images/projects/fences/fences1/img4.jpeg"
	},
	"/images/projects/fences/fences1/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2d447-2Om+crJJjRcUQ6z4OfqLeBC/u8g\"",
		"mtime": "2026-09-09T07:06:43.428Z",
		"size": 185415,
		"path": "../public/images/projects/fences/fences1/img5.jpeg"
	},
	"/images/projects/fences/fences1/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"46236-UL6pKeHkbAWmJu+oU5nKW8dnhMA\"",
		"mtime": "2026-09-09T07:06:43.454Z",
		"size": 287286,
		"path": "../public/images/projects/fences/fences1/img6.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"269cf-akmxsLleMWYm/V5E84HegixVAWA\"",
		"mtime": "2026-09-09T07:04:20.804Z",
		"size": 158159,
		"path": "../public/images/projects/home-renovations/home-renovation1/img1.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"304b8-quUZK3SOXda9oCO5fjLGqAtfmIw\"",
		"mtime": "2026-09-09T07:04:20.925Z",
		"size": 197816,
		"path": "../public/images/projects/home-renovations/home-renovation1/img10.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"28160-ru8IWlkQrPld0her/TVCwyOjULU\"",
		"mtime": "2026-09-09T07:04:20.933Z",
		"size": 164192,
		"path": "../public/images/projects/home-renovations/home-renovation1/img11.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"269cf-akmxsLleMWYm/V5E84HegixVAWA\"",
		"mtime": "2026-09-09T07:04:20.950Z",
		"size": 158159,
		"path": "../public/images/projects/home-renovations/home-renovation1/img12.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2fbab-zBZ0bwfn/y02vsygZcst7eRsvA0\"",
		"mtime": "2026-09-09T07:04:20.963Z",
		"size": 195499,
		"path": "../public/images/projects/home-renovations/home-renovation1/img13.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img14.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1fe54-GIiDFvy7BBfR31mq0hGVWia6aQU\"",
		"mtime": "2026-09-09T07:04:20.974Z",
		"size": 130644,
		"path": "../public/images/projects/home-renovations/home-renovation1/img14.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img15.jpeg": {
		"type": "image/jpeg",
		"etag": "\"220cc-fmp6RqsQw4y5oEpjK/xvcerJxOo\"",
		"mtime": "2026-09-09T07:04:20.980Z",
		"size": 139468,
		"path": "../public/images/projects/home-renovations/home-renovation1/img15.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"304b8-quUZK3SOXda9oCO5fjLGqAtfmIw\"",
		"mtime": "2026-09-09T07:04:20.821Z",
		"size": 197816,
		"path": "../public/images/projects/home-renovations/home-renovation1/img2.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1fe54-GIiDFvy7BBfR31mq0hGVWia6aQU\"",
		"mtime": "2026-09-09T07:04:20.837Z",
		"size": 130644,
		"path": "../public/images/projects/home-renovations/home-renovation1/img3.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"220cc-fmp6RqsQw4y5oEpjK/xvcerJxOo\"",
		"mtime": "2026-09-09T07:04:20.849Z",
		"size": 139468,
		"path": "../public/images/projects/home-renovations/home-renovation1/img4.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2dc33-C8YPazFZki+epmuVjgAfgmkLKto\"",
		"mtime": "2026-09-09T07:04:20.861Z",
		"size": 187443,
		"path": "../public/images/projects/home-renovations/home-renovation1/img5.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"28160-ru8IWlkQrPld0her/TVCwyOjULU\"",
		"mtime": "2026-09-09T07:04:20.869Z",
		"size": 164192,
		"path": "../public/images/projects/home-renovations/home-renovation1/img6.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2fb15-hgfsqzxVgmABsT+7wu7JR11fFKo\"",
		"mtime": "2026-09-09T07:04:20.878Z",
		"size": 195349,
		"path": "../public/images/projects/home-renovations/home-renovation1/img7.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2fbab-zBZ0bwfn/y02vsygZcst7eRsvA0\"",
		"mtime": "2026-09-09T07:04:20.909Z",
		"size": 195499,
		"path": "../public/images/projects/home-renovations/home-renovation1/img9.jpeg"
	},
	"/images/projects/home-renovations/home-renovation1/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"304b8-quUZK3SOXda9oCO5fjLGqAtfmIw\"",
		"mtime": "2026-09-09T07:04:20.898Z",
		"size": 197816,
		"path": "../public/images/projects/home-renovations/home-renovation1/img8.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/1mg13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"359bb-OAMpYEWKyH0Xkl7HglpWGaskOME\"",
		"mtime": "2026-09-09T07:04:51.584Z",
		"size": 219579,
		"path": "../public/images/projects/home-renovations/home-renovation2/1mg13.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"226f2-9D8NzIxls/EJBP49+3lzS7ZDotI\"",
		"mtime": "2026-09-09T07:04:51.537Z",
		"size": 141042,
		"path": "../public/images/projects/home-renovations/home-renovation2/img10.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"28b74-frk7or3aSWwj0phmS1U3vocBMao\"",
		"mtime": "2026-09-09T07:04:51.559Z",
		"size": 166772,
		"path": "../public/images/projects/home-renovations/home-renovation2/img1.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1fb44-fRuzcBxjjDGYjx8FSO1YQQolnZ0\"",
		"mtime": "2026-09-09T07:04:51.548Z",
		"size": 129860,
		"path": "../public/images/projects/home-renovations/home-renovation2/img11.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"21700-Cc/locU31MugKJo8SvoPej0WWf8\"",
		"mtime": "2026-09-09T07:04:51.568Z",
		"size": 136960,
		"path": "../public/images/projects/home-renovations/home-renovation2/img12.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3f8af-PcycWKzgpr/KNgL0gwEVbMhN3rY\"",
		"mtime": "2026-09-09T07:04:51.593Z",
		"size": 260271,
		"path": "../public/images/projects/home-renovations/home-renovation2/img13.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img14.jpeg": {
		"type": "image/jpeg",
		"etag": "\"251c7-1fU3jR9RjPXLLvbT1KKu0CqxDOo\"",
		"mtime": "2026-09-09T07:04:51.610Z",
		"size": 152007,
		"path": "../public/images/projects/home-renovations/home-renovation2/img14.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img15.jpeg": {
		"type": "image/jpeg",
		"etag": "\"27ee7-QzjCQnmpw+2Nkm8QNY177g3+8fE\"",
		"mtime": "2026-09-09T07:04:51.622Z",
		"size": 163559,
		"path": "../public/images/projects/home-renovations/home-renovation2/img15.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img16.jpeg": {
		"type": "image/jpeg",
		"etag": "\"17ec3-0tlnZC29SN7uYraCTTjd1KImEj8\"",
		"mtime": "2026-09-09T07:04:51.633Z",
		"size": 97987,
		"path": "../public/images/projects/home-renovations/home-renovation2/img16.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img17.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2b0f1-r35sWpX32l+lYvFuO4sjS6vT+MM\"",
		"mtime": "2026-09-09T07:04:51.645Z",
		"size": 176369,
		"path": "../public/images/projects/home-renovations/home-renovation2/img17.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img18.jpeg": {
		"type": "image/jpeg",
		"etag": "\"17798-I4l2gEcvw1DgbcyzsEE7iaoDebQ\"",
		"mtime": "2026-09-09T07:04:51.653Z",
		"size": 96152,
		"path": "../public/images/projects/home-renovations/home-renovation2/img18.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img19.jpeg": {
		"type": "image/jpeg",
		"etag": "\"19683-357Mnw3xbFuZ+K7im7UWLcUFzPA\"",
		"mtime": "2026-09-09T07:04:51.667Z",
		"size": 104067,
		"path": "../public/images/projects/home-renovations/home-renovation2/img19.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"15ebb-DLPZJqL0VV5eZXkgehgh5pLrsy8\"",
		"mtime": "2026-09-09T07:04:51.437Z",
		"size": 89787,
		"path": "../public/images/projects/home-renovations/home-renovation2/img2.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img20.jpeg": {
		"type": "image/jpeg",
		"etag": "\"23971-gH1SbEw3XZBa2PkLK9bQ6JR2drk\"",
		"mtime": "2026-09-09T07:04:51.680Z",
		"size": 145777,
		"path": "../public/images/projects/home-renovations/home-renovation2/img20.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img21.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1342b-GDQjA8jEXWW6nABCjseuAic5vb8\"",
		"mtime": "2026-09-09T07:04:51.692Z",
		"size": 78891,
		"path": "../public/images/projects/home-renovations/home-renovation2/img21.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img24.jpeg": {
		"type": "image/jpeg",
		"etag": "\"d3de-O+1GC+0hfxy0L7yl6Y0MDuhSOwE\"",
		"mtime": "2026-09-09T07:04:51.720Z",
		"size": 54238,
		"path": "../public/images/projects/home-renovations/home-renovation2/img24.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img23.jpeg": {
		"type": "image/jpeg",
		"etag": "\"16ff8-pSA+aKrBq7NLiseIQyGVwG5cK3M\"",
		"mtime": "2026-09-09T07:04:51.717Z",
		"size": 94200,
		"path": "../public/images/projects/home-renovations/home-renovation2/img23.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img22.jpeg": {
		"type": "image/jpeg",
		"etag": "\"32dcc-SGYaBwjLgu8IYyvwALCwXdMKqZg\"",
		"mtime": "2026-09-09T07:04:51.703Z",
		"size": 208332,
		"path": "../public/images/projects/home-renovations/home-renovation2/img22.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img26.jpeg": {
		"type": "image/jpeg",
		"etag": "\"fa15-GQp9+NtLabWx4kcN6h5i2KYMg/g\"",
		"mtime": "2026-09-09T07:04:51.749Z",
		"size": 64021,
		"path": "../public/images/projects/home-renovations/home-renovation2/img26.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img25.jpeg": {
		"type": "image/jpeg",
		"etag": "\"19dc4-qljNst+wKeEyuiAUiin1fI0w49k\"",
		"mtime": "2026-09-09T07:04:51.736Z",
		"size": 105924,
		"path": "../public/images/projects/home-renovations/home-renovation2/img25.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img27.jpeg": {
		"type": "image/jpeg",
		"etag": "\"15278-esP+Y6R7vSeneBIOxxkjoNO8E+M\"",
		"mtime": "2026-09-09T07:04:51.765Z",
		"size": 86648,
		"path": "../public/images/projects/home-renovations/home-renovation2/img27.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img28.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1234b-r4Rnrhjs2EUfYrp/HMcq+n9mfjk\"",
		"mtime": "2026-09-09T07:04:51.768Z",
		"size": 74571,
		"path": "../public/images/projects/home-renovations/home-renovation2/img28.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img29.jpeg": {
		"type": "image/jpeg",
		"etag": "\"10ea5-6sGNRRW1PxakexyCwLcKqq3+2sI\"",
		"mtime": "2026-09-09T07:04:51.785Z",
		"size": 69285,
		"path": "../public/images/projects/home-renovations/home-renovation2/img29.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img30.jpeg": {
		"type": "image/jpeg",
		"etag": "\"e582-HYWsfxCwarLdo7fZDhL/TQzSa6M\"",
		"mtime": "2026-09-09T07:04:51.797Z",
		"size": 58754,
		"path": "../public/images/projects/home-renovations/home-renovation2/img30.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"157cd-2+I3B8SqKTORfGdjoqdsdjylbk4\"",
		"mtime": "2026-09-09T07:04:51.452Z",
		"size": 88013,
		"path": "../public/images/projects/home-renovations/home-renovation2/img3.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img31.jpeg": {
		"type": "image/jpeg",
		"etag": "\"40dfa-tnNaSGLbjklcAKuzkjyDJRtRPNg\"",
		"mtime": "2026-09-09T07:04:51.815Z",
		"size": 265722,
		"path": "../public/images/projects/home-renovations/home-renovation2/img31.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img32.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5b657-fIUd13mV376IGa3DJWDpp9A5aew\"",
		"mtime": "2026-09-09T07:04:51.831Z",
		"size": 374359,
		"path": "../public/images/projects/home-renovations/home-renovation2/img32.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img33.jpeg": {
		"type": "image/jpeg",
		"etag": "\"47d2c-Ydgj1C24t4zmU8OxQ7y80CsVUYk\"",
		"mtime": "2026-09-09T07:04:51.844Z",
		"size": 294188,
		"path": "../public/images/projects/home-renovations/home-renovation2/img33.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img34.jpeg": {
		"type": "image/jpeg",
		"etag": "\"14b68-s7gTO7srL5GG6nO3IvY++zM65ww\"",
		"mtime": "2026-09-09T07:04:51.849Z",
		"size": 84840,
		"path": "../public/images/projects/home-renovations/home-renovation2/img34.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img35.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4783c-AKVYf6lSDl2C0SCNbCO3vKLOW3k\"",
		"mtime": "2026-09-09T07:04:51.870Z",
		"size": 292924,
		"path": "../public/images/projects/home-renovations/home-renovation2/img35.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img37.jpeg": {
		"type": "image/jpeg",
		"etag": "\"cf61-Qnv9uyyITGK3A0+zW3KNThrK/zA\"",
		"mtime": "2026-09-09T07:04:51.896Z",
		"size": 53089,
		"path": "../public/images/projects/home-renovations/home-renovation2/img37.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img36.jpeg": {
		"type": "image/jpeg",
		"etag": "\"15112-XQ3yo3diFvJrlCfvIs4BlpnYxPg\"",
		"mtime": "2026-09-09T07:04:51.878Z",
		"size": 86290,
		"path": "../public/images/projects/home-renovations/home-renovation2/img36.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img38.jpeg": {
		"type": "image/jpeg",
		"etag": "\"f952-7vYC/nnY44cS19xgL1x46gLvnYU\"",
		"mtime": "2026-09-09T07:04:51.907Z",
		"size": 63826,
		"path": "../public/images/projects/home-renovations/home-renovation2/img38.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img39.jpeg": {
		"type": "image/jpeg",
		"etag": "\"12b67-ELrobr0Bt5jHDuQEXB3ppmheM1I\"",
		"mtime": "2026-09-09T07:04:51.919Z",
		"size": 76647,
		"path": "../public/images/projects/home-renovations/home-renovation2/img39.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1b70a-G8cAiSwK27rDlCmq+aqHiV9IVJQ\"",
		"mtime": "2026-09-09T07:04:51.465Z",
		"size": 112394,
		"path": "../public/images/projects/home-renovations/home-renovation2/img4.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1946d-TGHw6cCpVFW4rMHQQrbQvsrzAHM\"",
		"mtime": "2026-09-09T07:04:51.478Z",
		"size": 103533,
		"path": "../public/images/projects/home-renovations/home-renovation2/img5.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2006c-OkMdAdzj4S5TyGdzk4Jt+YMQ2nE\"",
		"mtime": "2026-09-09T07:04:51.485Z",
		"size": 131180,
		"path": "../public/images/projects/home-renovations/home-renovation2/img6.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1510b-QGPUZrU2hEgC+A4FmZewQctf1zI\"",
		"mtime": "2026-09-09T07:04:51.501Z",
		"size": 86283,
		"path": "../public/images/projects/home-renovations/home-renovation2/img7.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"15d5e-PXUjbw+ZZHWKaw+CSchE9Cs6r2k\"",
		"mtime": "2026-09-09T07:04:51.511Z",
		"size": 89438,
		"path": "../public/images/projects/home-renovations/home-renovation2/img8.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1752f-RT05800BTZjR4XP3/KgvdkAQYto\"",
		"mtime": "2026-09-09T07:08:20.536Z",
		"size": 95535,
		"path": "../public/images/projects/home-renovations/home-renovation3/img1.jpeg"
	},
	"/images/projects/home-renovations/home-renovation2/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"18118-a/ntMNaSvOkHzqnI6Yb//yP9w2I\"",
		"mtime": "2026-09-09T07:04:51.524Z",
		"size": 98584,
		"path": "../public/images/projects/home-renovations/home-renovation2/img9.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2ae37-LVSRCzLmh4/yXhb13MkRegwu5o8\"",
		"mtime": "2026-09-09T07:08:20.670Z",
		"size": 175671,
		"path": "../public/images/projects/home-renovations/home-renovation3/img10.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"276c0-NjxLbwQqdIimqWmKEEE3SbQj79k\"",
		"mtime": "2026-09-09T07:08:20.686Z",
		"size": 161472,
		"path": "../public/images/projects/home-renovations/home-renovation3/img11.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"17c64-wb8TW5ImawcIbVJv4leyOJ0qkQA\"",
		"mtime": "2026-09-09T07:08:20.698Z",
		"size": 97380,
		"path": "../public/images/projects/home-renovations/home-renovation3/img12.jpeg"
	},
	"/images/insights/insight-3.jpg": {
		"type": "image/jpeg",
		"etag": "\"e2a9b1-8qEvQICBE+9jHTH7+yh2JJSLIX8\"",
		"mtime": "2026-09-19T21:36:41.126Z",
		"size": 14854577,
		"path": "../public/images/insights/insight-3.jpg"
	},
	"/images/projects/home-renovations/home-renovation3/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1682b-TdZgGQsXDViNn6tvQfpO3yN4OqY\"",
		"mtime": "2026-09-09T07:08:20.574Z",
		"size": 92203,
		"path": "../public/images/projects/home-renovations/home-renovation3/img3.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2785a-N8Wnpj+QcfURpxwqlQ67oM5ZeO0\"",
		"mtime": "2026-09-09T07:08:20.709Z",
		"size": 161882,
		"path": "../public/images/projects/home-renovations/home-renovation3/img13.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"22b95-6GwrDb8AYsTvPxNatzjDISACW9E\"",
		"mtime": "2026-09-09T07:08:20.567Z",
		"size": 142229,
		"path": "../public/images/projects/home-renovations/home-renovation3/img2.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"32eca-DE5FCGlH5yTiKOVFRIuDxcZd5zk\"",
		"mtime": "2026-09-09T07:08:20.602Z",
		"size": 208586,
		"path": "../public/images/projects/home-renovations/home-renovation3/img4.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"26d02-8KEWWbwcg9z8dAnnWx+l58g2n4Y\"",
		"mtime": "2026-09-09T07:08:20.611Z",
		"size": 158978,
		"path": "../public/images/projects/home-renovations/home-renovation3/img5.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"23be1-IRdfLj55iu1cil+ySiaO0ymCbMw\"",
		"mtime": "2026-09-09T07:08:20.622Z",
		"size": 146401,
		"path": "../public/images/projects/home-renovations/home-renovation3/img6.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2c091-hDiM7e3E/RV3QFRvstiNkcHxzCQ\"",
		"mtime": "2026-09-09T07:08:20.638Z",
		"size": 180369,
		"path": "../public/images/projects/home-renovations/home-renovation3/img7.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"23358-Zb4JwG1bfUjUa/nzd6OvfCGRHVs\"",
		"mtime": "2026-09-09T07:08:20.649Z",
		"size": 144216,
		"path": "../public/images/projects/home-renovations/home-renovation3/img8.jpeg"
	},
	"/images/projects/home-renovations/home-renovation3/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2312f-bepBUwvNTiScCdaJF1peGQXthqg\"",
		"mtime": "2026-09-09T07:08:20.656Z",
		"size": 143663,
		"path": "../public/images/projects/home-renovations/home-renovation3/img9.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"7189b-cBTZlMC0JzUce9etwIRP4F0IYBk\"",
		"mtime": "2026-09-09T07:11:09.777Z",
		"size": 465051,
		"path": "../public/images/projects/home-renovations/home-renovation5/img1.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"6acdf-vZTx+DgUmk1eiP9eIpf2FuEZRjc\"",
		"mtime": "2026-09-09T07:11:09.926Z",
		"size": 437471,
		"path": "../public/images/projects/home-renovations/home-renovation5/img10.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"40d4a-/lm7+kooCqgkYjCfLQ8FBIck0rM\"",
		"mtime": "2026-09-09T07:11:09.940Z",
		"size": 265546,
		"path": "../public/images/projects/home-renovations/home-renovation5/img11.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2dd13-Cpyd76I7vbDOSkZoga854c9Nfs4\"",
		"mtime": "2026-09-09T07:11:09.957Z",
		"size": 187667,
		"path": "../public/images/projects/home-renovations/home-renovation5/img12.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"7cba3-pznI11aat6EJQR7QhoALViEd3r8\"",
		"mtime": "2026-09-09T07:11:09.974Z",
		"size": 510883,
		"path": "../public/images/projects/home-renovations/home-renovation5/img13.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img14.jpeg": {
		"type": "image/jpeg",
		"etag": "\"758a9-Tb/ySm69VohGCyrSsMNzD1f1jCk\"",
		"mtime": "2026-09-09T07:11:09.988Z",
		"size": 481449,
		"path": "../public/images/projects/home-renovations/home-renovation5/img14.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img15.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5a5af-wp2XcfKMQ7TiEqT67AePQ+fMEOs\"",
		"mtime": "2026-09-09T07:11:10.004Z",
		"size": 370095,
		"path": "../public/images/projects/home-renovations/home-renovation5/img15.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img16.jpeg": {
		"type": "image/jpeg",
		"etag": "\"6c180-pP4h7OSvsV/nIzfyyE/K9HY4eq4\"",
		"mtime": "2026-09-09T07:11:10.025Z",
		"size": 442752,
		"path": "../public/images/projects/home-renovations/home-renovation5/img16.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"6f013-aUWNAJjN/LBy9IQSS/IrSN/4Hvs\"",
		"mtime": "2026-09-09T07:11:09.815Z",
		"size": 454675,
		"path": "../public/images/projects/home-renovations/home-renovation5/img3.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"57324-eCoDXIMfLAwKMKkSTEpttVeON28\"",
		"mtime": "2026-09-09T07:11:09.793Z",
		"size": 357156,
		"path": "../public/images/projects/home-renovations/home-renovation5/img2.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"78ba9-yDsVLTQ+tDfLZkK9YIokCkmkICU\"",
		"mtime": "2026-09-09T07:11:09.836Z",
		"size": 494505,
		"path": "../public/images/projects/home-renovations/home-renovation5/img4.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"60ecc-tmjjPWfj9iBerFutQvKTF3uAmfA\"",
		"mtime": "2026-09-09T07:11:09.852Z",
		"size": 397004,
		"path": "../public/images/projects/home-renovations/home-renovation5/img5.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"79bde-faFw/bjP6oBqvLXQ3da7he7g050\"",
		"mtime": "2026-09-09T07:11:09.857Z",
		"size": 498654,
		"path": "../public/images/projects/home-renovations/home-renovation5/img6.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"739bb-bSynWfXCXW3Hf9+Feu1LKzZ5dcY\"",
		"mtime": "2026-09-09T07:11:09.871Z",
		"size": 473531,
		"path": "../public/images/projects/home-renovations/home-renovation5/img7.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"73ae7-4OLZPGJ68wbdLmfBJSl/+4z5/MU\"",
		"mtime": "2026-09-09T07:11:09.887Z",
		"size": 473831,
		"path": "../public/images/projects/home-renovations/home-renovation5/img8.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3e309-x1w9Q16EyNY0LlmMFnoBXv5/gzA\"",
		"mtime": "2026-09-09T07:09:48.230Z",
		"size": 254729,
		"path": "../public/images/projects/home-renovations/home-renovation4/img1.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"41377-8zlNFhv0JEe54rJif73jKChHLqM\"",
		"mtime": "2026-09-09T07:09:48.339Z",
		"size": 267127,
		"path": "../public/images/projects/home-renovations/home-renovation4/img10.jpeg"
	},
	"/images/projects/home-renovations/home-renovation5/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"7c5cd-4gD6ke2mfvdVIPRUvBGZOSJP5pU\"",
		"mtime": "2026-09-09T07:11:09.907Z",
		"size": 509389,
		"path": "../public/images/projects/home-renovations/home-renovation5/img9.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"11477-HcdGSw2u0PWRjwLCj6wMYlYrYdk\"",
		"mtime": "2026-09-09T07:09:48.359Z",
		"size": 70775,
		"path": "../public/images/projects/home-renovations/home-renovation4/img11.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"19647-9zjgCn5wwEYpiSatTVlmaHsw0PU\"",
		"mtime": "2026-09-09T07:09:48.371Z",
		"size": 104007,
		"path": "../public/images/projects/home-renovations/home-renovation4/img12.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1798a-pwCsU+SeEwXbvSuDyiujrsY/eBw\"",
		"mtime": "2026-09-09T07:09:48.382Z",
		"size": 96650,
		"path": "../public/images/projects/home-renovations/home-renovation4/img13.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img14.jpeg": {
		"type": "image/jpeg",
		"etag": "\"385ab-58aKDCRn4KY2LTrg8jikEXt91XM\"",
		"mtime": "2026-09-09T07:09:48.393Z",
		"size": 230827,
		"path": "../public/images/projects/home-renovations/home-renovation4/img14.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img15.jpeg": {
		"type": "image/jpeg",
		"etag": "\"39628-nWw8SZl3446m+tM/xJr7Sgbr/l4\"",
		"mtime": "2026-09-09T07:09:48.408Z",
		"size": 235048,
		"path": "../public/images/projects/home-renovations/home-renovation4/img15.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img16.jpeg": {
		"type": "image/jpeg",
		"etag": "\"25fe8-+h37zyWKCLDR6/NfqtgKBLmEUoM\"",
		"mtime": "2026-09-09T07:09:48.423Z",
		"size": 155624,
		"path": "../public/images/projects/home-renovations/home-renovation4/img16.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img17.jpeg": {
		"type": "image/jpeg",
		"etag": "\"49328-29v7OsiL5lr2YBZttvQODNP//cM\"",
		"mtime": "2026-09-09T07:09:48.438Z",
		"size": 299816,
		"path": "../public/images/projects/home-renovations/home-renovation4/img17.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img18.jpeg": {
		"type": "image/jpeg",
		"etag": "\"48a23-3zXPEOr5Wb3R/o2XfY2QVPQkZgQ\"",
		"mtime": "2026-09-09T07:09:48.452Z",
		"size": 297507,
		"path": "../public/images/projects/home-renovations/home-renovation4/img18.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img19.jpeg": {
		"type": "image/jpeg",
		"etag": "\"39af8-zsJ05afrS8F/+36WB26rVuf3o00\"",
		"mtime": "2026-09-09T07:09:48.467Z",
		"size": 236280,
		"path": "../public/images/projects/home-renovations/home-renovation4/img19.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3c1c0-a/xZ1ni6EM+eAEKnfxs3MXYljLQ\"",
		"mtime": "2026-09-09T07:09:48.242Z",
		"size": 246208,
		"path": "../public/images/projects/home-renovations/home-renovation4/img2.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img20.jpeg": {
		"type": "image/jpeg",
		"etag": "\"47005-+zkmxKgCE2pr1OuzxGsjCIIm694\"",
		"mtime": "2026-09-09T07:09:48.481Z",
		"size": 290821,
		"path": "../public/images/projects/home-renovations/home-renovation4/img20.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img21.jpeg": {
		"type": "image/jpeg",
		"etag": "\"6d285-GbOTzV3pTcgQQBgb7vyNNOFMJDY\"",
		"mtime": "2026-09-09T07:09:48.489Z",
		"size": 447109,
		"path": "../public/images/projects/home-renovations/home-renovation4/img21.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img22.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5bf0c-FnAtbkssrlcmR1/u93M3qaYCMiY\"",
		"mtime": "2026-09-09T07:09:48.507Z",
		"size": 376588,
		"path": "../public/images/projects/home-renovations/home-renovation4/img22.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img23.jpeg": {
		"type": "image/jpeg",
		"etag": "\"511fe-av8oIk4CtC31+JdF3sBHh6CTBxI\"",
		"mtime": "2026-09-09T07:09:48.521Z",
		"size": 332286,
		"path": "../public/images/projects/home-renovations/home-renovation4/img23.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img25.jpeg": {
		"type": "image/jpeg",
		"etag": "\"36e15-3v99xWGeWr08QGRdvWExsFRmpTE\"",
		"mtime": "2026-09-09T07:09:48.554Z",
		"size": 224789,
		"path": "../public/images/projects/home-renovations/home-renovation4/img25.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img24.jpeg": {
		"type": "image/jpeg",
		"etag": "\"49c6c-ETOkIR73XpS2pRc7Yq2GbrREXOE\"",
		"mtime": "2026-09-09T07:09:48.537Z",
		"size": 302188,
		"path": "../public/images/projects/home-renovations/home-renovation4/img24.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img26.jpeg": {
		"type": "image/jpeg",
		"etag": "\"569a6-Xyxfm7Huk5P5r62sBVU+dtTDHpM\"",
		"mtime": "2026-09-09T07:09:48.569Z",
		"size": 354726,
		"path": "../public/images/projects/home-renovations/home-renovation4/img26.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1b423-VMwCPlvDM1t0+a/usqnOQEsJ/8A\"",
		"mtime": "2026-09-09T07:09:48.257Z",
		"size": 111651,
		"path": "../public/images/projects/home-renovations/home-renovation4/img3.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img27.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4439b-YwDSxfZgPTWq9lCnAkuszAZWlUQ\"",
		"mtime": "2026-09-09T07:09:48.574Z",
		"size": 279451,
		"path": "../public/images/projects/home-renovations/home-renovation4/img27.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"15e70-yd1PmB7qkQuJVQVMNlnwnnK/tds\"",
		"mtime": "2026-09-09T07:09:48.282Z",
		"size": 89712,
		"path": "../public/images/projects/home-renovations/home-renovation4/img5.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"465d2-oOVWWt6R7qzmQzXZKIVP4L9Gk/0\"",
		"mtime": "2026-09-09T07:09:48.270Z",
		"size": 288210,
		"path": "../public/images/projects/home-renovations/home-renovation4/img4.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1d30d-klWy43Ymymovk0SmhaBHhGDYiUk\"",
		"mtime": "2026-09-09T07:09:48.292Z",
		"size": 119565,
		"path": "../public/images/projects/home-renovations/home-renovation4/img6.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2f9b7-sOZ7l/LEx8GmXFBVXNkP+sdx4A8\"",
		"mtime": "2026-09-09T07:09:48.306Z",
		"size": 194999,
		"path": "../public/images/projects/home-renovations/home-renovation4/img7.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2da36-h6zEaxTT4QAnfKF2opQ9tSgOKXI\"",
		"mtime": "2026-09-09T07:09:48.334Z",
		"size": 186934,
		"path": "../public/images/projects/home-renovations/home-renovation4/img9.jpeg"
	},
	"/images/projects/home-renovations/home-renovation4/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"41008-WTw6mumSYQNNl8hnPEi4s4sFJfA\"",
		"mtime": "2026-09-09T07:09:48.316Z",
		"size": 266248,
		"path": "../public/images/projects/home-renovations/home-renovation4/img8.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"44795-R/vxg46fOkSEbGOCHkLnYGEc3H4\"",
		"mtime": "2026-09-09T07:02:37.465Z",
		"size": 280469,
		"path": "../public/images/projects/infrastructure/infrastructure1/img1.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"42f0c-+keXdWEp1BB+Iuany/vTYWg+Ah0\"",
		"mtime": "2026-09-09T07:02:37.593Z",
		"size": 274188,
		"path": "../public/images/projects/infrastructure/infrastructure1/img10.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"63763-z8bLB17OE5wjill9GaHgAWrHodA\"",
		"mtime": "2026-09-09T07:02:37.607Z",
		"size": 407395,
		"path": "../public/images/projects/infrastructure/infrastructure1/img11.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4d950-TO90XWSqWel0K7vHs4pP9R8GrPw\"",
		"mtime": "2026-09-09T07:02:37.623Z",
		"size": 317776,
		"path": "../public/images/projects/infrastructure/infrastructure1/img12.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img13.jpeg": {
		"type": "image/jpeg",
		"etag": "\"183e3-ogDpZZioEp/hg5n7wtjs14tY2as\"",
		"mtime": "2026-09-09T07:02:37.634Z",
		"size": 99299,
		"path": "../public/images/projects/infrastructure/infrastructure1/img13.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img14.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1dd68-i3y5a9npD5lgiFIHxW2/jjGg+5Y\"",
		"mtime": "2026-09-09T07:02:37.646Z",
		"size": 122216,
		"path": "../public/images/projects/infrastructure/infrastructure1/img14.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img15.jpeg": {
		"type": "image/jpeg",
		"etag": "\"38efa-HOliov4eJL916NqKmdYISMICHzc\"",
		"mtime": "2026-09-09T07:02:37.659Z",
		"size": 233210,
		"path": "../public/images/projects/infrastructure/infrastructure1/img15.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img16.jpeg": {
		"type": "image/jpeg",
		"etag": "\"31e81-uSeSSrBM0K+lgz5rN4EjB78ZJDg\"",
		"mtime": "2026-09-09T07:02:37.672Z",
		"size": 204417,
		"path": "../public/images/projects/infrastructure/infrastructure1/img16.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img17.jpeg": {
		"type": "image/jpeg",
		"etag": "\"31e69-N+RtdRZQG25fzIYMCU9WqzGMNLQ\"",
		"mtime": "2026-09-09T07:02:37.686Z",
		"size": 204393,
		"path": "../public/images/projects/infrastructure/infrastructure1/img17.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img18.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3333c-mfhnVgHYb0H62WINvhWWKx29feU\"",
		"mtime": "2026-09-09T07:02:37.699Z",
		"size": 209724,
		"path": "../public/images/projects/infrastructure/infrastructure1/img18.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img19.jpeg": {
		"type": "image/jpeg",
		"etag": "\"33683-MG85lpWNXhRlQ5xzlwuBzpHQH18\"",
		"mtime": "2026-09-09T07:02:37.711Z",
		"size": 210563,
		"path": "../public/images/projects/infrastructure/infrastructure1/img19.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2bd28-aNdFM4xBEZT00PqGcvVEoAclN18\"",
		"mtime": "2026-09-09T07:02:37.480Z",
		"size": 179496,
		"path": "../public/images/projects/infrastructure/infrastructure1/img2.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img20.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2f3e2-jra6jvUS/LYD67GH/KHMs7+DOMI\"",
		"mtime": "2026-09-09T07:02:37.724Z",
		"size": 193506,
		"path": "../public/images/projects/infrastructure/infrastructure1/img20.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"28041-RKecxF6E7SqPumg+c5ukkGSAnt8\"",
		"mtime": "2026-09-09T07:02:37.493Z",
		"size": 163905,
		"path": "../public/images/projects/infrastructure/infrastructure1/img3.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"25df6-TaqJtAGKU7W4rPIZZEK94A9VeOE\"",
		"mtime": "2026-09-09T07:02:37.522Z",
		"size": 155126,
		"path": "../public/images/projects/infrastructure/infrastructure1/img5.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4cf06-mbxYHum8c+KhOnI98XWIxFQyE98\"",
		"mtime": "2026-09-09T07:02:37.508Z",
		"size": 315142,
		"path": "../public/images/projects/infrastructure/infrastructure1/img4.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"324c1-S4W2D0ZsD28SJUG8K/qtu61KLZg\"",
		"mtime": "2026-09-09T07:02:37.536Z",
		"size": 206017,
		"path": "../public/images/projects/infrastructure/infrastructure1/img6.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2daed-OPWPNW3ZSfuoxk+3/vJ3j4Pf2uo\"",
		"mtime": "2026-09-09T07:02:37.549Z",
		"size": 187117,
		"path": "../public/images/projects/infrastructure/infrastructure1/img7.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"42c4c-PyMLZfF7B3f0K/MKNCb6PvXQWhc\"",
		"mtime": "2026-09-09T07:02:37.579Z",
		"size": 273484,
		"path": "../public/images/projects/infrastructure/infrastructure1/img9.jpeg"
	},
	"/images/projects/infrastructure/infrastructure1/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"68712-IgrDxFg0FsDeZYDzXozF6Rz+jmA\"",
		"mtime": "2026-09-09T07:02:37.566Z",
		"size": 427794,
		"path": "../public/images/projects/infrastructure/infrastructure1/img8.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2d6dd-HMcelJSg2iuVITt8SbPOwuoUvPs\"",
		"mtime": "2026-09-09T07:05:59.085Z",
		"size": 186077,
		"path": "../public/images/projects/infrastructure/infrastructure2/img1.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img10.jpeg": {
		"type": "image/jpeg",
		"etag": "\"15318-MQmKJ3wEQVNMt8rPjToQz4BFArI\"",
		"mtime": "2026-09-09T07:05:59.197Z",
		"size": 86808,
		"path": "../public/images/projects/infrastructure/infrastructure2/img10.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img12.jpeg": {
		"type": "image/jpeg",
		"etag": "\"aa30-BwbTQFFtqj9W/sGEruuVHPIYpxM\"",
		"mtime": "2026-09-09T07:05:59.225Z",
		"size": 43568,
		"path": "../public/images/projects/infrastructure/infrastructure2/img12.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img11.jpeg": {
		"type": "image/jpeg",
		"etag": "\"d755-PX6+EYbrsfg7JCLn3dEOM2onlGE\"",
		"mtime": "2026-09-09T07:05:59.214Z",
		"size": 55125,
		"path": "../public/images/projects/infrastructure/infrastructure2/img11.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"38dca-G+hnWhQGozF+9f2xwpK0+T2Yz8c\"",
		"mtime": "2026-09-09T07:05:59.097Z",
		"size": 232906,
		"path": "../public/images/projects/infrastructure/infrastructure2/img2.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"163f0-TIGdqBX5JOJoA1GqscxBVFy0Gmo\"",
		"mtime": "2026-09-09T07:05:59.140Z",
		"size": 91120,
		"path": "../public/images/projects/infrastructure/infrastructure2/img5.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"50b4b-PZUBbuz8VPRE3uo/qVCiTkuh+EM\"",
		"mtime": "2026-09-09T07:05:59.114Z",
		"size": 330571,
		"path": "../public/images/projects/infrastructure/infrastructure2/img3.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"26a4a-72PsjJt+IRJJcLed4EVg+rS7MpM\"",
		"mtime": "2026-09-09T07:05:59.130Z",
		"size": 158282,
		"path": "../public/images/projects/infrastructure/infrastructure2/img4.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2fbcb-XMkJBSEugri2Zhpteh3X/NIFYwI\"",
		"mtime": "2026-09-09T07:05:59.147Z",
		"size": 195531,
		"path": "../public/images/projects/infrastructure/infrastructure2/img6.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img8.jpeg": {
		"type": "image/jpeg",
		"etag": "\"15951-O+VOHdZuaLI+xShnCtVAfWRbFLQ\"",
		"mtime": "2026-09-09T07:05:59.180Z",
		"size": 88401,
		"path": "../public/images/projects/infrastructure/infrastructure2/img8.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img7.jpeg": {
		"type": "image/jpeg",
		"etag": "\"3e17e-ktZ85sQb5swNFak1byab6RkInT8\"",
		"mtime": "2026-09-09T07:05:59.168Z",
		"size": 254334,
		"path": "../public/images/projects/infrastructure/infrastructure2/img7.jpeg"
	},
	"/images/projects/infrastructure/infrastructure2/img9.jpeg": {
		"type": "image/jpeg",
		"etag": "\"15542-KLkHrEFCc0SYsXWui1gBHcpaRSc\"",
		"mtime": "2026-09-09T07:05:59.180Z",
		"size": 87362,
		"path": "../public/images/projects/infrastructure/infrastructure2/img9.jpeg"
	},
	"/images/projects/infrastructure/infrastructure3/img1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5b9e3-WEjwAwE/yrDtJ2QaIoCgkwLL+bk\"",
		"mtime": "2026-09-09T07:07:54.855Z",
		"size": 375267,
		"path": "../public/images/projects/infrastructure/infrastructure3/img1.jpeg"
	},
	"/images/projects/infrastructure/infrastructure3/img2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"6905b-NWL2gH9cXjZ1x12jhygERT1WRYE\"",
		"mtime": "2026-09-09T07:07:54.868Z",
		"size": 430171,
		"path": "../public/images/projects/infrastructure/infrastructure3/img2.jpeg"
	},
	"/images/projects/infrastructure/infrastructure3/img3.jpeg": {
		"type": "image/jpeg",
		"etag": "\"6b68e-vZuiMmsAEkKeFDFyzqeTf+SbQVQ\"",
		"mtime": "2026-09-09T07:07:54.894Z",
		"size": 439950,
		"path": "../public/images/projects/infrastructure/infrastructure3/img3.jpeg"
	},
	"/images/projects/infrastructure/infrastructure3/img4.jpeg": {
		"type": "image/jpeg",
		"etag": "\"66945-Hmar+ZD1bECHULDiSo/eu8Q8EoQ\"",
		"mtime": "2026-09-09T07:07:54.913Z",
		"size": 420165,
		"path": "../public/images/projects/infrastructure/infrastructure3/img4.jpeg"
	},
	"/images/projects/infrastructure/infrastructure3/img5.jpeg": {
		"type": "image/jpeg",
		"etag": "\"579d8-X+Niqj81BEMoXqLITGeximt+0aM\"",
		"mtime": "2026-09-09T07:07:54.930Z",
		"size": 358872,
		"path": "../public/images/projects/infrastructure/infrastructure3/img5.jpeg"
	},
	"/images/projects/infrastructure/infrastructure3/img6.jpeg": {
		"type": "image/jpeg",
		"etag": "\"47606-gg1I2Gm1aT7HjMSynjyPWdX9wl0\"",
		"mtime": "2026-09-09T07:07:54.946Z",
		"size": 292358,
		"path": "../public/images/projects/infrastructure/infrastructure3/img6.jpeg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_2o8uyN = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_2o8uyN
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
