import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Reveal } from "./reveal-9iJXRnDn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-hero-CQEGAZcs.js
var import_jsx_runtime = require_jsx_runtime();
function PageHero({ eyebrow, title, intro, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-ink text-ink-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid-blueprint-dark pointer-events-none absolute inset-0 opacity-60 motion-safe:animate-[blueprint-drift_18s_linear_infinite]",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute -top-24 right-[-10%] hidden size-136 rotate-12 border border-ink-line motion-safe:animate-[hero-orbit_24s_linear_infinite] md:block",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute -bottom-32 -left-24 hidden size-64 rounded-full border border-ink-line opacity-40 motion-safe:animate-[hero-pulse_8s_ease-in-out_infinite] lg:block",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute left-0 top-0 h-px w-1/3 origin-left bg-accent motion-safe:animate-[hero-line_1.2s_ease-out]",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x relative pt-14 pb-14 md:pt-20 md:pb-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label-tech flex items-center gap-3 text-ink-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: eyebrow })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 120,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "display-1 mt-6 max-w-5xl",
							children: title
						})
					}),
					intro && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 240,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 max-w-2xl text-lg leading-relaxed text-ink-muted",
							children: intro
						})
					}),
					children && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 360,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10",
							children
						})
					})
				]
			})
		]
	});
}
//#endregion
export { PageHero as t };
