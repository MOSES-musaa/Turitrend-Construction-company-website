import { f as lazyRouteComponent, j as notFound, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as serviceBySlug } from "./whatsapp-button-ChXxaLqO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services._slug-D5yTtc4j.js
var $$splitComponentImporter = () => import("./services._slug-BwhkQ5xA.mjs");
var Route = createFileRoute("/services/$slug")({
	loader: ({ params }) => {
		const service = serviceBySlug(params.slug);
		if (!service) throw notFound();
		return { service };
	},
	head: ({ loaderData }) => {
		const service = loaderData?.service;
		const title = service ? `${service.title} | Turiend Construction Limited` : "Service | Turiend Construction Limited";
		const description = service?.summary ?? "Construction services in Kenya.";
		return { meta: [
			{ title },
			{
				name: "description",
				content: description
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: description
			}
		] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
