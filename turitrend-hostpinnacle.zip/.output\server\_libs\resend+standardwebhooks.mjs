import { t as __commonJSMin } from "../_runtime.mjs";
import { t as PostalMime } from "./postal-mime.mjs";
import { t as require_base64 } from "./stablelib__base64.mjs";
import { t as require_sha256 } from "./fast-sha256.mjs";
//#region node_modules/standardwebhooks/dist/timing_safe_equal.js
var require_timing_safe_equal = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.timingSafeEqual = void 0;
	function assert(expr, msg = "") {
		if (!expr) throw new Error(msg);
	}
	function timingSafeEqual(a, b) {
		if (a.byteLength !== b.byteLength) return false;
		if (!(a instanceof DataView)) a = new DataView(ArrayBuffer.isView(a) ? a.buffer : a);
		if (!(b instanceof DataView)) b = new DataView(ArrayBuffer.isView(b) ? b.buffer : b);
		assert(a instanceof DataView);
		assert(b instanceof DataView);
		const length = a.byteLength;
		let out = 0;
		let i = -1;
		while (++i < length) out |= a.getUint8(i) ^ b.getUint8(i);
		return out === 0;
	}
	exports.timingSafeEqual = timingSafeEqual;
}));
//#endregion
//#region node_modules/resend/dist/index.mjs
var import_dist = (/* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Webhook = exports.WebhookVerificationError = void 0;
	var timing_safe_equal_1 = require_timing_safe_equal();
	var base64 = require_base64();
	var sha256 = require_sha256();
	var WEBHOOK_TOLERANCE_IN_SECONDS = 300;
	var ExtendableError = class ExtendableError extends Error {
		constructor(message) {
			super(message);
			Object.setPrototypeOf(this, ExtendableError.prototype);
			this.name = "ExtendableError";
			this.stack = new Error(message).stack;
		}
	};
	var WebhookVerificationError = class WebhookVerificationError extends ExtendableError {
		constructor(message) {
			super(message);
			Object.setPrototypeOf(this, WebhookVerificationError.prototype);
			this.name = "WebhookVerificationError";
		}
	};
	exports.WebhookVerificationError = WebhookVerificationError;
	var Webhook = class Webhook {
		constructor(secret, options) {
			if (!secret) throw new Error("Secret can't be empty.");
			if ((options === null || options === void 0 ? void 0 : options.format) === "raw") if (secret instanceof Uint8Array) this.key = secret;
			else this.key = Uint8Array.from(secret, (c) => c.charCodeAt(0));
			else {
				if (typeof secret !== "string") throw new Error("Expected secret to be of type string");
				if (secret.startsWith(Webhook.prefix)) secret = secret.substring(Webhook.prefix.length);
				this.key = base64.decode(secret);
			}
		}
		verify(payload, headers_) {
			const headers = {};
			for (const key of Object.keys(headers_)) headers[key.toLowerCase()] = headers_[key];
			const msgId = headers["webhook-id"];
			const msgSignature = headers["webhook-signature"];
			const msgTimestamp = headers["webhook-timestamp"];
			if (!msgSignature || !msgId || !msgTimestamp) throw new WebhookVerificationError("Missing required headers");
			const timestamp = this.verifyTimestamp(msgTimestamp);
			const expectedSignature = this.sign(msgId, timestamp, payload).split(",")[1];
			const passedSignatures = msgSignature.split(" ");
			const encoder = new globalThis.TextEncoder();
			for (const versionedSignature of passedSignatures) {
				const [version, signature] = versionedSignature.split(",");
				if (version !== "v1") continue;
				if ((0, timing_safe_equal_1.timingSafeEqual)(encoder.encode(signature), encoder.encode(expectedSignature))) return JSON.parse(payload.toString());
			}
			throw new WebhookVerificationError("No matching signature found");
		}
		sign(msgId, timestamp, payload) {
			if (typeof payload === "string") {} else if (payload.constructor.name === "Buffer") payload = payload.toString();
			else throw new Error("Expected payload to be of type string or Buffer.");
			const encoder = new TextEncoder();
			const timestampNumber = Math.floor(timestamp.getTime() / 1e3);
			const toSign = encoder.encode(`${msgId}.${timestampNumber}.${payload}`);
			return `v1,${base64.encode(sha256.hmac(this.key, toSign))}`;
		}
		verifyTimestamp(timestampHeader) {
			const now = Math.floor(Date.now() / 1e3);
			const timestamp = parseInt(timestampHeader, 10);
			if (isNaN(timestamp)) throw new WebhookVerificationError("Invalid Signature Headers");
			if (now - timestamp > WEBHOOK_TOLERANCE_IN_SECONDS) throw new WebhookVerificationError("Message timestamp too old");
			if (timestamp > now + WEBHOOK_TOLERANCE_IN_SECONDS) throw new WebhookVerificationError("Message timestamp too new");
			return /* @__PURE__ */ new Date(timestamp * 1e3);
		}
	};
	exports.Webhook = Webhook;
	Webhook.prefix = "whsec_";
})))();
var version = "6.28.0";
function buildPaginationUrl(base, options) {
	const queryString = buildPaginationQuery(options);
	return queryString ? `${base}?${queryString}` : base;
}
/**
* Builds a query string from pagination options
* @param options - Pagination options containing limit and either after or before (but not both)
* @returns Query string (without leading '?') or empty string if no options
*/
function buildPaginationQuery(options) {
	const searchParams = new URLSearchParams();
	if (options.limit !== void 0) searchParams.set("limit", options.limit.toString());
	if ("after" in options && options.after !== void 0) searchParams.set("after", options.after);
	if ("before" in options && options.before !== void 0) searchParams.set("before", options.before);
	return searchParams.toString();
}
var ApiKeys = class {
	constructor(resend) {
		this.resend = resend;
	}
	async create(payload, options = {}) {
		return await this.resend.post("/api-keys", payload, options);
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/api-keys", options);
		return await this.resend.get(url);
	}
	async update(id, payload) {
		return await this.resend.patch(`/api-keys/${id}`, payload);
	}
	async remove(id) {
		return await this.resend.delete(`/api-keys/${id}`);
	}
};
var AutomationRuns = class {
	constructor(resend) {
		this.resend = resend;
	}
	async get(options) {
		return await this.resend.get(`/automations/${options.automationId}/runs/${options.runId}`);
	}
	async list(options) {
		const queryString = buildPaginationQuery(options);
		const searchParams = new URLSearchParams(queryString);
		if (options.status) {
			const statusValue = Array.isArray(options.status) ? options.status.join(",") : options.status;
			searchParams.set("status", statusValue);
		}
		const qs = searchParams.toString();
		const url = qs ? `/automations/${options.automationId}/runs?${qs}` : `/automations/${options.automationId}/runs`;
		return await this.resend.get(url);
	}
};
function parseStepConfig(step) {
	switch (step.type) {
		case "trigger": return {
			key: step.key,
			type: step.type,
			config: { event_name: step.config.eventName }
		};
		case "delay": return {
			key: step.key,
			type: step.type,
			config: step.config
		};
		case "send_email": return {
			key: step.key,
			type: step.type,
			config: {
				template: step.config.template,
				subject: step.config.subject,
				from: step.config.from,
				reply_to: step.config.replyTo
			}
		};
		case "wait_for_event": return {
			key: step.key,
			type: step.type,
			config: {
				event_name: step.config.eventName,
				timeout: step.config.timeout,
				filter_rule: step.config.filterRule
			}
		};
		case "condition": return {
			key: step.key,
			type: step.type,
			config: step.config
		};
		case "contact_update": return {
			key: step.key,
			type: step.type,
			config: {
				first_name: step.config.firstName,
				last_name: step.config.lastName,
				unsubscribed: step.config.unsubscribed,
				properties: step.config.properties
			}
		};
		case "contact_delete": return {
			key: step.key,
			type: step.type,
			config: step.config
		};
		case "add_to_segment": return {
			key: step.key,
			type: step.type,
			config: { segment_id: step.config.segmentId }
		};
	}
}
function parseConnection(connection) {
	return {
		from: connection.from,
		to: connection.to,
		type: connection.type
	};
}
function parseAutomationToApiOptions(automation) {
	return {
		name: automation.name,
		status: automation.status,
		steps: automation.steps.map(parseStepConfig),
		connections: automation.connections.map(parseConnection)
	};
}
function parseEventToApiOptions(event) {
	return {
		event: event.event,
		contact_id: event.contactId,
		email: event.email,
		payload: event.payload
	};
}
var Automations = class {
	constructor(resend) {
		this.resend = resend;
		this.runs = new AutomationRuns(this.resend);
	}
	async create(payload) {
		return await this.resend.post("/automations", parseAutomationToApiOptions(payload));
	}
	async list(options = {}) {
		const params = [buildPaginationQuery(options)];
		if (options.status) params.push(`status=${encodeURIComponent(options.status)}`);
		const qs = params.filter(Boolean).join("&");
		const url = qs ? `/automations?${qs}` : "/automations";
		return await this.resend.get(url);
	}
	async get(id) {
		return await this.resend.get(`/automations/${id}`);
	}
	async remove(id) {
		return await this.resend.delete(`/automations/${id}`);
	}
	async update(id, payload) {
		const apiPayload = {};
		if (payload.name !== void 0) apiPayload.name = payload.name;
		if (payload.status !== void 0) apiPayload.status = payload.status;
		if (payload.steps !== void 0) apiPayload.steps = payload.steps.map(parseStepConfig);
		if (payload.connections !== void 0) apiPayload.connections = payload.connections.map(parseConnection);
		return await this.resend.patch(`/automations/${id}`, apiPayload);
	}
	async duplicate(id) {
		return await this.resend.post(`/automations/${id}/duplicate`);
	}
	async stop(id) {
		return await this.resend.post(`/automations/${id}/stop`);
	}
};
function parseAttachments(attachments) {
	return attachments?.map((attachment) => ({
		content: attachment.content,
		filename: attachment.filename,
		path: attachment.path,
		content_type: attachment.contentType,
		content_id: attachment.contentId
	}));
}
function parseEmailToApiOptions(email) {
	return {
		attachments: parseAttachments(email.attachments),
		bcc: email.bcc,
		cc: email.cc,
		from: email.from,
		headers: email.headers,
		html: email.html,
		reply_to: email.replyTo,
		scheduled_at: email.scheduledAt,
		subject: email.subject,
		tags: email.tags,
		text: email.text,
		to: email.to,
		template: email.template ? {
			id: email.template.id,
			variables: email.template.variables
		} : void 0,
		topic_id: email.topicId
	};
}
async function render(node) {
	let render;
	try {
		({render} = await import("../_chunks/render_resend.mjs"));
	} catch {
		throw new Error("Failed to render React component. Make sure to install `@react-email/render` or `@react-email/components`.");
	}
	return render(node);
}
var Batch$1 = class {
	constructor(resend) {
		this.resend = resend;
	}
	async send(payload, options) {
		return this.create(payload, options);
	}
	async create(payload, options) {
		const emails = [];
		for (const email of payload) {
			if (email.react) {
				email.html = await render(email.react);
				email.react = void 0;
			}
			emails.push(parseEmailToApiOptions(email));
		}
		return await this.resend.post("/emails/batch", emails, {
			...options,
			headers: {
				"x-batch-validation": options?.batchValidation ?? "strict",
				...options?.headers
			}
		});
	}
};
var Broadcasts = class {
	constructor(resend) {
		this.resend = resend;
	}
	async create(payload, options = {}) {
		const html = payload.react ? await render(payload.react) : payload.html;
		return await this.resend.post("/broadcasts", {
			name: payload.name,
			segment_id: payload.segmentId,
			audience_id: payload.audienceId,
			preview_text: payload.previewText,
			from: payload.from,
			html,
			reply_to: payload.replyTo,
			subject: payload.subject,
			text: payload.text,
			topic_id: payload.topicId,
			send: payload.send,
			scheduled_at: payload.scheduledAt
		}, options);
	}
	async send(id, payload) {
		return await this.resend.post(`/broadcasts/${id}/send`, { scheduled_at: payload?.scheduledAt });
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/broadcasts", options);
		return await this.resend.get(url);
	}
	async get(id) {
		return await this.resend.get(`/broadcasts/${id}`);
	}
	async recipients(id, options) {
		const url = `/broadcasts/${id}/recipients?${buildRecipientsQuery(options)}`;
		return await this.resend.get(url);
	}
	async clickedLinks(id, options = {}) {
		const url = buildPaginationUrl(`/broadcasts/${id}/clicked-links`, options);
		return await this.resend.get(url);
	}
	async remove(id) {
		return await this.resend.delete(`/broadcasts/${id}`);
	}
	async cancel(id) {
		return await this.resend.post(`/broadcasts/${id}/cancel`);
	}
	async duplicate(id) {
		return await this.resend.post(`/broadcasts/${id}/duplicate`);
	}
	async update(id, payload) {
		const html = payload.react ? await render(payload.react) : payload.html;
		return await this.resend.patch(`/broadcasts/${id}`, {
			name: payload.name,
			segment_id: payload.segmentId,
			audience_id: payload.audienceId,
			from: payload.from,
			html,
			text: payload.text,
			subject: payload.subject,
			reply_to: payload.replyTo,
			preview_text: payload.previewText,
			topic_id: payload.topicId
		});
	}
};
function buildRecipientsQuery(options) {
	const { type, email, bounceType, ...pagination } = options;
	const searchParams = new URLSearchParams(buildPaginationQuery(pagination));
	searchParams.set("type", type);
	if (email !== void 0) searchParams.set("email", email);
	if (bounceType !== void 0) searchParams.set("bounce_type", bounceType);
	return searchParams.toString();
}
function parseContactPropertyFromApi(contactProperty) {
	return {
		id: contactProperty.id,
		key: contactProperty.key,
		createdAt: contactProperty.created_at,
		type: contactProperty.type,
		fallbackValue: contactProperty.fallback_value
	};
}
function parseContactPropertyToApiOptions(contactProperty) {
	if ("key" in contactProperty) return {
		key: contactProperty.key,
		type: contactProperty.type,
		fallback_value: contactProperty.fallbackValue
	};
	return { fallback_value: contactProperty.fallbackValue };
}
var ContactProperties = class {
	constructor(resend) {
		this.resend = resend;
	}
	async create(options) {
		const apiOptions = parseContactPropertyToApiOptions(options);
		return await this.resend.post("/contact-properties", apiOptions);
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/contact-properties", options);
		const response = await this.resend.get(url);
		if (response.data) return {
			data: {
				...response.data,
				data: response.data.data.map((apiContactProperty) => parseContactPropertyFromApi(apiContactProperty))
			},
			headers: response.headers,
			error: null
		};
		return response;
	}
	async get(id) {
		if (!id) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		const response = await this.resend.get(`/contact-properties/${id}`);
		if (response.data) return {
			data: {
				object: "contact_property",
				...parseContactPropertyFromApi(response.data)
			},
			headers: response.headers,
			error: null
		};
		return response;
	}
	async update(payload) {
		if (!payload.id) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		const apiOptions = parseContactPropertyToApiOptions(payload);
		return await this.resend.patch(`/contact-properties/${payload.id}`, apiOptions);
	}
	async remove(id) {
		if (!id) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		return await this.resend.delete(`/contact-properties/${id}`);
	}
};
var ContactImports = class {
	constructor(resend) {
		this.resend = resend;
	}
	async create(payload, options = {}) {
		const formData = this.buildCreateFormData(payload);
		return this.resend.post("/contacts/imports", formData, options);
	}
	async list(options = {}) {
		const searchParams = new URLSearchParams(buildPaginationQuery(options));
		if (options.status !== void 0) searchParams.set("status", options.status);
		const queryString = searchParams.toString();
		const url = queryString ? `/contacts/imports?${queryString}` : "/contacts/imports";
		return this.resend.get(url);
	}
	async get(id) {
		return this.resend.get(`/contacts/imports/${id}`);
	}
	buildCreateFormData(payload) {
		const formData = new FormData();
		formData.append("file", payload.file);
		this.appendField(formData, "column_map", this.buildColumnMap(payload.columnMap ?? null));
		this.appendField(formData, "on_conflict", payload.onConflict ?? null);
		this.appendField(formData, "segments", payload.segments ?? null);
		this.appendField(formData, "topics", payload.topics ?? null);
		return formData;
	}
	buildColumnMap(columnMap) {
		if (columnMap === null) return null;
		return {
			email: columnMap.email,
			first_name: columnMap.firstName,
			last_name: columnMap.lastName,
			unsubscribed: columnMap.unsubscribed,
			properties: columnMap.properties
		};
	}
	appendField(formData, name, value) {
		if (value === null) return;
		formData.append(name, typeof value === "string" ? value : JSON.stringify(value));
	}
};
var ContactSegments = class {
	constructor(resend) {
		this.resend = resend;
	}
	async list(options) {
		if (!options.contactId && !options.email) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` or `email` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		const url = buildPaginationUrl(`/contacts/${options.email ? options.email : options.contactId}/segments`, options);
		return await this.resend.get(url);
	}
	async add(options) {
		if (!options.contactId && !options.email) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` or `email` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		const identifier = options.email ? options.email : options.contactId;
		return this.resend.post(`/contacts/${identifier}/segments/${options.segmentId}`);
	}
	async remove(options) {
		if (!options.contactId && !options.email) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` or `email` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		const identifier = options.email ? options.email : options.contactId;
		return this.resend.delete(`/contacts/${identifier}/segments/${options.segmentId}`);
	}
};
var ContactTopics = class {
	constructor(resend) {
		this.resend = resend;
	}
	async update(payload) {
		if (!payload.id && !payload.email) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` or `email` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		const identifier = payload.email ? payload.email : payload.id;
		return this.resend.patch(`/contacts/${identifier}/topics`, payload.topics);
	}
	async list(options) {
		if (!options.id && !options.email) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` or `email` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		const url = buildPaginationUrl(`/contacts/${options.email ? options.email : options.id}/topics`, options);
		return this.resend.get(url);
	}
};
var Contacts = class {
	constructor(resend) {
		this.resend = resend;
		this.imports = new ContactImports(this.resend);
		this.topics = new ContactTopics(this.resend);
		this.segments = new ContactSegments(this.resend);
	}
	async create(payload, options = {}) {
		if ("audienceId" in payload) {
			if ("segments" in payload || "topics" in payload) return {
				data: null,
				headers: null,
				error: {
					message: "`audienceId` is deprecated, and cannot be used together with `segments` or `topics`. Use `segments` instead to add one or more segments to the new contact.",
					statusCode: null,
					name: "invalid_parameter"
				}
			};
			return await this.resend.post(`/audiences/${payload.audienceId}/contacts`, {
				unsubscribed: payload.unsubscribed,
				email: payload.email,
				first_name: payload.firstName,
				last_name: payload.lastName,
				properties: payload.properties
			}, options);
		}
		return await this.resend.post("/contacts", {
			unsubscribed: payload.unsubscribed,
			email: payload.email,
			first_name: payload.firstName,
			last_name: payload.lastName,
			properties: payload.properties,
			segments: payload.segments,
			topics: payload.topics
		}, options);
	}
	async list(options = {}) {
		const segmentId = options.segmentId ?? options.audienceId;
		if (!segmentId) {
			const url = buildPaginationUrl("/contacts", options);
			return await this.resend.get(url);
		}
		const url = buildPaginationUrl(`/segments/${segmentId}/contacts`, options);
		return await this.resend.get(url);
	}
	async get(options) {
		if (typeof options === "string") return this.resend.get(`/contacts/${options}`);
		if (!options.id && !options.email) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` or `email` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		if (!options.audienceId) return this.resend.get(`/contacts/${options?.email ? options?.email : options?.id}`);
		return this.resend.get(`/audiences/${options.audienceId}/contacts/${options?.email ? options?.email : options?.id}`);
	}
	async update(options) {
		if (!options.id && !options.email) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` or `email` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		if (!options.audienceId) return await this.resend.patch(`/contacts/${options?.email ? options?.email : options?.id}`, {
			unsubscribed: options.unsubscribed,
			first_name: options.firstName,
			last_name: options.lastName,
			properties: options.properties
		});
		return await this.resend.patch(`/audiences/${options.audienceId}/contacts/${options?.email ? options?.email : options?.id}`, {
			unsubscribed: options.unsubscribed,
			first_name: options.firstName,
			last_name: options.lastName,
			properties: options.properties
		});
	}
	async remove(payload) {
		if (typeof payload === "string") return this.resend.delete(`/contacts/${payload}`);
		if (!payload.id && !payload.email) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` or `email` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		if (!payload.audienceId) return this.resend.delete(`/contacts/${payload?.email ? payload?.email : payload?.id}`);
		return this.resend.delete(`/audiences/${payload.audienceId}/contacts/${payload?.email ? payload?.email : payload?.id}`);
	}
};
function parseDomainToApiOptions(domain) {
	return {
		name: domain.name,
		region: domain.region,
		custom_return_path: domain.customReturnPath,
		capabilities: domain.capabilities,
		open_tracking: domain.openTracking,
		click_tracking: domain.clickTracking,
		tls: domain.tls,
		tracking_subdomain: domain.trackingSubdomain
	};
}
var DomainClaims = class {
	constructor(resend) {
		this.resend = resend;
	}
	async create(payload, options = {}) {
		return await this.resend.post("/domains/claim", {
			name: payload.name,
			region: payload.region,
			custom_return_path: payload.customReturnPath,
			open_tracking: payload.openTracking,
			click_tracking: payload.clickTracking,
			tracking_subdomain: payload.trackingSubdomain
		}, options);
	}
	async get(domainId) {
		return await this.resend.get(`/domains/${domainId}/claim`);
	}
	async verify(domainId) {
		return await this.resend.post(`/domains/${domainId}/claim/verify`);
	}
};
var Domains = class {
	constructor(resend) {
		this.resend = resend;
		this.claims = new DomainClaims(this.resend);
	}
	async create(payload, options = {}) {
		return await this.resend.post("/domains", parseDomainToApiOptions(payload), options);
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/domains", options);
		return await this.resend.get(url);
	}
	async get(id) {
		return await this.resend.get(`/domains/${id}`);
	}
	async update(payload) {
		return await this.resend.patch(`/domains/${payload.id}`, {
			click_tracking: payload.clickTracking,
			open_tracking: payload.openTracking,
			tls: payload.tls,
			capabilities: payload.capabilities,
			tracking_subdomain: payload.trackingSubdomain
		});
	}
	async remove(id) {
		return await this.resend.delete(`/domains/${id}`);
	}
	async verify(id) {
		return await this.resend.post(`/domains/${id}/verify`);
	}
};
var Attachments$1 = class {
	constructor(resend) {
		this.resend = resend;
	}
	async get(options) {
		const { emailId, id } = options;
		return await this.resend.get(`/emails/${emailId}/attachments/${id}`);
	}
	async list(options) {
		const { emailId } = options;
		const url = buildPaginationUrl(`/emails/${emailId}/attachments`, options);
		return await this.resend.get(url);
	}
};
var Attachments = class {
	constructor(resend) {
		this.resend = resend;
	}
	async get(options) {
		const { emailId, id } = options;
		return await this.resend.get(`/emails/receiving/${emailId}/attachments/${id}`);
	}
	async list(options) {
		const { emailId } = options;
		const url = buildPaginationUrl(`/emails/receiving/${emailId}/attachments`, options);
		return await this.resend.get(url);
	}
};
var Receiving = class {
	constructor(resend) {
		this.resend = resend;
		this.attachments = new Attachments(resend);
	}
	async get(id, options = {}) {
		const searchParams = new URLSearchParams();
		if (options.html_format !== void 0) searchParams.set("html_format", options.html_format);
		const queryString = searchParams.toString();
		const path = queryString ? `/emails/receiving/${id}?${queryString}` : `/emails/receiving/${id}`;
		return await this.resend.get(path);
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/emails/receiving", options);
		return await this.resend.get(url);
	}
	async forward(options, requestOptions = {}) {
		const { emailId, to, from } = options;
		const passthrough = options.passthrough !== false;
		const emailResponse = await this.get(emailId);
		if (emailResponse.error) return {
			data: null,
			error: emailResponse.error,
			headers: emailResponse.headers
		};
		const email = emailResponse.data;
		const originalSubject = email.subject || "(no subject)";
		if (passthrough) return this.forwardPassthrough(email, {
			to,
			from,
			subject: originalSubject
		}, requestOptions);
		const forwardSubject = originalSubject.startsWith("Fwd:") ? originalSubject : `Fwd: ${originalSubject}`;
		return this.forwardWrapped(email, {
			to,
			from,
			subject: forwardSubject,
			text: "text" in options ? options.text : void 0,
			html: "html" in options ? options.html : void 0
		}, requestOptions);
	}
	async forwardPassthrough(email, options, requestOptions) {
		const { to, from, subject } = options;
		if (!email.raw?.download_url) return {
			data: null,
			error: {
				name: "validation_error",
				message: "Raw email content is not available for this email",
				statusCode: 400
			},
			headers: null
		};
		const rawResponse = await fetch(email.raw.download_url);
		if (!rawResponse.ok) return {
			data: null,
			error: {
				name: "application_error",
				message: "Failed to download raw email content",
				statusCode: rawResponse.status
			},
			headers: null
		};
		const rawEmailContent = await rawResponse.text();
		const parsed = await PostalMime.parse(rawEmailContent, { attachmentEncoding: "base64" });
		const attachments = parsed.attachments.map((attachment) => {
			const contentId = attachment.contentId ? attachment.contentId.replace(/^<|>$/g, "") : void 0;
			return {
				filename: attachment.filename,
				content: attachment.content.toString(),
				content_type: attachment.mimeType,
				content_id: contentId || void 0
			};
		});
		return await this.resend.post("/emails", {
			from,
			to,
			subject,
			text: parsed.text || void 0,
			html: parsed.html || void 0,
			attachments: attachments.length > 0 ? attachments : void 0
		}, requestOptions);
	}
	async forwardWrapped(email, options, requestOptions) {
		const { to, from, subject, text, html } = options;
		if (!email.raw?.download_url) return {
			data: null,
			error: {
				name: "validation_error",
				message: "Raw email content is not available for this email",
				statusCode: 400
			},
			headers: null
		};
		const rawResponse = await fetch(email.raw.download_url);
		if (!rawResponse.ok) return {
			data: null,
			error: {
				name: "application_error",
				message: "Failed to download raw email content",
				statusCode: rawResponse.status
			},
			headers: null
		};
		const rawEmailContent = await rawResponse.text();
		return await this.resend.post("/emails", {
			from,
			to,
			subject,
			text,
			html,
			attachments: [{
				filename: "forwarded_message.eml",
				content: Buffer.from(rawEmailContent).toString("base64"),
				content_type: "message/rfc822"
			}]
		}, requestOptions);
	}
};
var Emails = class {
	constructor(resend) {
		this.resend = resend;
		this.attachments = new Attachments$1(resend);
		this.receiving = new Receiving(resend);
	}
	async send(payload, options = {}) {
		return this.create(payload, options);
	}
	async create(payload, options = {}) {
		const body = { ...payload };
		if (payload.react) body.html = await render(payload.react);
		return await this.resend.post("/emails", parseEmailToApiOptions(body), options);
	}
	async get(id) {
		return await this.resend.get(`/emails/${id}`);
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/emails", options);
		return await this.resend.get(url);
	}
	async update(payload) {
		return await this.resend.patch(`/emails/${payload.id}`, { scheduled_at: payload.scheduledAt });
	}
	async cancel(id) {
		return await this.resend.post(`/emails/${id}/cancel`);
	}
	async share(id, payload) {
		return await this.resend.post(`/emails/${id}/share`, { expires_in: payload?.expiresIn });
	}
	async metrics(options = {}) {
		const queryString = buildMetricsQuery(options);
		const url = queryString ? `/emails/metrics?${queryString}` : "/emails/metrics";
		return await this.resend.get(url);
	}
};
function buildMetricsQuery(options) {
	const params = {
		start_date: options.startDate,
		end_date: options.endDate,
		timezone: options.timezone,
		granularity: options.granularity,
		metrics: options.metrics?.join(","),
		dimensions: options.dimensions?.join(","),
		domain_id: options.domainId?.join(","),
		email_id: options.emailId?.join(","),
		broadcast_id: options.broadcastId?.join(",")
	};
	const searchParams = new URLSearchParams();
	for (const [key, value] of Object.entries(params)) if (value !== void 0 && value !== "") searchParams.set(key, value);
	return searchParams.toString();
}
var Events$1 = class {
	constructor(resend) {
		this.resend = resend;
	}
	async send(payload) {
		return await this.resend.post("/events/send", parseEventToApiOptions(payload));
	}
	async create(payload) {
		return await this.resend.post("/events", payload);
	}
	async get(identifier) {
		return await this.resend.get(`/events/${encodeURIComponent(identifier)}`);
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/events", options);
		return await this.resend.get(url);
	}
	async update(identifier, payload) {
		return await this.resend.patch(`/events/${encodeURIComponent(identifier)}`, payload);
	}
	async remove(identifier) {
		return await this.resend.delete(`/events/${encodeURIComponent(identifier)}`);
	}
};
var Logs = class {
	constructor(resend) {
		this.resend = resend;
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/logs", options);
		return await this.resend.get(url);
	}
	async get(id) {
		return await this.resend.get(`/logs/${id}`);
	}
};
var OAuthGrants = class {
	constructor(resend) {
		this.resend = resend;
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/oauth/grants", options);
		return await this.resend.get(url);
	}
	async revoke(id) {
		return await this.resend.delete(`/oauth/grants/${id}`);
	}
};
var Segments = class {
	constructor(resend) {
		this.resend = resend;
	}
	async create(payload, options = {}) {
		return await this.resend.post("/segments", payload, options);
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/segments", options);
		return await this.resend.get(url);
	}
	async get(id) {
		return await this.resend.get(`/segments/${id}`);
	}
	async update(id, payload) {
		return await this.resend.patch(`/segments/${id}`, payload);
	}
	async remove(id) {
		return await this.resend.delete(`/segments/${id}`);
	}
};
var Batch = class {
	constructor(resend) {
		this.resend = resend;
	}
	async add(options) {
		return this.resend.post("/suppressions/batch/add", options);
	}
	async remove(options) {
		return this.resend.post("/suppressions/batch/remove", options);
	}
};
var missingIdentifierError = () => ({
	data: null,
	headers: null,
	error: {
		message: "Missing `id` field.",
		statusCode: null,
		name: "missing_required_field"
	}
});
var Suppressions = class {
	constructor(resend) {
		this.resend = resend;
		this.batch = new Batch(resend);
	}
	async add(options) {
		return this.resend.post("/suppressions", options);
	}
	async list(options = {}) {
		const queryString = buildSuppressionsQuery(options);
		const url = queryString ? `/suppressions?${queryString}` : "/suppressions";
		return this.resend.get(url);
	}
	async get(idOrEmail) {
		if (!idOrEmail) return missingIdentifierError();
		return this.resend.get(`/suppressions/${encodeURIComponent(idOrEmail)}`);
	}
	async remove(idOrEmail) {
		if (!idOrEmail) return missingIdentifierError();
		return this.resend.delete(`/suppressions/${encodeURIComponent(idOrEmail)}`);
	}
};
function buildSuppressionsQuery(options) {
	const { origin, ...pagination } = options;
	const searchParams = new URLSearchParams(buildPaginationQuery(pagination));
	if (origin) searchParams.set("origin", origin);
	return searchParams.toString();
}
function getPaginationQueryProperties(options = {}) {
	const query = new URLSearchParams();
	if (options.before) query.set("before", options.before);
	if (options.after) query.set("after", options.after);
	if (options.limit) query.set("limit", options.limit.toString());
	return query.size > 0 ? `?${query.toString()}` : "";
}
function parseVariables(variables) {
	return variables?.map((variable) => ({
		key: variable.key,
		type: variable.type,
		fallback_value: variable.fallbackValue
	}));
}
function parseTemplateToApiOptions(template) {
	return {
		name: "name" in template ? template.name : void 0,
		subject: template.subject,
		html: template.html,
		text: template.text,
		alias: template.alias,
		from: template.from,
		reply_to: template.replyTo,
		variables: parseVariables(template.variables)
	};
}
var ChainableTemplateResult = class {
	constructor(promise, publishFn) {
		this.promise = promise;
		this.publishFn = publishFn;
	}
	then(onfulfilled, onrejected) {
		return this.promise.then(onfulfilled, onrejected);
	}
	async publish() {
		const { data, error } = await this.promise;
		if (error) return {
			data: null,
			headers: null,
			error
		};
		return this.publishFn(data.id);
	}
};
var Templates = class {
	constructor(resend) {
		this.resend = resend;
	}
	create(payload) {
		return new ChainableTemplateResult(this.performCreate(payload), this.publish.bind(this));
	}
	async performCreate(payload) {
		const body = { ...payload };
		if (payload.react) body.html = await render(payload.react);
		return this.resend.post("/templates", parseTemplateToApiOptions(body));
	}
	async remove(identifier) {
		return await this.resend.delete(`/templates/${identifier}`);
	}
	async get(identifier) {
		return await this.resend.get(`/templates/${identifier}`);
	}
	async list(options = {}) {
		return this.resend.get(`/templates${getPaginationQueryProperties(options)}`);
	}
	duplicate(identifier) {
		return new ChainableTemplateResult(this.resend.post(`/templates/${identifier}/duplicate`), this.publish.bind(this));
	}
	async publish(identifier) {
		return await this.resend.post(`/templates/${identifier}/publish`);
	}
	async update(identifier, payload) {
		return await this.resend.patch(`/templates/${identifier}`, parseTemplateToApiOptions(payload));
	}
};
var Topics = class {
	constructor(resend) {
		this.resend = resend;
	}
	async create(payload) {
		const { defaultSubscription, ...body } = payload;
		return await this.resend.post("/topics", {
			...body,
			default_subscription: defaultSubscription
		});
	}
	async list() {
		return await this.resend.get("/topics");
	}
	async get(id) {
		if (!id) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		return await this.resend.get(`/topics/${id}`);
	}
	async update(payload) {
		if (!payload.id) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		return await this.resend.patch(`/topics/${payload.id}`, payload);
	}
	async remove(id) {
		if (!id) return {
			data: null,
			headers: null,
			error: {
				message: "Missing `id` field.",
				statusCode: null,
				name: "missing_required_field"
			}
		};
		return await this.resend.delete(`/topics/${id}`);
	}
};
var Attempts = class {
	constructor(resend) {
		this.resend = resend;
	}
	async list(options) {
		const { webhookId, eventId } = options;
		const url = buildPaginationUrl(`/webhooks/${webhookId}/events/${eventId}/attempts`, options);
		return await this.resend.get(url);
	}
};
var Events = class {
	constructor(resend) {
		this.resend = resend;
		this.attempts = new Attempts(resend);
	}
	async list(options) {
		const { webhookId } = options;
		const url = buildPaginationUrl(`/webhooks/${webhookId}/events`, options);
		return await this.resend.get(url);
	}
	async get(options) {
		const { webhookId, eventId } = options;
		return await this.resend.get(`/webhooks/${webhookId}/events/${eventId}`);
	}
	async replay(options) {
		const { webhookId, eventId } = options;
		return await this.resend.post(`/webhooks/${webhookId}/events/${eventId}/replay`);
	}
};
var Webhooks = class {
	constructor(resend) {
		this.resend = resend;
		this.events = new Events(resend);
	}
	async create(payload, options = {}) {
		return await this.resend.post("/webhooks", payload, options);
	}
	async get(id) {
		return await this.resend.get(`/webhooks/${id}`);
	}
	async list(options = {}) {
		const url = buildPaginationUrl("/webhooks", options);
		return await this.resend.get(url);
	}
	async update(id, payload) {
		return await this.resend.patch(`/webhooks/${id}`, payload);
	}
	async remove(id) {
		return await this.resend.delete(`/webhooks/${id}`);
	}
	async rotateSigningSecret(id) {
		return await this.resend.post(`/webhooks/${id}/signing-secret/rotate`);
	}
	verify(payload) {
		return new import_dist.Webhook(payload.webhookSecret).verify(payload.payload, {
			"webhook-id": payload.headers.id,
			"webhook-timestamp": payload.headers.timestamp,
			"webhook-signature": payload.headers.signature
		});
	}
};
var defaultBaseUrl = "https://api.resend.com";
var defaultUserAgent = `resend-node:${version}`;
function getDefaultBaseUrl() {
	return typeof process !== "undefined" && process.env ? process.env.RESEND_BASE_URL || defaultBaseUrl : defaultBaseUrl;
}
function getDefaultUserAgent() {
	return typeof process !== "undefined" && process.env ? process.env.RESEND_USER_AGENT || defaultUserAgent : defaultUserAgent;
}
var Resend = class {
	constructor(key, options) {
		this.key = key;
		this.segments = new Segments(this);
		this.apiKeys = new ApiKeys(this);
		this.audiences = this.segments;
		this.automations = new Automations(this);
		this.batch = new Batch$1(this);
		this.broadcasts = new Broadcasts(this);
		this.contactProperties = new ContactProperties(this);
		this.contacts = new Contacts(this);
		this.domains = new Domains(this);
		this.emails = new Emails(this);
		this.events = new Events$1(this);
		this.logs = new Logs(this);
		this.oauthGrants = new OAuthGrants(this);
		this.suppressions = new Suppressions(this);
		this.templates = new Templates(this);
		this.topics = new Topics(this);
		this.webhooks = new Webhooks(this);
		if (!key) {
			if (typeof process !== "undefined" && process.env) this.key = process.env.RESEND_API_KEY;
			if (!this.key) throw new Error("Missing API key. Pass it to the constructor `new Resend(\"re_123\")`");
		}
		this.baseUrl = options?.baseUrl ?? getDefaultBaseUrl();
		this.userAgent = options?.userAgent ?? getDefaultUserAgent();
		this.headers = new Headers({
			Authorization: `Bearer ${this.key}`,
			"User-Agent": this.userAgent,
			"Content-Type": "application/json"
		});
	}
	logError(error, path, status) {
		if (typeof process !== "undefined" && process.env && false);
	}
	async fetchRequest(path, options = {}) {
		try {
			const response = await fetch(`${this.baseUrl}${path}`, options);
			if (!response.ok) try {
				const rawError = await response.text();
				const parsedError = JSON.parse(rawError);
				this.logError(parsedError, path, response.status);
				return {
					data: null,
					error: parsedError,
					headers: Object.fromEntries(response.headers.entries())
				};
			} catch (err) {
				if (err instanceof SyntaxError) {
					const error = {
						name: "application_error",
						statusCode: response.status,
						message: "Internal server error. We are unable to process your request right now, please try again later."
					};
					this.logError(error, path, response.status);
					return {
						data: null,
						error,
						headers: Object.fromEntries(response.headers.entries())
					};
				}
				const error = {
					message: response.statusText,
					statusCode: response.status,
					name: "application_error"
				};
				if (err instanceof Error) {
					const errorWithMessage = {
						...error,
						message: err.message
					};
					this.logError(errorWithMessage, path, response.status);
					return {
						data: null,
						error: errorWithMessage,
						headers: Object.fromEntries(response.headers.entries())
					};
				}
				this.logError(error, path, response.status);
				return {
					data: null,
					error,
					headers: Object.fromEntries(response.headers.entries())
				};
			}
			return {
				data: await response.json(),
				error: null,
				headers: Object.fromEntries(response.headers.entries())
			};
		} catch {
			const error = {
				name: "application_error",
				statusCode: null,
				message: "Unable to fetch data. The request could not be resolved."
			};
			this.logError(error, path);
			return {
				data: null,
				error,
				headers: null
			};
		}
	}
	async post(path, entity, options = {}) {
		const headers = new Headers(this.headers);
		const isFormData = typeof FormData !== "undefined" && entity instanceof FormData;
		if (isFormData) headers.delete("Content-Type");
		if (options.headers) for (const [key, value] of new Headers(options.headers).entries()) headers.set(key, value);
		if (options.idempotencyKey) headers.set("Idempotency-Key", options.idempotencyKey);
		const requestOptions = {
			method: "POST",
			body: isFormData ? entity : JSON.stringify(entity),
			...options,
			headers
		};
		return this.fetchRequest(path, requestOptions);
	}
	async get(path, options = {}) {
		const headers = new Headers(this.headers);
		if (options.headers) for (const [key, value] of new Headers(options.headers).entries()) headers.set(key, value);
		const requestOptions = {
			method: "GET",
			...options,
			headers
		};
		return this.fetchRequest(path, requestOptions);
	}
	async put(path, entity, options = {}) {
		const headers = new Headers(this.headers);
		if (options.headers) for (const [key, value] of new Headers(options.headers).entries()) headers.set(key, value);
		const requestOptions = {
			method: "PUT",
			body: JSON.stringify(entity),
			...options,
			headers
		};
		return this.fetchRequest(path, requestOptions);
	}
	async patch(path, entity, options = {}) {
		const headers = new Headers(this.headers);
		if (options.headers) for (const [key, value] of new Headers(options.headers).entries()) headers.set(key, value);
		const requestOptions = {
			method: "PATCH",
			body: JSON.stringify(entity),
			...options,
			headers
		};
		return this.fetchRequest(path, requestOptions);
	}
	async delete(path, query, options = {}) {
		const headers = new Headers(this.headers);
		if (options.headers) for (const [key, value] of new Headers(options.headers).entries()) headers.set(key, value);
		const requestOptions = {
			method: "DELETE",
			body: query === void 0 ? void 0 : JSON.stringify(query),
			...options,
			headers
		};
		return this.fetchRequest(path, requestOptions);
	}
};
//#endregion
export { Resend as t };
