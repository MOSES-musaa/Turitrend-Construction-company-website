import { r as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as BriefcaseBusiness, M as ArrowUpRight, N as ArrowRight, P as ArrowLeft, S as GitBranch, b as House, f as MessageSquareText, j as BadgeCheck, k as Building2, o as ShieldCheck, u as PiggyBank, v as Layers, w as ClipboardList, x as HardHat } from "../_libs/lucide-react.mjs";
import { _ as whyTuriend, a as clientTypes, h as track, l as processSteps, m as services, n as CtaLink, o as company, r as WhatsAppCta, u as projectFinder } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as CtaBand } from "./cta-band-CNJbZvLK.mjs";
import { t as Reveal } from "./reveal-9iJXRnDn.mjs";
import { t as SectionHeading } from "./section-heading-CNHs7aX1.mjs";
import { t as aboutImage } from "./placeholders-CL4ero5s.mjs";
import { t as blueprint_lines_default } from "./blueprint-lines-Bykqsr2s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CfmC-AhK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero_architecture_default = "/assets/hero-architecture-DmdUpQVN.jpg";
var hero_construction_default = "/assets/hero-construction-DyKaLMTn.jpg";
var clientIcons = [
	House,
	Building2,
	HardHat,
	BriefcaseBusiness,
	ClipboardList
];
var whyIcons = [
	Layers,
	GitBranch,
	MessageSquareText,
	BadgeCheck,
	PiggyBank,
	ShieldCheck
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden bg-ink text-ink-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCarousel, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-r from-ink via-ink/85 to-ink/30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-x relative grid gap-12 pt-16 pb-16 md:min-h-[82vh] md:grid-cols-12 md:content-center md:pt-24 md:pb-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "md:col-span-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "label-tech flex items-center gap-3 text-ink-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: company.location })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "display-1 mt-6",
								children: ["Turiend Construction", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-accent",
									children: "Limited"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-8 max-w-2xl text-lg leading-relaxed text-ink-foreground/85 md:text-xl",
								children: "Building, renovations, infrastructure, electrical, water, fencing and project management — handled by one team, so you are not left coordinating six different contractors on your own site."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 flex flex-col gap-3 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CtaLink, {
									to: "/quote",
									variant: "accent",
									size: "lg",
									onClick: () => track("cta_click", {
										context: "hero",
										cta: "quote"
									}),
									children: ["Request a Quote", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
										className: "size-4",
										"aria-hidden": "true"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaLink, {
									to: "/services",
									variant: "outlineLight",
									size: "lg",
									children: "Explore our services"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "grid grid-cols-2 gap-px self-end border border-ink-line bg-ink-line md:col-span-4 md:grid-cols-1",
						children: [
							["Building & civil", "Groundworks to finishes"],
							["Water & electrical", "Installations and maintenance"],
							["Perimeter & access", "Fences, gates, automation"],
							["Management", "Project and property oversight"]
						].map(([term, desc]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-ink p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-sm font-semibold",
								children: term
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-xs text-ink-muted",
								children: desc
							})]
						}, term))
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-12 lg:items-center lg:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "label-tech flex items-center gap-3 text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-8 bg-line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Who we are" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-6 max-w-xl text-4xl font-semibold tracking-tight md:text-5xl",
							children: "Construction work, coordinated properly."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-7 max-w-xl space-y-5 text-base leading-8 text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Turiend Construction Limited is a Kenyan construction company. We take on building and civil works, water and electrical installations, perimeter and access works, biodigesters, and the management of projects and properties." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We work the other way round — agree the scope, agree the sequence, then keep you informed while the work is carried out." })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-9 border-t border-line pt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "label-tech text-accent",
								children: "Our approach"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm font-medium",
								children: "Clear scope. Proper supervision. Accountable delivery."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/about",
							className: "group mt-8 inline-flex items-center gap-2 text-sm font-medium transition-colors hover:text-accent",
							children: ["More about Turiend", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
								className: "size-4 transition-transform group-hover:translate-x-1",
								"aria-hidden": "true"
							})]
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 100,
					className: "relative lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pointer-events-none absolute -inset-3 border border-line/60",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative overflow-hidden bg-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: aboutImage.src,
										alt: aboutImage.alt,
										width: 1600,
										height: 1e3,
										loading: "lazy",
										className: "aspect-4/3 w-full object-cover transition-transform duration-1200ms ease-out hover:scale-[1.02]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute inset-0 bg-linear-to-t from-ink/45 via-transparent to-transparent",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-4 left-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "label-tech bg-ink/85 px-3 py-2 text-ink-foreground",
											children: "Turiend Construction"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute right-4 top-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "label-tech bg-background/90 px-3 py-2" })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex items-start justify-between gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-md text-xs leading-5 text-muted-foreground",
									children: "Coordinated construction services across building, infrastructure and property works."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "label-tech shrink-0 text-muted-foreground",
									children: "Nairobi · Kenya"
								})]
							})
						]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x section-y",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "What we do",
					title: "Six core service areas",
					intro: "Each area can be a project on its own, or one part of a larger scope we deliver together."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-px border border-line bg-line md:mt-16 md:grid-cols-2 lg:grid-cols-3",
					children: services.map((service, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 60,
						className: "bg-background",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/services/$slug",
							params: { slug: service.slug },
							className: "group flex h-full flex-col p-7 transition-colors hover:bg-ink hover:text-ink-foreground md:p-9",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-6 text-xl leading-tight font-semibold tracking-tight md:text-2xl",
									children: service.shortTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 flex-1 text-sm leading-relaxed text-muted-foreground group-hover:text-ink-muted",
									children: service.summary
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "label-tech mt-8 inline-flex items-center gap-2",
									children: ["Discuss this service", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" })]
								})
							]
						})
					}, service.slug))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Project finder",
				title: "What are you planning?",
				intro: "Pick the closest description and we will take you to the right place."
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-3 md:mt-14 md:grid-cols-2",
				children: projectFinder.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 50,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/services/$slug",
						params: { slug: item.slug },
						className: "group flex min-h-16 items-center justify-between gap-4 border border-line bg-card px-6 py-5 text-base font-medium transition-all hover:border-ink hover:bg-ink hover:text-ink-foreground md:text-lg",
						children: [item.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5 shrink-0 text-accent transition-transform group-hover:translate-x-1" })]
					})
				}, item.label))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-ink text-ink-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x section-y",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "How we work",
					tone: "dark",
					align: "split",
					title: "Six steps from first conversation to handover",
					intro: "The same sequence applies whether the job is a single room or a full build. It is what keeps scope, cost and programme in one place."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 grid gap-10 md:mt-16 md:grid-cols-12 md:items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "md:col-span-7",
						children: processSteps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							as: "div",
							delay: i * 60,
							className: "border-t border-ink-line py-6 last:border-b",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-semibold tracking-tight",
								children: step.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-ink-muted",
								children: step.text
							})] })
						}, step.number))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "md:col-span-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: blueprint_lines_default,
							alt: "Technical isometric line drawing of a timber roof structure",
							width: 1400,
							height: 1e3,
							loading: "lazy",
							className: "w-full border border-ink-line bg-ink-foreground object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaLink, {
							to: "/how-we-work",
							variant: "outlineLight",
							size: "md",
							className: "mt-6 w-full",
							children: "See the full process"
						})]
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Who we work with",
				title: "Clients we can serve"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-4 md:mt-14 md:grid-cols-3",
				children: [clientTypes.map((client, i) => {
					const Icon = clientIcons[i];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 50,
						className: "group relative overflow-hidden border border-line bg-background p-7 transition-all duration-300 hover:-translate-y-1 hover:border-accent/50 hover:bg-card hover:shadow-xl md:p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							"aria-hidden": "true",
							className: "absolute -right-8 -bottom-8 size-28 rounded-full bg-accent/5 transition-transform duration-500 group-hover:scale-150"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex size-11 items-center justify-center border border-accent/25 bg-accent/10 text-accent transition-all duration-300 group-hover:border-accent/50 group-hover:bg-accent group-hover:text-accent-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5 transition-transform duration-300 group-hover:scale-110",
										strokeWidth: 1.8
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-7 text-lg font-semibold tracking-tight",
									children: client.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: client.text
								})
							]
						})]
					}, client.title);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden border border-line bg-surface p-8 transition-all duration-300 hover:-translate-y-1 hover:border-accent/40 hover:shadow-xl md:block lg:col-span-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech text-muted-foreground",
						children: "Not sure where you fit?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppCta, {
						message: "Hello Turiend, I would like to discuss a construction project.",
						label: "Ask us on WhatsApp",
						variant: "quiet",
						size: "sm",
						context: "home_clients",
						className: "mt-3"
					})]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x section-y",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Why Turiend",
					align: "split",
					title: "What working with us actually gives you",
					intro: "FROM CONCEPT TO CREATION."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-4 md:mt-16 md:grid-cols-2 lg:grid-cols-3",
					children: whyTuriend.map((item, i) => {
						const Icon = whyIcons[i];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							delay: i * 50,
							className: "group relative overflow-hidden border border-line bg-background p-7 transition-all duration-300 hover:-translate-y-1 hover:border-accent/50 hover:shadow-xl md:p-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-hidden": "true",
								className: "absolute -right-8 -bottom-8 size-28 rounded-full bg-accent/5 transition-transform duration-500 group-hover:scale-150"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-11 items-center justify-center border border-accent/25 bg-accent/10 text-accent transition-all duration-300 group-hover:border-accent/50 group-hover:bg-accent group-hover:text-accent-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5 transition-transform duration-300 group-hover:scale-110",
											strokeWidth: 1.8
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-7 text-lg font-semibold tracking-tight",
										children: item.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-muted-foreground",
										children: item.text
									})
								]
							})]
						}, item.title);
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {})
	] });
}
var heroSlides = [
	{
		src: hero_architecture_default,
		alt: "Abstract architectural line drawing over a dark concrete surface",
		caption: "Building & civil works"
	},
	{
		src: hero_construction_default,
		alt: "A building under construction at dusk, scaffolding and crane silhouetted",
		caption: "Groundworks to finishes"
	},
	{
		src: blueprint_lines_default,
		alt: "Technical isometric line drawing of a timber roof structure",
		caption: "Planned before it is built"
	}
];
function HeroCarousel() {
	const [index, setIndex] = (0, import_react.useState)(0);
	const go = (0, import_react.useCallback)((next) => {
		setIndex((next + heroSlides.length) % heroSlides.length);
	}, []);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => {
			setIndex((current) => (current + 1) % heroSlides.length);
		}, 6500);
		return () => {
			window.clearInterval(timer);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 overflow-hidden",
		role: "region",
		"aria-roledescription": "carousel",
		"aria-label": "Turiend Construction highlights",
		children: [heroSlides.map((slide, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `absolute inset-0 overflow-hidden transition-opacity duration-1800 ease-in-out ${i === index ? "opacity-100" : "opacity-0"}`,
			"aria-hidden": i !== index,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: slide.src,
				alt: i === index ? slide.alt : "",
				width: 1920,
				height: 1280,
				fetchPriority: i === 0 ? "high" : "auto",
				loading: i === 0 ? "eager" : "lazy",
				className: `size-full object-cover will-change-transform ${i === index ? "hero-carousel-image" : "scale-100"}`
			})
		}, slide.src)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-x-0 bottom-0 z-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-x pb-6 md:pb-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-5 md:flex-row md:items-end md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-10 bg-ink-line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "label-tech text-ink-muted",
							children: String(heroSlides.length).padStart(2, "0")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-md text-sm font-medium tracking-wide text-ink-foreground md:text-base",
						"aria-live": "polite",
						children: heroSlides[index].caption
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2",
							role: "tablist",
							"aria-label": "Hero slides",
							children: heroSlides.map((slide, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "tab",
								"aria-selected": i === index,
								"aria-label": `Slide ${i + 1}: ${slide.caption}`,
								onClick: () => go(i),
								className: "group flex h-6 items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `block h-px transition-all duration-500 ${i === index ? "w-10 bg-accent" : "w-5 bg-ink-foreground/30 group-hover:w-7 group-hover:bg-ink-foreground/60"}` })
							}, slide.src))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => go(index - 1),
								"aria-label": "Previous slide",
								className: "flex size-10 items-center justify-center border border-ink-line text-ink-foreground transition-colors hover:bg-ink-foreground hover:text-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
									className: "size-4",
									"aria-hidden": "true"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => go(index + 1),
								"aria-label": "Next slide",
								className: "flex size-10 items-center justify-center border-y border-r border-ink-line text-ink-foreground transition-colors hover:bg-ink-foreground hover:text-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "size-4",
									"aria-hidden": "true"
								})
							})]
						})]
					})]
				})
			})
		})]
	});
}
//#endregion
export { Home as component };
