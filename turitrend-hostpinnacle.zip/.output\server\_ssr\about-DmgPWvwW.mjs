import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { A as BriefcaseBusiness, T as ClipboardCheck, _ as Lightbulb, a as Sparkles, f as MessageSquareText, i as UsersRound, j as BadgeCheck, k as Building2, l as Ruler, n as Wrench, o as ShieldCheck, x as HardHat } from "../_libs/lucide-react.mjs";
import { a as clientTypes, m as services, o as company } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as CtaBand } from "./cta-band-CNJbZvLK.mjs";
import { t as Reveal } from "./reveal-9iJXRnDn.mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { t as SectionHeading } from "./section-heading-CNHs7aX1.mjs";
import { t as aboutImage } from "./placeholders-CL4ero5s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DmgPWvwW.js
var import_jsx_runtime = require_jsx_runtime();
var texture_concrete_default = "/assets/texture-concrete-BtuPXH0p.jpg";
var teamMembers = [
	{
		id: "james-mwendia",
		name: "James Mwendia",
		role: "Director / Managing Director",
		bio: "Construction Project Manager with over 10 years of professional experience. Responsible for strategic leadership, project oversight, construction project management, site coordination, quality control and client relations.",
		initials: "JM"
	},
	{
		id: "teresia-wanjiku",
		name: "Teresiah Wanjiku",
		role: "Director / HR Manager",
		bio: "Responsible for human resource management, administration and organizational operations, supporting effective coordination and internal management.",
		initials: "TW"
	},
	{
		id: "dennis-kinyua",
		name: "Dennis Kinyua",
		role: "Project Manager",
		bio: "Responsible for project execution, site coordination, supervision, scheduling and quality assurance.",
		initials: "DK"
	}
];
function TeamAvatar({ initials, name }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative aspect-square w-full overflow-hidden bg-surface",
		"aria-label": `${name} photo placeholder`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 opacity-60",
				style: {
					backgroundImage: "linear-gradient(to right, hsl(var(--line) / 0.35) 1px, transparent 1px), linear-gradient(to bottom, hsl(var(--line) / 0.35) 1px, transparent 1px)",
					backgroundSize: "28px 28px"
				},
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-24 w-24 items-center justify-center rounded-full border border-line bg-background text-xl font-semibold tracking-tight text-muted-foreground",
					children: initials
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute bottom-0 right-0 h-10 w-10 bg-accent",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute bottom-2 right-2 z-10 text-xs font-semibold tracking-widest text-accent-foreground",
				children: initials
			})
		]
	});
}
function TeamSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute right-0 top-0 hidden h-full w-[38%] lg:block",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-0 top-0 h-80 w-full bg-linear-to-bl from-surface via-background to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-12 top-16 h-64 w-48 border-l border-t border-line/70" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-24 top-28 h-56 w-40 border-l border-t border-line/50" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-0 top-48 h-px w-72 rotate-[-28deg] bg-accent/30" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-x pb-20 pt-8 md:pb-24 md:pt-10 relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-5xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "h-px w-12 bg-line",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "label-tech text-muted-foreground",
							children: "Our team"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 max-w-4xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "max-w-3xl text-4xl font-semibold leading-[0.98] tracking-tight md:text-5xl lg:text-6xl",
							children: [
								"The People Behind",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Our Work."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-base leading-7 text-muted-foreground md:text-lg",
							children: "Our team brings together experience, professionalism and a shared commitment to delivering quality construction solutions."
						})]
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
					children: teamMembers.map((member, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 70,
						className: "group",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "h-full overflow-hidden border border-line bg-background transition-colors duration-300 hover:border-accent/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-[7rem_minmax(0,1fr)] gap-5 p-5 md:grid-cols-[8rem_minmax(0,1fr)] md:p-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamAvatar, {
									initials: member.initials,
									name: member.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center gap-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "h-px flex-1 bg-line",
												"aria-hidden": "true"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-4 text-xl font-semibold uppercase leading-tight tracking-tight md:text-2xl",
											children: member.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-xs font-semibold uppercase leading-5 tracking-[0.16em] text-accent",
											children: member.role
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "border-t border-line px-5 py-6 md:px-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-7 text-muted-foreground md:text-[15px]",
									children: member.bio
								})
							})]
						})
					}, member.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 180,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-12 grid border-y border-line md:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b border-line py-6 md:border-b-0 md:border-r md:px-8 md:first:pl-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 text-lg font-semibold tracking-tight",
									children: "A Collaborative Team"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 max-w-xs text-sm leading-6 text-muted-foreground",
									children: "We work together towards shared goals and better project outcomes."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b border-line py-6 md:border-b-0 md:border-r md:px-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 text-lg font-semibold tracking-tight",
									children: "Professional Standards"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 max-w-xs text-sm leading-6 text-muted-foreground",
									children: "We uphold high standards in planning, coordination and delivery."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "py-6 md:px-8 md:pr-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 text-lg font-semibold tracking-tight",
									children: "Results Driven"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 max-w-xs text-sm leading-6 text-muted-foreground",
									children: "We focus on practical solutions and quality delivery from start to completion."
								})]
							})
						]
					})
				})
			]
		})]
	});
}
var values = [
	"Integrity",
	"Professionalism",
	"Quality workmanship",
	"Accountability",
	"Innovation",
	"Customer satisfaction",
	"Teamwork",
	"Safety"
];
var valueIcons = [
	ShieldCheck,
	BadgeCheck,
	Sparkles,
	ClipboardCheck,
	Lightbulb,
	UsersRound,
	MessageSquareText,
	HardHat
];
var serviceIcons = [
	Building2,
	Ruler,
	Wrench,
	ShieldCheck,
	HardHat,
	ClipboardCheck
];
var clientIcons = [
	Building2,
	UsersRound,
	Ruler,
	BriefcaseBusiness,
	ClipboardCheck
];
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "About",
			title: "A Kenyan construction company built around clear scope and proper supervision.",
			intro: "Turiend Construction Limited delivers building, civil, water and electrical works, perimeter and access works, biodigesters, and project and property management."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x pt-16 pb-10 md:pt-24 md:pb-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-12 lg:items-center lg:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "label-tech flex items-center gap-3 text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-8 bg-line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Who we are" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-6 max-w-xl text-4xl font-semibold tracking-tight md:text-5xl lg:text-6xl",
							children: "Construction work, coordinated properly."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 max-w-xl space-y-5 text-base leading-8 text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We work with homeowners, landlords, developers, businesses, institutions and property managers on projects that range from a single set of repairs to a complete building." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Because we cover several disciplines in-house, a project that needs structure, plumbing, power and external works does not have to be split across separate contracts that nobody is holding together." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"We are based in ",
									company.location,
									" and take on work in Nairobi and the surrounding counties."
								] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 border-t border-line pt-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-between gap-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "label-tech text-accent",
									children: "Our approach"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm font-medium",
									children: "Clear scope. Proper supervision. Accountable delivery."
								})] })
							})
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 100,
					className: "relative lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pointer-events-none absolute -inset-3 border border-line/60",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative overflow-hidden bg-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: aboutImage.src,
										alt: aboutImage.alt,
										width: 1600,
										height: 1e3,
										loading: "lazy",
										className: "aspect-16/10 w-full object-cover transition-transform duration-1200 ease-out hover:scale-[1.02]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-ink/45 via-transparent to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-4 left-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "label-tech bg-ink/85 px-3 py-2 text-ink-foreground",
											children: "Turiend Construction"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-4 top-4" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex items-start justify-between gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-md text-xs leading-5 text-muted-foreground",
									children: "Coordinated construction services across building, infrastructure and property works."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "label-tech shrink-0 text-muted-foreground",
									"aria-hidden": "true",
									children: "Nairobi · Kenya"
								})]
							})
						]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-ink text-ink-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x section-y grid gap-12 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "border-t border-ink-line pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech text-accent",
						children: "Vision"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "display-3 mt-5",
						children: "To become a leading construction and project management company in Kenya by delivering high-quality, innovative and sustainable construction solutions."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: 80,
					className: "border-t border-ink-line pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech text-accent",
						children: "Mission"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "display-3 mt-5",
						children: "To provide reliable, cost-effective and professional construction services while maintaining the highest standards of quality, safety and client satisfaction."
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Core values",
				title: "What we hold ourselves to"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: values.map((value, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					as: "li",
					delay: i * 40,
					className: "group relative overflow-hidden rounded-sm border border-line bg-card p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-accent/50 hover:shadow-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-hidden": "true",
						className: "absolute -right-8 -bottom-8 size-24 rounded-full bg-accent/5 transition-transform duration-500 group-hover:scale-150"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [(() => {
							const Icon = valueIcons[i] ?? ShieldCheck;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-7 flex size-10 items-center justify-center border border-accent/25 bg-accent/10 text-accent transition-all duration-300 group-hover:border-accent/50 group-hover:bg-accent group-hover:text-accent-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4.5 transition-transform duration-300 group-hover:scale-110",
									strokeWidth: 1.8
								})
							});
						})(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg font-semibold tracking-tight",
							children: value
						})]
					})]
				}, value))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x section-y grid gap-12 md:grid-cols-12 md:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "md:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: texture_concrete_default,
						alt: "Close detail of a fair-faced concrete wall surface",
						width: 1400,
						height: 1e3,
						loading: "lazy",
						className: "aspect-4/3 w-full object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: "Health & safety",
						title: "Safe sites, every day"
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 80,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-base leading-relaxed text-muted-foreground md:text-lg",
							children: "Turiend Construction Limited maintains safe working environments for employees, clients and the public. We follow safety regulations, use proper personal protective equipment and keep safety awareness active throughout project operations."
						})
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Capability",
				title: "Disciplines we cover"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
				children: services.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: i * 40,
					className: "group relative overflow-hidden rounded-sm border border-line bg-card p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-accent/50 hover:shadow-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-hidden": "true",
						className: "absolute -right-8 -bottom-8 size-28 rounded-full bg-accent/5 transition-transform duration-500 group-hover:scale-150"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							(() => {
								const Icon = serviceIcons[i];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-7 flex size-11 items-center justify-center border border-accent/25 bg-accent/10 text-accent transition-all duration-300 group-hover:border-accent/50 group-hover:bg-accent group-hover:text-accent-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5 transition-transform duration-300 group-hover:scale-110",
										strokeWidth: 1.8
									})
								});
							})(),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-semibold tracking-tight",
								children: s.shortTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted-foreground",
								children: s.summary
							})
						]
					})]
				}, s.slug))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x section-y",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Clients",
					title: "Who we work with"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
					children: clientTypes.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 40,
						className: "group relative overflow-hidden rounded-sm border border-line bg-card p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-accent/50 hover:shadow-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							"aria-hidden": "true",
							className: "absolute -right-8 -bottom-8 size-28 rounded-full bg-accent/5 transition-transform duration-500 group-hover:scale-150"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								(() => {
									const Icon = clientIcons[i];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mb-7 flex size-11 items-center justify-center border border-accent/25 bg-accent/10 text-accent transition-all duration-300 group-hover:border-accent/50 group-hover:bg-accent group-hover:text-accent-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5 transition-transform duration-300 group-hover:scale-110",
											strokeWidth: 1.8
										})
									});
								})(),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-semibold tracking-tight",
									children: c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: c.text
								})
							]
						})]
					}, c.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {
			title: "Have a project in mind?",
			text: "Tell us what you are planning and we will let you know what the works would involve.",
			whatsappMessage: "Hello Turiend, I would like to discuss a construction project.",
			context: "about"
		})
	] });
}
//#endregion
export { About as component };
