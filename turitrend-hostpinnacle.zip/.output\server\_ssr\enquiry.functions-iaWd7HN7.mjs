import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-Cxmnb3Iu.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { t as enquirySchema } from "./enquiry-schema-CRzDW4x3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enquiry.functions-iaWd7HN7.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var submitEnquiry = createServerFn({ method: "POST" }).validator(enquirySchema).handler(createSsrRpc("617707e00effff11fe2ad158ad24aa66c3e087d1885e1e35dc054328f3e2b494"));
//#endregion
export { submitEnquiry as t };
