import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { l as processSteps } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as CtaBand } from "./cta-band-CNJbZvLK.mjs";
import { t as Reveal } from "./reveal-9iJXRnDn.mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { t as SectionHeading } from "./section-heading-CNHs7aX1.mjs";
import { n as processImage } from "./placeholders-CL4ero5s.mjs";
import { t as blueprint_lines_default } from "./blueprint-lines-Bykqsr2s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/how-we-work-Bov7zvP5.js
var import_jsx_runtime = require_jsx_runtime();
var detail = {
	"01": ["A first conversation about what you want to achieve, the property, and any constraints you already know about.", "We ask about budget range and timing early — it changes what we would recommend."],
	"02": ["A site visit where the works require it. We look at existing conditions, access, services and anything that will affect sequencing.", "Drawings, specifications or an existing bill of quantities are reviewed at this stage."],
	"03": ["We set out the approach and the cost information against a defined scope.", "Where there are options — materials, phasing, specification — we put the cost difference in front of you rather than deciding for you."],
	"04": ["Resources, materials and the trades required are organized before work starts on site.", "Site setup and any temporary arrangements are agreed with you."],
	"05": ["Work proceeds to the agreed scope with supervision on site.", "Progress, workmanship and coordination between trades are monitored, and you are kept informed as the work moves."],
	"06": ["Completed works are reviewed against the agreed scope.", "Outstanding items are tracked to completion before the project is closed out and handed over."]
};
function HowWeWork() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "How we work",
			title: "Six steps, in the same order, every time.",
			intro: "Whether the job is a set of repairs or a full building, the sequence is what keeps scope, cost and programme under control."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 md:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: processSteps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						as: "div",
						delay: i * 50,
						className: "border-t border-line py-10 last:border-b",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "display-3",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-2xl text-base leading-relaxed md:text-lg",
								children: step.text
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-5 max-w-2xl space-y-2.5",
								children: (detail[step.number] ?? []).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border-l-2 border-line pl-4 text-sm leading-relaxed text-muted-foreground",
									children: d
								}, d))
							})
						] })
					}, step.number)) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "md:col-span-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sticky top-28",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative mb-6 overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: processImage.src,
									alt: processImage.alt,
									width: 1400,
									height: 1e3,
									loading: "lazy",
									className: "aspect-4/3 w-full object-cover"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: blueprint_lines_default,
								alt: "Isometric technical drawing of a building frame and roof structure",
								width: 1400,
								height: 1e3,
								loading: "lazy",
								className: "w-full border border-line object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
								className: "mt-10",
								eyebrow: "Reporting",
								title: "You always know where the project stands",
								as: "h2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-sm leading-relaxed text-muted-foreground",
								children: "Reporting frequency and format are agreed at the start of the engagement, so there is no ambiguity about when you will hear from us or what will be covered."
							})
						]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {
			title: "Start at step one.",
			text: "Tell us what you are planning and we will take it from understanding the requirement.",
			context: "how_we_work"
		})
	] });
}
//#endregion
export { HowWeWork as component };
