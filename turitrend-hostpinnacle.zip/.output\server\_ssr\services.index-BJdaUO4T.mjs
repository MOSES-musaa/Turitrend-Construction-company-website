import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { m as services } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as CtaBand } from "./cta-band-CNJbZvLK.mjs";
import { t as Reveal } from "./reveal-9iJXRnDn.mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { r as serviceImages } from "./placeholders-CL4ero5s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.index-BJdaUO4T.js
var import_jsx_runtime = require_jsx_runtime();
function ServicesIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Services",
			title: "Six core service areas.",
			intro: "Take one on its own, or combine several into a single scope with one team responsible for the result."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-12 flex flex-col gap-5 border-b border-line pb-6 md:flex-row md:items-end md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech text-accent",
					children: "Our capabilities"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display-3 mt-3 max-w-2xl",
					children: "Practical construction work, properly coordinated."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-sm leading-relaxed text-muted-foreground md:text-right",
					children: "From individual works to broader project scopes, we coordinate the people, materials and sequence needed to move the work forward."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-px border border-line bg-line md:grid-cols-2",
				children: services.map((service, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 60,
					className: "bg-background",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/services/$slug",
						params: { slug: service.slug },
						className: "group block h-full transition-colors duration-300 hover:bg-ink hover:text-ink-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: serviceImages[service.slug].src,
								alt: serviceImages[service.slug].alt,
								width: 1200,
								height: 800,
								loading: i < 2 ? "eager" : "lazy",
								className: "aspect-video w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-ink/70 via-transparent to-transparent opacity-70" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-64 flex-col p-7 md:p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "max-w-lg text-xl font-semibold tracking-tight md:text-2xl",
										children: service.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-9 shrink-0 items-center justify-center border border-line transition-colors group-hover:border-ink-line",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
											className: "size-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5",
											"aria-hidden": "true"
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-xl text-sm leading-relaxed text-muted-foreground group-hover:text-ink-muted",
									children: service.summary
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-auto flex items-center justify-between gap-4 pt-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-x-3 gap-y-2",
										children: service.includes.flatMap((group) => group.items).slice(0, 3).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "label-tech text-muted-foreground group-hover:text-ink-muted",
											children: item
										}, item))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "label-tech shrink-0 text-accent",
										children: "View service"
									})]
								})
							]
						})]
					})
				}, service.slug))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-14 overflow-hidden bg-ink md:h-20",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-b from-background via-background/60 to-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 left-0 h-px w-full bg-ink-line" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {
			title: "Not sure which service you need?",
			text: "Describe the problem rather than the trade — we will tell you what the work involves and who needs to be on site.",
			context: "services_index"
		})
	] });
}
//#endregion
export { ServicesIndex as component };
