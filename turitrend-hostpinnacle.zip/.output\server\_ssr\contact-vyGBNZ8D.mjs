import { r as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { d as Phone, g as Mail, h as MapPin, s as Send } from "../_libs/lucide-react.mjs";
import { h as track, n as CtaLink, o as company, r as WhatsAppCta, t as CtaButton } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as Reveal } from "./reveal-9iJXRnDn.mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { t as SectionHeading } from "./section-heading-CNHs7aX1.mjs";
import { t as submitEnquiry } from "./enquiry.functions-iaWd7HN7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-vyGBNZ8D.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fieldClass = "min-h-11 w-full border border-input bg-card px-3.5 py-3 text-sm outline-none transition-colors focus:border-ink";
function Contact() {
	const [sent, setSent] = (0, import_react.useState)(false);
	const [sending, setSending] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	async function onSubmit(event) {
		event.preventDefault();
		if (sending) return;
		setSending(true);
		setError("");
		const data = new FormData(event.currentTarget);
		try {
			await submitEnquiry({ data: {
				type: "contact",
				name: String(data.get("name") ?? ""),
				phone: String(data.get("phone") ?? ""),
				email: String(data.get("email") ?? ""),
				message: String(data.get("message") ?? "")
			} });
			track("contact_submitted", { context: "contact_page" });
			setSent(true);
		} catch (submissionError) {
			console.error("Contact form submission failed:", submissionError);
			setError("We couldn't send your message right now. Please try again or contact us directly on WhatsApp.");
		} finally {
			setSending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Contact",
		title: "Talk to Turiend Construction Limited.",
		intro: "Call, message on WhatsApp or send the details of your project. We respond during working hours."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "container-x section-y grid gap-12 md:grid-cols-12 md:gap-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:col-span-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Details",
					title: company.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("address", {
					className: "mt-8 not-italic",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: company.phoneHref,
								onClick: () => track("phone_click", { context: "contact_page" }),
								className: "group flex items-start gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "mt-1 size-5 shrink-0 text-accent",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "label-tech block text-muted-foreground",
									children: "Phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg font-semibold group-hover:text-accent",
									children: company.phone
								})] })]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: company.emailHref,
								onClick: () => track("email_click", { context: "contact_page" }),
								className: "group flex items-start gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "mt-1 size-5 shrink-0 text-accent",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "label-tech block text-muted-foreground",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg font-semibold break-all group-hover:text-accent",
									children: company.email
								})] })]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
									className: "mt-1 size-5 shrink-0 text-accent",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "label-tech block text-muted-foreground",
										children: "Location"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-lg font-semibold",
										children: company.location
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-sm text-muted-foreground",
										children: company.postal
									})
								] })]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppCta, {
						message: "Hello Turiend, I would like to discuss a construction project.",
						variant: "ink",
						context: "contact_page"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaLink, {
						to: "/quote",
						variant: "outline",
						children: "Request a Quote"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
			className: "md:col-span-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Message",
				title: "Send us a message"
			}), sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 border border-line bg-card p-8 md:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech text-accent",
						children: "Message sent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "display-3 mt-4",
						children: "Thank you, we have received your message."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground",
						children: "Your enquiry has been sent to the Turiend team. We will review the details and get back to you during working hours."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppCta, {
							message: "Hello Turiend, I just sent a message through your website and would like to follow up.",
							variant: "ink",
							context: "contact_confirmation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
							variant: "outline",
							onClick: () => {
								setSent(false);
								setError("");
							},
							children: "Write another message"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-8 grid gap-5",
				noValidate: false,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-5 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "name",
							className: "label-tech text-muted-foreground",
							children: "Your name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "name",
							name: "name",
							required: true,
							minLength: 2,
							autoComplete: "name",
							className: `mt-2 ${fieldClass}`,
							disabled: sending
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "phone",
							className: "label-tech text-muted-foreground",
							children: "Phone"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "phone",
							name: "phone",
							type: "tel",
							required: true,
							minLength: 7,
							autoComplete: "tel",
							className: `mt-2 ${fieldClass}`,
							disabled: sending
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "email",
						className: "label-tech text-muted-foreground",
						children: "Email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "email",
						name: "email",
						type: "email",
						autoComplete: "email",
						className: `mt-2 ${fieldClass}`,
						disabled: sending
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "message",
						className: "label-tech text-muted-foreground",
						children: "About the project"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "message",
						name: "message",
						required: true,
						minLength: 10,
						rows: 6,
						placeholder: "Location, what you want done, and where the project currently stands.",
						className: `mt-2 ${fieldClass}`,
						disabled: sending
					})] }),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						role: "alert",
						className: "border border-destructive/30 bg-destructive/5 p-4 text-sm leading-relaxed text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Your message is sent securely through the website. You do not need an email application installed on your device."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CtaButton, {
						type: "submit",
						variant: "ink",
						size: "lg",
						disabled: sending,
						className: "justify-self-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
							className: "size-4",
							"aria-hidden": "true"
						}), sending ? "Sending message..." : "Send message"]
					})
				]
			})]
		})]
	})] });
}
//#endregion
export { Contact as component };
