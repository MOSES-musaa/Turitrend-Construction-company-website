import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { t as insights } from "./insights-CLXMg3hL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights.index-BR_brZup.js
var import_jsx_runtime = require_jsx_runtime();
function InsightsPage() {
	const featuredInsight = insights.find((insight) => insight.featured);
	const otherInsights = insights.filter((insight) => insight.slug !== featuredInsight?.slug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Insights",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				"Perspectives on construction,",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
				"property and better building."
			] }),
			intro: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Practical ideas, project knowledge and perspectives from Turiend Construction Limited." })
		}),
		featuredInsight && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "grid overflow-hidden border border-line bg-card lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-16/10 overflow-hidden bg-muted lg:aspect-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: featuredInsight.image,
						alt: featuredInsight.title,
						className: "h-full w-full object-cover transition-transform duration-500 hover:scale-[1.02]"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-center p-8 md:p-12 lg:p-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label-tech text-accent",
							children: "Featured insight"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-xs uppercase tracking-wider text-muted-foreground",
							children: featuredInsight.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-semibold tracking-tight md:text-4xl",
							children: featuredInsight.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-base leading-8 text-muted-foreground",
							children: featuredInsight.excerpt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 text-xs text-muted-foreground",
							children: [
								featuredInsight.date,
								" · ",
								featuredInsight.readTime
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/insights/$slug",
							params: { slug: featuredInsight.slug },
							className: "mt-8 inline-flex w-fit items-center gap-2 text-sm font-medium transition-colors hover:text-accent",
							children: ["Read article", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								children: "→"
							})]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "label-tech text-accent",
				children: "All insights"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-3xl font-semibold tracking-tight",
				children: "Ideas worth exploring."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 md:grid-cols-2",
				children: otherInsights.map((insight) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "group overflow-hidden border border-line bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "aspect-16/10 overflow-hidden bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: insight.image,
							alt: insight.title,
							className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.02]",
							loading: "lazy"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6 md:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "label-tech text-accent",
								children: insight.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-2xl font-semibold tracking-tight",
								children: insight.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm leading-7 text-muted-foreground",
								children: insight.excerpt
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 text-xs text-muted-foreground",
								children: [
									insight.date,
									" · ",
									insight.readTime
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/insights/$slug",
								params: { slug: insight.slug },
								className: "mt-6 inline-flex items-center gap-2 text-sm font-medium transition-colors hover:text-accent",
								children: ["Read article", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "→"
								})]
							})
						]
					})]
				}, insight.slug))
			})]
		})
	] });
}
//#endregion
export { InsightsPage as component };
