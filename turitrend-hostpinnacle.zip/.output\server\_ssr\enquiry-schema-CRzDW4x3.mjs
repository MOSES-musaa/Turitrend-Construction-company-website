import { i as stringType, n as literalType, r as objectType, t as discriminatedUnionType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enquiry-schema-CRzDW4x3.js
var contactEnquirySchema = objectType({
	type: literalType("contact"),
	name: stringType().trim().min(2, "Please enter your name."),
	phone: stringType().trim().min(7, "Please enter a valid phone number."),
	email: stringType().trim().email("Please enter a valid email address.").optional().or(literalType("")),
	message: stringType().trim().min(10, "Please provide a little more information about the project.")
});
var quoteEnquirySchema = objectType({
	type: literalType("quote"),
	service: stringType().trim().min(1, "Service is required."),
	location: stringType().trim().min(2, "Project location is required."),
	details: stringType().trim().min(10, "Please provide more project details."),
	stage: stringType().trim().min(1, "Project stage is required."),
	name: stringType().trim().min(2, "Please enter your name."),
	phone: stringType().trim().min(7, "Please enter a valid phone number."),
	email: stringType().trim().email("Please enter a valid email address.").optional().or(literalType(""))
});
var enquirySchema = discriminatedUnionType("type", [contactEnquirySchema, quoteEnquirySchema]);
//#endregion
export { enquirySchema as t };
