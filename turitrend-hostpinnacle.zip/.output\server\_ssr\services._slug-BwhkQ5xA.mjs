import { r as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as ArrowUpRight, O as Check, P as ArrowLeft } from "../_libs/lucide-react.mjs";
import { h as track, m as services, n as CtaLink, r as WhatsAppCta } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as CtaBand } from "./cta-band-CNJbZvLK.mjs";
import { t as Reveal } from "./reveal-9iJXRnDn.mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { t as SectionHeading } from "./section-heading-CNHs7aX1.mjs";
import { r as serviceImages } from "./placeholders-CL4ero5s.mjs";
import { i as AccordionTrigger, n as AccordionContent, r as AccordionItem, t as Accordion } from "./accordion-uwqhymWC.mjs";
import { t as Route } from "./services._slug-D5yTtc4j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services._slug-BwhkQ5xA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ServiceDetail() {
	const { service } = Route.useLoaderData();
	const related = service.related.map((slug) => services.find((s) => s.slug === slug)).filter((s) => Boolean(s));
	const whatsappMessage = `Hello Turiend, I am interested in your ${service.shortTitle} services and would like to discuss my project.`;
	(0, import_react.useEffect)(() => {
		track("service_view", { service: service.slug });
	}, [service.slug]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Service",
			title: service.title,
			intro: service.summary,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/services",
					className: "label-tech inline-flex w-fit items-center gap-2 text-ink-muted transition-colors hover:text-ink-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Back to Services"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaLink, {
						to: "/quote",
						variant: "accent",
						size: "lg",
						children: "Request a Quote"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppCta, {
						message: whatsappMessage,
						label: "Discuss this service",
						variant: "outlineLight",
						size: "lg",
						context: `service_${service.slug}`
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative h-12 overflow-hidden bg-background",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-b from-ink via-ink/50 to-background" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x pb-16 md:pb-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 md:grid-cols-12 md:gap-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "md:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden bg-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: serviceImages[service.slug].src,
								alt: serviceImages[service.slug].alt,
								width: 1600,
								height: 1e3,
								loading: "eager",
								className: "aspect-4/3 w-full object-cover transition-transform duration-700 hover:scale-[1.015]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-linear-to-t from-ink/45 via-transparent to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute bottom-5 left-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "label-tech bg-background/90 px-3 py-2 text-foreground backdrop-blur-sm",
									children: service.shortTitle
								})
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: 120,
					className: "flex flex-col justify-center md:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label-tech text-accent",
							children: "The service"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display-3 mt-5",
							children: "What this service covers."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-7 space-y-5 text-base leading-relaxed text-muted-foreground",
							children: service.intro.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 border-t border-line pt-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "label-tech text-muted-foreground",
								children: "Scope is agreed around the property, existing conditions and the work required."
							})
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x section-y",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Scope",
					title: "What the work can include",
					intro: "The exact scope depends on the property and project requirements. Typical work may include the following."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-px border border-line bg-line md:grid-cols-3",
					children: service.includes.map((group, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 70,
						className: "bg-background p-7 md:p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-start justify-between gap-5",
							children: group.heading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "max-w-14rem text-right text-sm font-semibold tracking-tight",
								children: group.heading
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-7 space-y-4",
							children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 border-t border-line pt-4 text-sm leading-relaxed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "mt-0.5 size-4 shrink-0 text-accent",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
							}, item))
						})]
					}, group.heading ?? i))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-14 md:grid-cols-12 md:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: "Typical needs",
						title: "When clients call us."
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-9 space-y-5",
						children: service.needs.map((need, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							as: "li",
							delay: i * 60,
							className: "border-l-2 border-accent pl-5 text-base leading-relaxed",
							children: need
						}, need))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: "Our approach",
						title: "How we handle the work."
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-9",
						children: service.approach.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							as: "div",
							delay: i * 60,
							className: "border-t border-line py-6 last:border-b",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-semibold tracking-tight",
								children: item.step
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground",
								children: item.text
							})] })
						}, item.step))
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x section-y",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "FAQs",
					title: "Questions we are asked."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: 100,
					className: "mt-9 max-w-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
						type: "single",
						collapsible: true,
						children: service.faqs.map((faq, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
							value: `faq-${i}`,
							className: "border-line",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
								className: "py-5 text-left text-base font-semibold tracking-tight hover:no-underline",
								children: faq.q
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
								className: "pb-6 text-sm leading-relaxed text-muted-foreground",
								children: faq.a
							})]
						}, faq.q))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/faqs",
						className: "label-tech mt-8 inline-flex items-center gap-2 text-accent transition-opacity hover:opacity-70",
						children: ["All FAQs", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
							className: "size-4",
							"aria-hidden": "true"
						})]
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-x section-y",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Related",
				title: "Other services."
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-px border border-line bg-line md:grid-cols-3",
				children: related.map((relatedService, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 60,
					className: "bg-background",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/services/$slug",
						params: { slug: relatedService.slug },
						className: "group flex h-full flex-col p-7 transition-colors duration-300 hover:bg-ink hover:text-ink-foreground md:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "label-tech text-accent",
									children: relatedService.number
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
									className: "size-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5",
									"aria-hidden": "true"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-8 text-lg font-semibold tracking-tight",
								children: relatedService.shortTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 flex-1 text-sm leading-relaxed text-muted-foreground group-hover:text-ink-muted",
								children: relatedService.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "label-tech mt-8 text-accent",
								children: "View service"
							})
						]
					})
				}, relatedService.slug))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {
			title: `Planning ${service.shortTitle.toLowerCase()}?`,
			text: "Send the details and we will come back to you on scope, sequence and what a quotation would need.",
			whatsappMessage,
			context: `service_band_${service.slug}`
		})
	] });
}
//#endregion
export { ServiceDetail as component };
