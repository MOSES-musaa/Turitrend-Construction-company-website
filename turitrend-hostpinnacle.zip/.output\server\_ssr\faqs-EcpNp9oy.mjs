import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as Search } from "../_libs/lucide-react.mjs";
import { c as generalFaqs } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as CtaBand } from "./cta-band-CNJbZvLK.mjs";
import { t as PageHero } from "./page-hero-CQEGAZcs.mjs";
import { i as AccordionTrigger, n as AccordionContent, r as AccordionItem, t as Accordion } from "./accordion-uwqhymWC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faqs-EcpNp9oy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Faqs() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("All");
	const categories = (0, import_react.useMemo)(() => ["All", ...Array.from(new Set(generalFaqs.map((f) => f.category)))], []);
	const results = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return generalFaqs.filter((faq) => {
			const inCategory = category === "All" || faq.category === category;
			const inQuery = !q || faq.q.toLowerCase().includes(q) || faq.a.toLowerCase().includes(q);
			return inCategory && inQuery;
		});
	}, [query, category]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "FAQs",
			title: "Questions clients ask us.",
			intro: "Straight answers on scope, quotations and what each service actually involves."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 md:grid-cols-12 md:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sticky top-28",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "faq-search",
								className: "label-tech text-muted-foreground",
								children: "Search FAQs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "faq-search",
									type: "search",
									value: query,
									onChange: (e) => setQuery(e.target.value),
									placeholder: "e.g. quotation, gate, biodigester",
									className: "min-h-11 w-full border border-input bg-card py-3 pr-3 pl-9 text-sm outline-none focus:border-ink"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "label-tech mt-8 text-muted-foreground",
								children: "Categories"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setCategory(c),
									"aria-pressed": category === c,
									className: cn("min-h-11 border px-3.5 py-2 text-xs font-medium transition-colors", category === c ? "border-ink bg-ink text-ink-foreground" : "border-line hover:border-ink"),
									children: c
								}, c))
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "label-tech text-muted-foreground",
						"aria-live": "polite",
						children: [
							results.length,
							" ",
							results.length === 1 ? "question" : "questions"
						]
					}), results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 border border-line bg-card p-8 text-sm leading-relaxed text-muted-foreground",
						children: "Nothing matches that search. Try a different word, or ask us directly on WhatsApp — we answer questions that are not listed here."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
						type: "single",
						collapsible: true,
						className: "mt-4",
						children: results.map((faq, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
							value: `faq-${i}`,
							className: "border-line",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
								className: "py-5 text-left text-base font-semibold tracking-tight hover:no-underline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "label-tech mb-1.5 block text-accent",
									children: faq.category
								}), faq.q] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
								className: "pb-6 text-sm leading-relaxed text-muted-foreground",
								children: faq.a
							})]
						}, faq.q))
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {
			title: "Still need an answer?",
			text: "Send us the question with a little detail about the property and we will respond.",
			whatsappMessage: "Hello Turiend, I have a question about your construction services.",
			context: "faqs"
		})
	] });
}
//#endregion
export { Faqs as component };
