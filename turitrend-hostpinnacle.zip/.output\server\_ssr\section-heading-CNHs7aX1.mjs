import { t as cn } from "./utils-C_uf36nf.mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/section-heading-CNHs7aX1.js
var import_jsx_runtime = require_jsx_runtime();
function SectionHeading({ eyebrow, title, intro, align = "left", tone = "light", className, as: Tag = "h2" }) {
	const muted = tone === "dark" ? "text-ink-muted" : "text-muted-foreground";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("border-t pt-6", tone === "dark" ? "border-ink-line" : "border-line", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("gap-8 md:gap-16", align === "split" ? "grid md:grid-cols-12" : "flex flex-col"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: align === "split" ? "md:col-span-7" : void 0,
				children: [eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("label-tech mb-5 flex items-center gap-3", muted),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: eyebrow })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
					className: "display-2 max-w-3xl",
					children: title
				})]
			}), intro && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn(align === "split" ? "md:col-span-5 md:pt-14" : "mt-6 max-w-2xl", "text-base leading-relaxed md:text-lg", muted),
				children: intro
			})]
		})
	});
}
//#endregion
export { SectionHeading as t };
