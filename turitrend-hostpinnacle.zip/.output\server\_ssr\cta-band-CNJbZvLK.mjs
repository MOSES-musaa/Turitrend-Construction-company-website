import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as CtaLink, r as WhatsAppCta } from "./whatsapp-button-ChXxaLqO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cta-band-CNJbZvLK.js
var import_jsx_runtime = require_jsx_runtime();
function CtaBand({ title = "Tell us what you are planning.", text = "Send us the details of your project and we will come back to you on scope, next steps and what a quotation would need.", whatsappMessage = "Hello Turiend, I would like to discuss a construction project.", context = "cta_band" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-ink text-ink-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-x section-y grid gap-10 md:grid-cols-12 md:items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech text-accent",
						children: "Next step"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display-2 mt-5",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl text-base leading-relaxed text-ink-muted md:text-lg",
						children: text
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row md:col-span-5 md:justify-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaLink, {
					to: "/quote",
					variant: "accent",
					size: "lg",
					children: "Request a Quote"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppCta, {
					message: whatsappMessage,
					variant: "outlineLight",
					size: "lg",
					context
				})]
			})]
		})
	});
}
//#endregion
export { CtaBand as t };
