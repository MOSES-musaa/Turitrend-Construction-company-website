import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as BriefcaseBusiness, C as FileText, E as CircleQuestionMark, _ as Lightbulb, b as House, d as Phone, g as Mail, h as MapPin, k as Building2, m as Menu, p as MessageCircle, r as Workflow, t as X, y as Info } from "../_libs/lucide-react.mjs";
import { c as generalFaqs, g as whatsappLink, h as track, i as WhatsAppFloat, m as services, n as CtaLink, o as company, s as defaultWhatsappMessage } from "./whatsapp-button-ChXxaLqO.mjs";
import { t as Route$12 } from "./insights._slug-DFlC2dLy.mjs";
import { t as Route$13 } from "./projects._slug-BPr1HOFN.mjs";
import { t as Route$14 } from "./services._slug-D5yTtc4j.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CYasImKE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-hQhEHVxV.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var logo1_default = "/assets/logo1-CAT8vbKs.png";
var navItems = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/about",
		label: "About",
		icon: Info
	},
	{
		to: "/services",
		label: "Services",
		icon: BriefcaseBusiness
	},
	{
		to: "/projects",
		label: "Projects",
		icon: Building2
	},
	{
		to: "/how-we-work",
		label: "How We Work",
		icon: Workflow
	},
	{
		to: "/faqs",
		label: "FAQs",
		icon: CircleQuestionMark
	},
	{
		to: "/insights",
		label: "Insights",
		icon: Lightbulb
	},
	{
		to: "/contact",
		label: "Contact",
		icon: Mail
	}
];
var quoteNavItem = {
	label: "Request a Quote",
	icon: FileText
};
function SiteHeader() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const QuoteIcon = quoteNavItem.icon;
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("sticky top-0 z-50 border-b bg-background/90 backdrop-blur-md transition-all duration-300", scrolled ? "border-line" : "border-transparent"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("container-x flex items-center justify-between transition-all duration-300", scrolled ? "h-16" : "h-20 md:h-24"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex shrink-0 items-center",
					"aria-label": "Turiend Construction Limited — home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: logo1_default,
						alt: "Turiend Construction Limited",
						width: 280,
						height: 82,
						className: cn("w-auto object-contain transition-all duration-300", scrolled ? "h-10 md:h-11" : "h-12 md:h-14")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Main",
					className: "hidden items-center gap-7 lg:flex",
					children: navItems.slice(1).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "text-sm font-medium text-foreground/75 transition-colors hover:text-accent [&.active]:text-accent",
						activeOptions: { exact: item.to === "/" },
						children: item.label
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaLink, {
						to: "/quote",
						variant: "ink",
						size: "sm",
						className: "hidden sm:inline-flex",
						children: "Request a Quote"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen((v) => !v),
						"aria-expanded": open,
						"aria-controls": "mobile-nav",
						"aria-label": open ? "Close menu" : "Open menu",
						className: "flex size-11 items-center justify-center border border-line lg:hidden",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})]
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: "mobile-nav",
			className: "absolute left-0 right-0 top-full z-50 max-h-[calc(100vh-4rem)] overflow-y-auto border-t border-line bg-background shadow-lg lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Mobile",
				className: "container-x flex flex-col py-2",
				children: [navItems.map((item) => {
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						onClick: () => setOpen(false),
						className: "group flex items-center gap-4 border-b border-line py-5 text-2xl font-semibold tracking-tight transition-colors hover:text-accent [&.active]:text-accent",
						activeOptions: { exact: item.to === "/" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5 shrink-0 text-foreground/45 transition-colors group-hover:text-accent group-[.active]:text-accent",
							strokeWidth: 1.8,
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
					}, item.to);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CtaLink, {
					to: "/quote",
					variant: "accent",
					size: "lg",
					className: "mt-6 mb-28",
					onClick: () => setOpen(false),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteIcon, {
						className: "size-5",
						strokeWidth: 1.8,
						"aria-hidden": "true"
					}), quoteNavItem.label]
				})]
			})
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-px bg-ink text-ink-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-x grid gap-12 py-14 md:grid-cols-12 md:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: logo1_default,
						alt: "Turiend Construction Limited",
						width: 220,
						height: 64,
						loading: "lazy",
						className: "h-12 w-auto rounded-sm border border-primary/30 bg-secondary px-3 py-2 shadow-[0_8px_24px_rgb(0_0_0_/_14%)]"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 max-w-sm text-sm leading-relaxed text-ink-muted",
						children: [company.name, " is a Kenyan construction company covering building works, renovations, civil works, water and electrical installations, perimeter and access works, biodigesters, and project and property management."]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "md:col-span-3",
					"aria-label": "Footer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "label-tech text-ink-muted",
						children: "Quick links"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 space-y-3 text-sm",
						children: navItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: "transition-colors hover:text-accent",
							children: item.label
						}) }, item.to))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "label-tech text-ink-muted",
						children: "Services"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 space-y-3 text-sm",
						children: services.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/services/$slug",
							params: { slug: s.slug },
							className: "transition-colors hover:text-accent",
							children: s.shortTitle
						}) }, s.slug))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("address", {
					className: "not-italic md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "label-tech text-ink-muted",
						children: "Contact"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-5 space-y-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: company.phoneHref,
								onClick: () => track("phone_click", { context: "footer" }),
								className: "flex items-start gap-2.5 transition-colors hover:text-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "mt-0.5 size-4 shrink-0 text-accent",
									"aria-hidden": "true"
								}), company.phone]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: company.emailHref,
								onClick: () => track("email_click", { context: "footer" }),
								className: "flex items-start gap-2.5 break-all transition-colors hover:text-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "mt-0.5 size-4 shrink-0 text-accent",
									"aria-hidden": "true"
								}), company.email]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-2.5 text-ink-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
									className: "mt-0.5 size-4 shrink-0 text-accent",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									company.location,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									company.postal
								] })]
							})
						]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-ink-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x flex flex-col gap-2 py-6 text-xs text-ink-muted sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" ",
					company.name,
					". All rights reserved."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech",
					children: company.tagline
				})]
			})
		})]
	});
}
function MobileActionBar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-x-0 bottom-0 z-50 grid grid-cols-3 border-t border-ink-line bg-ink text-ink-foreground md:hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: company.phoneHref,
				onClick: () => track("phone_click", { context: "mobile_bar" }),
				className: "flex min-h-14 flex-col items-center justify-center gap-1 border-r border-ink-line text-[0.7rem] font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
					className: "size-4.5",
					"aria-hidden": "true"
				}), "Call"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: whatsappLink(defaultWhatsappMessage),
				target: "_blank",
				rel: "noopener noreferrer",
				onClick: () => track("whatsapp_click", { context: "mobile_bar" }),
				className: "flex min-h-14 flex-col items-center justify-center gap-1 border-r border-ink-line text-[0.7rem] font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
					className: "size-4.5",
					"aria-hidden": "true"
				}), "WhatsApp"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/quote",
				onClick: () => track("cta_click", {
					context: "mobile_bar",
					cta: "quote"
				}),
				className: "flex min-h-14 flex-col items-center justify-center gap-1 bg-accent text-[0.7rem] font-semibold text-accent-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
					className: "size-4.5",
					"aria-hidden": "true"
				}), "Get a Quote"]
			})
		]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-[70vh] items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech text-accent",
					children: "Error 404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display-2 mt-4",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex min-h-11 items-center justify-center bg-ink px-6 py-3 text-sm font-medium text-ink-foreground transition-colors hover:bg-primary",
						children: "Go home"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services",
						className: "inline-flex min-h-11 items-center justify-center border border-ink/25 px-6 py-3 text-sm font-medium transition-colors hover:border-ink",
						children: "View services"
					})]
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-[70vh] items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display-3",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-muted-foreground",
					children: [
						"Something went wrong on our end. Try again, or call us on ",
						company.phone,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex min-h-11 items-center justify-center bg-ink px-6 py-3 text-sm font-medium text-ink-foreground transition-colors hover:bg-primary",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex min-h-11 items-center justify-center border border-ink/25 px-6 py-3 text-sm font-medium transition-colors hover:border-ink",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$11 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Turiend Construction Limited | Building & Civil Works, Kenya" },
			{
				name: "description",
				content: "Turiend Construction Limited — building works, renovations, fencing and gates, biodigesters, road, electrical and water works, and project management in Kenya."
			},
			{
				name: "author",
				content: "Turiend Construction Limited"
			},
			{
				property: "og:site_name",
				content: "Turiend Construction Limited"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "theme-color",
				content: "#1d2027"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:wght@400;500;600&display=swap"
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "GeneralContractor",
				name: company.name,
				description: "Kenyan construction company providing building works, renovations, civil works, water works, electrical works, perimeter and access works, biodigester works and project management.",
				telephone: company.phone,
				email: company.email,
				areaServed: "Kenya",
				address: {
					"@type": "PostalAddress",
					addressLocality: "Nairobi",
					addressCountry: "KE",
					postOfficeBoxNumber: "317 – 10106, Othaya"
				}
			})
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$11.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-100 focus:bg-ink focus:px-4 focus:py-2 focus:text-ink-foreground",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "main",
				className: "pb-14 md:pb-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppFloat, { message: defaultWhatsappMessage }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileActionBar, {})
		]
	});
}
var $$splitComponentImporter$10 = () => import("./routes-CfmC-AhK.mjs");
var Route$10 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Turiend Construction Limited | Construction Company in Kenya" },
		{
			name: "description",
			content: "Building works, renovations, fencing and gate automation, biodigesters, road, electrical and water works, and project management across Kenya. Request a quote from Turiend."
		},
		{
			property: "og:title",
			content: "Turiend Construction Limited | Construction in Kenya"
		},
		{
			property: "og:description",
			content: "A Kenyan construction company covering building, renovations, civil, water and electrical works, perimeter and access works, and project management."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./about-DmgPWvwW.mjs");
var Route$9 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: "About Turiend Construction Limited | Nairobi, Kenya" },
		{
			name: "description",
			content: "Turiend Construction Limited is a Kenyan construction company covering building, civil, water and electrical works, perimeter works, biodigesters and project management."
		},
		{
			property: "og:title",
			content: "About Turiend Construction Limited"
		},
		{
			property: "og:description",
			content: "Who Turiend is, how we work with clients, and the disciplines we cover across Kenya."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./contact-vyGBNZ8D.mjs");
var Route$8 = createFileRoute("/contact")({
	head: () => ({ meta: [
		{ title: "Contact Turiend Construction Limited | Nairobi, Kenya" },
		{
			name: "description",
			content: `Contact Turiend Construction Limited — call ${company.phone}, message on WhatsApp, or email ${company.email}. Based in Nairobi, Kenya.`
		},
		{
			property: "og:title",
			content: "Contact Turiend Construction Limited"
		},
		{
			property: "og:description",
			content: "Phone, WhatsApp and email contact details for Turiend Construction Limited."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./faqs-EcpNp9oy.mjs");
var Route$7 = createFileRoute("/faqs")({
	head: () => ({
		meta: [
			{ title: "FAQs | Turiend Construction Limited" },
			{
				name: "description",
				content: "Answers on quotations, building works, renovations, fencing and gates, biodigesters, road, electrical and water works, and project management in Kenya."
			},
			{
				property: "og:title",
				content: "Frequently Asked Questions | Turiend Construction"
			},
			{
				property: "og:description",
				content: "Common questions about working with Turiend Construction Limited in Kenya."
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "FAQPage",
				mainEntity: generalFaqs.map((f) => ({
					"@type": "Question",
					name: f.q,
					acceptedAnswer: {
						"@type": "Answer",
						text: f.a
					}
				}))
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./how-we-work-Bov7zvP5.mjs");
var Route$6 = createFileRoute("/how-we-work")({
	head: () => ({ meta: [
		{ title: "How We Work | Turiend Construction Limited" },
		{
			name: "description",
			content: "Our six-step project journey: understand, assess, plan and cost, mobilize, execute and supervise, complete and hand over."
		},
		{
			property: "og:title",
			content: "How We Work | Turiend Construction Limited"
		},
		{
			property: "og:description",
			content: "The six steps a Turiend project moves through, from first conversation to handover."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./insights-C-A84leN.mjs");
var Route$5 = createFileRoute("/insights")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./projects-CLVm_UNT.mjs");
var Route$4 = createFileRoute("/projects")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./quote-D28YqBeO.mjs");
var Route$3 = createFileRoute("/quote")({
	head: () => ({ meta: [
		{ title: "Request a Quote | Turiend Construction Limited" },
		{
			name: "description",
			content: "Tell Turiend Construction about your project — building, renovations, fencing, biodigesters, road, electrical or water works — and receive a considered response."
		},
		{
			property: "og:title",
			content: "Request a Quote | Turiend Construction Limited"
		},
		{
			property: "og:description",
			content: "A short guided enquiry that helps us understand your project before we respond."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./insights.index-BR_brZup.mjs");
var Route$2 = createFileRoute("/insights/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./projects.index-XZvwNUyJ.mjs");
var Route$1 = createFileRoute("/projects/")({
	head: () => ({ meta: [
		{ title: "Projects | Turiend Construction Limited" },
		{
			name: "description",
			content: "Turiend Construction project showcases are being documented. In the meantime, tell us about your project and we will discuss comparable work directly."
		},
		{
			property: "og:title",
			content: "Projects | Turiend Construction Limited"
		},
		{
			property: "og:description",
			content: "Project showcases from Turiend Construction Limited, currently being documented."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./services.index-BJdaUO4T.mjs");
var Route = createFileRoute("/services/")({
	head: () => ({ meta: [
		{ title: "Construction Services in Kenya | Turiend Construction Limited" },
		{
			name: "description",
			content: "Six service areas: home improvements and renovations, building works, fences and gate automation, biodigesters, road, electrical and water works, and project management."
		},
		{
			property: "og:title",
			content: "Construction Services | Turiend Construction Limited"
		},
		{
			property: "og:description",
			content: "Building, renovation, civil, water, electrical, perimeter and project management services."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$10.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$11
});
var AboutRoute = Route$9.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$11
});
var ContactRoute = Route$8.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$11
});
var FaqsRoute = Route$7.update({
	id: "/faqs",
	path: "/faqs",
	getParentRoute: () => Route$11
});
var HowWeWorkRoute = Route$6.update({
	id: "/how-we-work",
	path: "/how-we-work",
	getParentRoute: () => Route$11
});
var InsightsRoute = Route$5.update({
	id: "/insights",
	path: "/insights",
	getParentRoute: () => Route$11
});
var ProjectsRoute = Route$4.update({
	id: "/projects",
	path: "/projects",
	getParentRoute: () => Route$11
});
var QuoteRoute = Route$3.update({
	id: "/quote",
	path: "/quote",
	getParentRoute: () => Route$11
});
var InsightsIndexRoute = Route$2.update({
	id: "/",
	path: "/",
	getParentRoute: () => InsightsRoute
});
var InsightsSlugRoute = Route$12.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => InsightsRoute
});
var ProjectsIndexRoute = Route$1.update({
	id: "/",
	path: "/",
	getParentRoute: () => ProjectsRoute
});
var ProjectsSlugRoute = Route$13.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => ProjectsRoute
});
var ServicesIndexRoute = Route.update({
	id: "/services/",
	path: "/services/",
	getParentRoute: () => Route$11
});
var ServicesSlugRoute = Route$14.update({
	id: "/services/$slug",
	path: "/services/$slug",
	getParentRoute: () => Route$11
});
var InsightsRouteChildren = {
	InsightsSlugRoute,
	InsightsIndexRoute
};
var InsightsRouteWithChildren = InsightsRoute._addFileChildren(InsightsRouteChildren);
var ProjectsRouteChildren = {
	ProjectsSlugRoute,
	ProjectsIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	ContactRoute,
	FaqsRoute,
	HowWeWorkRoute,
	InsightsRoute: InsightsRouteWithChildren,
	ProjectsRoute: ProjectsRoute._addFileChildren(ProjectsRouteChildren),
	QuoteRoute,
	ServicesSlugRoute,
	ServicesIndexRoute
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
