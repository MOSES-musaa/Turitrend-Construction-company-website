import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects._slug-BPr1HOFN.js
var $$splitComponentImporter = () => import("./projects._slug-Di73U2df.mjs");
var Route = createFileRoute("/projects/$slug")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
